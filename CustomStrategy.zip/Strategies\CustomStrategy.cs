#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.MarketAnalyzerColumns;
using System.Windows.Controls;
using NinjaTrader.Gui.Tools;
using System.Windows.Documents;
using System.Runtime.Remoting.Channels;
using System.Windows.Navigation;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class CustomStrategy : Strategy
	{
        #region Variables
        private const string CHART_TRADER_AUTOMATION_ID = "ChartWindowChartTraderControl";
        private const string CHART_TRADER_MAIN_GRID_NAME = "grdMain";
        private const string CHART_TRADER_EXTENSION_ROW_NAME = "ChartTraderExtensionsRow";
        private const string CHART_TRADER_EXTENSION_GRID_UID = "ChartTraderExtensionsGrid";
        private const string SAMPLE_BUTTON_UID = "SampleButton";
        private const int CHART_TRADER_ROWS = 7;
        private int chartWindowCount = 0;
        private Button CustomButton;
        private Grid mainGrid;
        private Grid chartTraderExtensionGrid;
        private AccountSelector accountSelector;
        private ChartTrader chartTrader;
        private Account selectedAccount;
        private enum ButtonState { ON, RUN, OFF }
		private ButtonState currentState = ButtonState.OFF;
		private double buyStopDistance;
		private double sellStopDistance;
        private double lastPrice;
        private Order buyStopOrder;
		private Order sellStopOrder;
        private Order buyStopLossOrder;
        private Order sellStopLossOrder;
        #endregion

        
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Strategy here.";
                Name = "CustomStrategy";
                Calculate = Calculate.OnPriceChange;
                EntriesPerDirection = 1;
                EntryHandling = EntryHandling.AllEntries;
                ConnectionLossHandling = ConnectionLossHandling.Recalculate;
                DisconnectDelaySeconds = 10;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                IsFillLimitOnTouch = false;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution = OrderFillResolution.Standard;
                Slippage = 0;
                StartBehavior = StartBehavior.ImmediatelySubmit;
                TimeInForce = TimeInForce.Gtc;
                TraceOrders = false;
                RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade = 20;
                IsUnmanaged = true;
                OnColor = Brushes.DodgerBlue;
                OffColor = Brushes.Gray;
                RunColor = Brushes.HotPink;
                Distance = 10;
                Lots = 4;
                SL_Distance = 20;
                TrailingDistance = 20;
                IncludeTradeHistoryInBacktest = true;

                // Disable this property for performance gains in Strategy Analyzer optimizations
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration = true;
                // Add custom button when data is loaded and chart interface is available

 
            }
            else if (State == State.Configure)
            {


            }
            else if (State == State.Historical)
            {
                Dispatcher.InvokeAsync(() =>
                {
                    chartTrader = Window.GetWindow(ChartPanel).FindFirst(CHART_TRADER_AUTOMATION_ID) as ChartTrader;
                    selectedAccount = chartTrader.Account;
                    if (chartTrader == null) return; // something is seriously wrong if chartTrader is null

                    // find the main Chart Trader grid where the default buttons and controls reside
                    mainGrid = chartTrader.FindName(CHART_TRADER_MAIN_GRID_NAME) as Grid;
                    Print("MainGrid is created" + mainGrid);
                    Print("Main Grid is not null");
                    if (mainGrid != null)
                    {
                        Print("Main Grid is not null");
                        mainGrid?.Dispatcher.InvokeAsync(() =>
                        {
                            Print("Async function executed");
                            // define a Chart Trader Extension grid
                            chartTraderExtensionGrid = new Grid
                            {
                                VerticalAlignment = VerticalAlignment.Bottom,
                                Margin = new Thickness(10),
                                Uid = CHART_TRADER_EXTENSION_GRID_UID,

                            };
                            // Create the button
                            CustomButton = new Button()
                            {
                                Foreground = Brushes.Black,
                            };


                            CustomButton.Click += OnButtonClicked;

                            // Add the button to the ChartTrader's grid or panel
                            chartTraderExtensionGrid.Children.Add(CustomButton);
                            // by default, there will be 7 rows in Chart Trader, we need to add a new row for the Chart Trader Extension Grid
                            if (mainGrid.RowDefinitions.Count <= CHART_TRADER_ROWS)
                            {
                                RowDefinition newRow = new RowDefinition
                                {
                                    Name = CHART_TRADER_EXTENSION_ROW_NAME,
                                };
                                Print("Adding a new row to the Chart Trader grid on Window " + chartWindowCount);
                                mainGrid.RowDefinitions.Add(newRow);
                            }
                            // add the Chart Trader Extension grid to the new row we just created
                            Grid.SetRow(chartTraderExtensionGrid, mainGrid.RowDefinitions.Count);
                            Print("Adding the Chart Trader Extension grid to the Chart Trader grid on Window " + chartWindowCount);
                            mainGrid.Children.Add(chartTraderExtensionGrid);
                        });
                    }
                });



            }
            else if (State == State.Terminated)
            {
                if (mainGrid != null)
                {
                    Print("Strategy is terminating...");
                    mainGrid?.Dispatcher.InvokeAsync(() =>
                    {
                        Print("Found mainGrid. Attempting to remove custom elements...");
                        mainGrid.Children.Remove(chartTraderExtensionGrid);
                         // Make sure to set this to null as well after removing
                        Print("Elements removal should now be complete.");
                    });
                }
            }
        }
		 private void OnButtonClicked(object sender, RoutedEventArgs rea)
        {
            Button button = sender as Button;
            switch (currentState)
            {
                case ButtonState.OFF:
                    currentState = ButtonState.ON;
                    CustomButton.Content = "ON";
                    CustomButton.Background = OnColor;
                    // Initialize orders at the start
                    if (buyStopOrder == null && sellStopOrder == null)
                    {
                        buyStopDistance = Distance * TickSize;
                        sellStopDistance = Distance * TickSize;
                        PlaceOrders(lastPrice);
                    }
                    break;
                case ButtonState.ON:
                    currentState = ButtonState.RUN;
                    CustomButton.Content = "RUN";
                    CustomButton.Background = RunColor;
                    // Orders are now static
                    break;
                case ButtonState.RUN:
                    currentState = ButtonState.OFF;
                    CustomButton.Content = "OFF";
                    CustomButton.Background = OffColor;
                    CancelOrders();
                    buyStopOrder = null;
                    sellStopOrder = null;
                    break;
            }
        }
        private void UpdateButtonContent()
        {
            CustomButton.Dispatcher.InvokeAsync(() =>
            {
                switch (currentState)
                {
                    case ButtonState.ON:
                        CustomButton.Content = "ON";
                        CustomButton.Background = OnColor;
                        break;
                    case ButtonState.RUN:
                        CustomButton.Content = "RUN";
                        CustomButton.Background = RunColor;
                        break;
                    case ButtonState.OFF:
                        CustomButton.Content = "OFF";
                        CustomButton.Background = OffColor;
                        Print("Succesful convert Off");
                        Print("Account " + selectedAccount.ToString());
                        break;
                }
            });

        }
	
		private void CancelOrders()
		{
		    if (buyStopOrder != null)
		        CancelOrder(buyStopOrder);
                buyStopOrder = null;
		    if (sellStopOrder != null)
		        CancelOrder(sellStopOrder);
                sellStopOrder = null;
            if (buyStopLossOrder != null)
                CancelOrder(buyStopLossOrder);
                buyStopLossOrder = null;
            if (sellStopLossOrder != null)
                CancelOrder(sellStopLossOrder);
                sellStopLossOrder = null;
            if (Position != null && Position.MarketPosition == MarketPosition.Long)
            {
                // Close the long position by entering an equivalent short position
                SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, Position.Quantity, 0, 0, "", "Close Long Position");
            }
            else if (Position != null && Position.MarketPosition == MarketPosition.Short)
            {
                // Close the short position by entering an equivalent long position
                SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, Position.Quantity, 0, 0, "", "Close Short Position");
            }
        }

		protected override void OnBarUpdate()
		{
            if (currentState == ButtonState.ON)
            {

                double currentPrice = Close[0]; // Current price based on the last close

                if (buyStopOrder != null && sellStopOrder != null)
                {
                    // Adjust orders as price changes
                    AdjustStopOrders(currentPrice);
                }

            }
            if (currentState == ButtonState.RUN)
            {
                // Once in a position, check if price moved favorably by 'profitTrigger' points
                if (Position != null && Position.MarketPosition == MarketPosition.Long)
                {
                    double currentProfitPoints = Position.GetUnrealizedProfitLoss(PerformanceUnit.Points, Close[0]) / TickSize;
                    Print("Current Profit Points ---- " + currentProfitPoints);

                    if (currentProfitPoints >= TrailingStartDistance)
                    {
                        Print("Break Even Price-0 " + Close[0]);

                        // Now place initial trailing stop 'trailingStopLossTicks' ticks under the break even price
                        UpdateBuyTrailingStop(Close[0]);
                    }
                }
                if (Position != null && Position.MarketPosition == MarketPosition.Short)
                {
                    double currentProfitPoints = Position.GetUnrealizedProfitLoss(PerformanceUnit.Points, Close[0]) / TickSize;
                    Print("Current Profit Points - " + currentProfitPoints);

                    if (currentProfitPoints >= TrailingStartDistance)
                    {
                        Print("Break Even Price-0 " + Close[0]);

                        // Now place initial trailing stop 'trailingStopLossTicks' ticks under the break even price
                        UpdateSellTrailingStop(Close[0]);
                    }
                }
                lastPrice = Close[0];
            }
            if (currentState == ButtonState.OFF)
            {
                buyStopOrder = null;
                sellStopOrder = null;
                lastPrice = Close[0];
            }
            Dispatcher.InvokeAsync(UpdateButtonContent);
        }
        private void PlaceOrders(double initialPrice)
        {
            if (buyStopOrder != null)
                CancelOrder(buyStopOrder);
            if (sellStopOrder != null)
                CancelOrder(sellStopOrder);

            buyStopOrder = SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.StopMarket, Lots, 0, initialPrice + buyStopDistance, "", "BuyStop");
            sellStopOrder = SubmitOrderUnmanaged(0, OrderAction.SellShort, OrderType.StopMarket, Lots, 0, initialPrice - buyStopDistance, "", "SellStop");

        }

        private void AdjustStopOrders(double price)
        {
            // Adjust the buy stop order
            if (buyStopOrder != null && buyStopOrder.OrderState == OrderState.Working)
                ChangeOrder(buyStopOrder, buyStopOrder.Quantity, buyStopOrder.LimitPrice, price + buyStopDistance);

            // Adjust the sell stop order
            if (sellStopOrder != null && sellStopOrder.OrderState == OrderState.Working)
                ChangeOrder(sellStopOrder, sellStopOrder.Quantity, sellStopOrder.LimitPrice, price - sellStopDistance);
        }
        protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string comment)
        {
            // Handle manual order adjustments here, possibly resetting distances
            if (order == buyStopOrder && order.OrderState == OrderState.Working && Math.Abs((order.StopPrice - Close[0]) - buyStopDistance) > 2 * TickSize)
            {
                buyStopDistance = order.StopPrice - Close[0];
                sellStopDistance = order.StopPrice - Close[0];
                ChangeOrder(sellStopOrder, sellStopOrder.Quantity, sellStopOrder.LimitPrice, Close[0] - sellStopDistance);
                Print("New buy stop distance with buy moving : " + buyStopDistance);
                Print("New Sell stop distance with buy moving : " + sellStopDistance);
            }
            else if (order == sellStopOrder && order.OrderState == OrderState.Working && Math.Abs((Close[0] - order.StopPrice) - sellStopDistance) > 2 * TickSize)
            {
                buyStopDistance = Close[0] - order.StopPrice;
                sellStopDistance = Close[0] - order.StopPrice;
                ChangeOrder(buyStopOrder, buyStopOrder.Quantity, buyStopOrder.LimitPrice, Close[0] + buyStopDistance);
                Print("New buy stop distance with sell moving : " + buyStopDistance);
                Print("New Sell stop distance sell moving : " + sellStopDistance);
            }
        }

        // This method is called on each execution, including partial fills
        protected override void OnExecutionUpdate(Cbi.Execution execution, string executionId, double price, int quantity, Cbi.MarketPosition marketPosition, string orderId, DateTime time)
        {
            // If our entry order was filled, place an initial trailing stop
            if (execution.Order == buyStopOrder && buyStopLossOrder == null)
            {
                CancelOrder(sellStopOrder);
                double buyStopLoss = execution.Price - SL_Distance * TickSize;
                buyStopLossOrder = SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, quantity, 0, buyStopLoss, "", "Buy Trail Stop");
                currentState = ButtonState.RUN;
            }
            if (execution.Order == sellStopOrder && sellStopLossOrder == null)
            {
                CancelOrder(buyStopOrder);
                double sellStopLoss = execution.Price + SL_Distance * TickSize;
                sellStopLossOrder = SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.StopMarket, quantity, 0, sellStopLoss, "", "Sell Trail Stop");
                currentState = ButtonState.RUN;
            }


        }

        protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, int quantity, MarketPosition marketPosition)
        {
            // Call the method that updates the button state on each position update
            if (quantity == 0)
            {
                currentState = ButtonState.OFF;
            }
        }

        // Function to manage the trailing stop
        private void UpdateBuyTrailingStop(double Price)
        {
            double newBuyStopLoss = Price - TrailingDistance * TickSize;

            // Make sure we don't move the stop away from the market
            Print("New Buy Stop Price " +  newBuyStopLoss);
            Print("Previous Buy Stop Price " + buyStopLossOrder.StopPrice);
            if (newBuyStopLoss > buyStopLossOrder.StopPrice)
            {
                CancelOrder(buyStopLossOrder);
                buyStopLossOrder = SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, Lots, 0, newBuyStopLoss, "", "Buy Trail Stop Adjusted");
            }
        }
        private void UpdateSellTrailingStop(double Price)
        {
            double newSellStopLoss = Price + TrailingDistance * TickSize;
            Print("New Sell Stop Price " + newSellStopLoss);
            Print("Previous Sell Stop Price " + sellStopLossOrder.StopPrice);
            // Make sure we don't move the stop away from the market
            if (newSellStopLoss < sellStopLossOrder.StopPrice)
            {
                CancelOrder(sellStopLossOrder);
                sellStopLossOrder = SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.StopMarket, Lots, 0, newSellStopLoss, "", "Sell Trail Stop Adjusted");
            }
        }
		
        #region Properties
        [NinjaScriptProperty]
        public int Lots { get; set; }
        [NinjaScriptProperty]
        public double Distance { get; set; }
        [NinjaScriptProperty]
        public double SL_Distance { get; set; }
        [NinjaScriptProperty]
        public double TrailingStartDistance { get; set; }
        [NinjaScriptProperty]
        public double TrailingDistance { get; set; }
        [NinjaScriptProperty]
        public Brush OnColor { get; set; }
        [NinjaScriptProperty]
        public Brush RunColor { get; set; }
        [NinjaScriptProperty]
        public Brush OffColor { get; set; }
        #endregion
	}
}
