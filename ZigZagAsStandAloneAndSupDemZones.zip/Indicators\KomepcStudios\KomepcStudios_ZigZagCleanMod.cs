#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX.Direct2D1;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.KomepcStudios
{
	public class KomepcStudios_ZigZagCleanMod : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ZigZag Clean Mod by KomepcStudios";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				DisplayInDataBox = true;
				DrawOnPricePanel = true;
				DrawHorizontalGridLines = true;
				DrawVerticalGridLines = true;
				PaintPriceMarkers = true;
				ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive = false;
				Bubbleoffset = .0005;
				Percentamount = .01;
				RevAmount = .15;
				Atrreversal = 1.0;
				Atrlength = 5;
				ShowBubbleschange = true;
				ShowBubblesprice = false;
				ShowBubblesBarsCount = false;
				ShowArrows = false;
				//The commented variables are/were from the SupDem main indicator which infact was/is extension of the zig zag
				//The sup dem zones indicator was containing the zig zag indicator inside itself as a class which is awful approach
				//With this indicator )Komepc Studios version) the Zig Zag indicator is turned to be a real stand alone indicator
				//Stand alone indicator like any other normal indicator - this is the way it should be! :-)
				//usealerts = false;
				//numbersuppdemandtoshow = 2;
				//numberextfibstoshow = 2;
				//showFibExtLines = true;
				//showtodayonly = false;
				//showSupplyDemand = CustomEnumNamespace.showSupplyDemandEnum.Pivot;
				//showSupplyDemandCloud = true;
				//fibextbubblespacesinexpansion = 8;
				ShowBubblesVolume = false;

				//indicator_purpose = "entry";
			}
			else if (State == State.Configure)
			{
			}
			else if(State == State.DataLoaded) {
				//The main (wrong) sup dem indicator was the ind variable forwarded to the zig zag class which was like internal class not as stand alone indicator
				//This code was inside the constuctor of the zig zag class (the wrong one)
				//From now on this code is move here in the Data Loaded on state change state
				//After this edit this cleaned zig zag version is expected to operate perfectly. Lets see :-)

				//!!!
				//ind is replaced by this !!!
				//!!!

				//this.ind = ind;
				//output = new Series<double>(ind, MaximumBarsLookBack.Infinite);
				output = new Series<double>(this, MaximumBarsLookBack.Infinite);

				Points = new Dictionary<int, double>();
				Indices = new Dictionary<int, int>();



				//maxPriceH = new Series<double>(ind, MaximumBarsLookBack.Infinite);
				//minPriceL = new Series<double>(ind, MaximumBarsLookBack.Infinite);
				//state = new Series<double>(ind, MaximumBarsLookBack.Infinite);
				maxPriceH = new Series<double>(this, MaximumBarsLookBack.Infinite);
				minPriceL = new Series<double>(this, MaximumBarsLookBack.Infinite);
				state = new Series<double>(this, MaximumBarsLookBack.Infinite);

				confirmed = true;
			}
		}

		protected override void OnBarUpdate()
		{
			ZigZagUpdate(CurrentBars[0], Highs[0], Lows[0], Percentamount, RevAmount, Atrlength, Atrreversal, 10, ATRWilders(Atrlength)[0], Closes[0][0]);
		}

		#region Parameters

		[NinjaScriptProperty]
		[Display(Name = "Bubble Offset", Order = 1, GroupName = "ZigZag Parameters")]
		public double Bubbleoffset { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Percent Amount", Order = 2, GroupName = "ZigZag Parameters")]
		public double Percentamount { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Rev Amount", Order = 3, GroupName = "ZigZag Parameters")]
		public double RevAmount { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Atr Reversal", Order = 4, GroupName = "ZigZag Parameters")]
		public double Atrreversal { get; set; }


		[NinjaScriptProperty]
		[Display(Name = "Atr Length", Order = 5, GroupName = "ZigZag Parameters")]
		public int Atrlength { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Bubbles Change", Order = 6, GroupName = "ZigZag Parameters")]
		public bool ShowBubbleschange { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Bubbles Price", Order = 7, GroupName = "ZigZag Parameters")]
		public bool ShowBubblesprice { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Bubbles Bars Count", Order = 8, GroupName = "ZigZag Parameters")]
		public bool ShowBubblesBarsCount { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Arrows", Order = 9, GroupName = "ZigZag Parameters")]
		public bool ShowArrows { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Bubbles Volume", Order = 10, GroupName = "ZigZag Parameters")]
		public bool ShowBubblesVolume { get; set; }


		#endregion


		SimpleFont textFont = new SimpleFont("Arial", 11);
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale) {
			OnRenderHack(chartControl, chartScale, null, null, null);
		}
		public void OnRenderHack(ChartControl chartControl, ChartScale chartScale, 
			RenderTarget RenderTarget_ext, 
			ChartBars ChartBars_ext,
			ChartPanel ChartPanel_ext) {
			base.OnRender(chartControl, chartScale);
			if (RenderTarget_ext != null)
				RenderTarget = RenderTarget_ext;
			if (ChartBars_ext != null)
				ChartBars = ChartBars_ext;
			if (ChartPanel_ext != null)
				ChartPanel = ChartPanel_ext;
			try {
				SharpDX.Direct2D1.Brush brush1 = Brushes.Green.ToDxBrush(RenderTarget); // Brushes.Lime.ToDxBrush(RenderTarget);
				SharpDX.Direct2D1.Brush brush2 = Brushes.Red.ToDxBrush(RenderTarget);
				SharpDX.Color spdmndGreen = SharpDX.Color.Lime;
				SharpDX.Color spdmndRed = SharpDX.Color.Red;
				SharpDX.Direct2D1.Brush brushSupDemZoneCloudRed = Brushes.Red.ToDxBrush(RenderTarget);
				SharpDX.Direct2D1.Brush brushSupDemZoneCloudGreen = Brushes.Lime.ToDxBrush(RenderTarget);
				SharpDX.Direct2D1.Brush yellow = Brushes.Yellow.ToDxBrush(RenderTarget);
				SharpDX.Direct2D1.Brush textBrush = Brushes.Black.ToDxBrush(RenderTarget);

				SharpDX.DirectWrite.TextFormat textFormat = textFont.ToDirectWriteTextFormat();

				foreach (int key in Points.Keys) {
					if (!Points.ContainsKey(key - 1) ||
						!Points.ContainsKey(key - 2))
						continue;

					double point0_y = Points[key - 2];
					int point1_x = Indices[key - 1];
					double point1_y = Points[key - 1];
					int point2_x = Indices[key];
					double point2_y = Points[key];
					bool up = point2_y > point1_y;

					bool equal_peaks = point2_y == point0_y;
					bool positive_p = point2_y > point0_y;

					double price_dif = point2_y - point1_y;
					double cur_dif = Instrument.MasterInstrument.RoundToTickSize(price_dif);

					double volume = 0;

					for (int i = point1_x + 1; i <= point2_x; i++) {
						volume += Volumes[0].GetValueAt(i);
					}


					if (ChartBars.FromIndex <= point2_x && point2_x <= ChartBars.ToIndex) {
						//ZIGZAG
						float point2_x_f = chartControl.GetXByBarIndex(ChartBars, point2_x);
						float point2_y_f = chartScale.GetYByValue(point2_y);
						float point1_x_f = chartControl.GetXByBarIndex(ChartBars, point1_x);
						float point1_y_f = chartScale.GetYByValue(point1_y);

						SharpDX.Vector2 v1 = new SharpDX.Vector2(point1_x_f, point1_y_f);
						SharpDX.Vector2 v2 = new SharpDX.Vector2(point2_x_f, point2_y_f);

						SharpDX.Direct2D1.AntialiasMode mode = RenderTarget.AntialiasMode;
						RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

						RenderTarget.DrawLine(v1, v2, up ? brush1 : brush2, 2);

						//TEXT, ARROWS
						float cur_dif_y = chartScale.GetYByValue(up ? point2_y * (1 + Bubbleoffset) : point2_y * (1 - Bubbleoffset));
						float cur_dif_x = point2_x_f;


						DrawCurrencyDifferenceText(chartControl, chartScale, "$" + cur_dif.ToString(), (point2_x - point1_x).ToString(), "$" + point2_y.ToString(), volume.ToString(), textFormat, textBrush, cur_dif_x, cur_dif_y, !up,
						equal_peaks ? yellow : positive_p ? brush1 : brush2);

						if (key != direction_index && ShowArrows) {
							DrawArrow(!up, chartControl.GetXByBarIndex(ChartBars, point2_x + 1),
							chartScale.GetYByValue(up ? Highs[0].GetValueAt(point2_x + 1) + TickSize : Lows[0].GetValueAt(point2_x + 1) - TickSize), !up ? brush1 : brush2);
						}
					
					}

				}
				brush1.Dispose();
				brush2.Dispose();
				brushSupDemZoneCloudRed.Dispose();
				brushSupDemZoneCloudGreen.Dispose();
				textBrush.Dispose();
				textFormat.Dispose();
				yellow.Dispose();
			}
			catch (Exception e) {
				Print(e.Message);
				Print(e.StackTrace);
				Print("");
			}


		}




		private void DrawCurrencyDifferenceText(
			ChartControl chartControl, ChartScale chartScale, string change_text, string barCount_text, 
			string price_text, string volume, SharpDX.DirectWrite.TextFormat textFormat, 
			SharpDX.Direct2D1.Brush brush, float x, float y, bool up, SharpDX.Direct2D1.Brush brush2) 
		{
			SharpDX.DirectWrite.TextLayout changeTextLayout = CurrencyText(change_text, textFormat);
			SharpDX.DirectWrite.TextLayout barTextLayout = CurrencyText(barCount_text, textFormat);
			SharpDX.DirectWrite.TextLayout priceTextLayout = CurrencyText(price_text, textFormat);
			SharpDX.DirectWrite.TextLayout volTextLayout = CurrencyText(volume, textFormat);

			float text_x = 0;
			float change_text_y = 0;
			float bar_text_y = 0;
			float price_text_y = 0;
			float vol_text_y = 0;

			text_x = x;

			if (ShowBubbleschange) {
				change_text_y = up ? y + changeTextLayout.Metrics.Height * 1.3f : y - 15f - changeTextLayout.Metrics.Height * 1.3f;

				DrawCurrencyDifferenceFigure(x, y, up, brush2);
			}

			if (ShowBubblesprice) {
				if (ShowBubbleschange) {
					price_text_y = up ? change_text_y + changeTextLayout.Metrics.Height + 8f : change_text_y - changeTextLayout.Metrics.Height - 8f;
				}
				else {
					price_text_y = up ? y + changeTextLayout.Metrics.Height * 1.3f : y - 15f - changeTextLayout.Metrics.Height * 1.3f;

					DrawCurrencyDifferenceFigure(x, y, up, brush2);
				}
			}

			if (ShowBubblesBarsCount) {
				if (ShowBubblesprice) {
					bar_text_y = up ? price_text_y + changeTextLayout.Metrics.Height + 8f : price_text_y - changeTextLayout.Metrics.Height - 8f;
				}
				else if (!ShowBubblesprice && ShowBubbleschange) {
					bar_text_y = up ? change_text_y + changeTextLayout.Metrics.Height + 8f : change_text_y - changeTextLayout.Metrics.Height - 8f;
				}
				else {
					bar_text_y = up ? y + changeTextLayout.Metrics.Height * 1.3f : y - 15f - changeTextLayout.Metrics.Height * 1.3f;

					DrawCurrencyDifferenceFigure(x, y, up, brush2);
				}
			}

			if (ShowBubblesVolume) {
				if (ShowBubblesBarsCount) {
					vol_text_y = up ? bar_text_y + changeTextLayout.Metrics.Height + 8f : bar_text_y - changeTextLayout.Metrics.Height - 8f;
				}
				else if (ShowBubblesprice && !ShowBubblesBarsCount) {
					vol_text_y = up ? price_text_y + changeTextLayout.Metrics.Height + 8f : price_text_y - changeTextLayout.Metrics.Height - 8f;
				}
				else if (!ShowBubblesprice && !ShowBubblesBarsCount && ShowBubbleschange) {
					vol_text_y = up ? change_text_y + changeTextLayout.Metrics.Height + 8f : change_text_y - changeTextLayout.Metrics.Height - 8f;
				}
				else {
					vol_text_y = up ? y + changeTextLayout.Metrics.Height * 1.3f : y - 15f - changeTextLayout.Metrics.Height * 1.3f;

					DrawCurrencyDifferenceFigure(x, y, up, brush2);
				}
			}

			SharpDX.Vector2 change_vector = new SharpDX.Vector2(text_x - 5f, change_text_y);
			SharpDX.Vector2 price_vector = new SharpDX.Vector2(text_x - 5f, price_text_y);
			SharpDX.Vector2 bar_vector = new SharpDX.Vector2(text_x - 5f, bar_text_y);
			SharpDX.Vector2 vol_vector = new SharpDX.Vector2(text_x - 5f, vol_text_y);
			//			if(showBubblesprice)
			//			{
			//				
			//			}


			if (ShowBubbleschange) {
				DrawCurrencyDifferenceRectangle(x, change_text_y, changeTextLayout.Metrics.Width * 1.3f, changeTextLayout.Metrics.Height * 1.3f, up, brush2, changeTextLayout.Metrics.Height);
			}

			if (ShowBubblesprice) {
				DrawCurrencyDifferenceRectangle(x, price_text_y, priceTextLayout.Metrics.Width * 1.3f, priceTextLayout.Metrics.Height * 1.3f, up, brush2, changeTextLayout.Metrics.Height);
			}
			if (ShowBubblesBarsCount) {
				DrawCurrencyDifferenceRectangle(x, bar_text_y, barTextLayout.Metrics.Width * 1.3f, barTextLayout.Metrics.Height * 1.3f, up, brush2, changeTextLayout.Metrics.Height);
			}
			if (ShowBubblesVolume) {
				DrawCurrencyDifferenceRectangle(x, vol_text_y, volTextLayout.Metrics.Width * 1.3f, volTextLayout.Metrics.Height * 1.3f, up, brush2, changeTextLayout.Metrics.Height);
			}

			if (ShowBubbleschange) {
				RenderTarget.DrawTextLayout(change_vector, changeTextLayout, brush);
			}
			if (ShowBubblesprice) {
				RenderTarget.DrawTextLayout(price_vector, priceTextLayout, brush);
			}
			if (ShowBubblesBarsCount) {
				RenderTarget.DrawTextLayout(bar_vector, barTextLayout, brush);
			}
			if (ShowBubblesVolume) {
				RenderTarget.DrawTextLayout(vol_vector, volTextLayout, brush);
			}

		}


		private SharpDX.DirectWrite.TextLayout CurrencyText(string text, SharpDX.DirectWrite.TextFormat textFormat) {
			try {
				SharpDX.DirectWrite.TextLayout textLayout =
					new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory,
						text, textFormat, ChartPanel.X + ChartPanel.W,
						textFormat.FontSize);
				return textLayout;
			}
			catch (Exception e) {
				Print(e.Message);
				Print(e.StackTrace);
			}
			return null;
		}

		private void DrawCurrencyDifferenceRectangle(float x, float y, float width, float height, bool up, SharpDX.Direct2D1.Brush brush, float textSize) {
			//SharpDX.Direct2D1.PathGeometry pathGeometry	=	CurrencyTextFigure(x,y,width,height,up);
			//RenderTarget.FillGeometry(pathGeometry, brush);

			SharpDX.RectangleF rect = TextRectangle(x - 6f, y, width, height, up, textSize);
			RenderTarget.FillRectangle(rect, brush);

		}

		private void DrawCurrencyDifferenceFigure(float x, float y, bool up, SharpDX.Direct2D1.Brush brush) {
			SharpDX.Direct2D1.PathGeometry pathGeometry = CurrencyTextFigure(x, y, up);
			RenderTarget.FillGeometry(pathGeometry, brush);
		}

		private SharpDX.RectangleF TextRectangle(float x, float y, float width, float height, bool up, float textSize) {
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			return rect;
		}

		private SharpDX.Direct2D1.PathGeometry CurrencyTextFigure(float x, float y, bool up) {
			SharpDX.Direct2D1.PathGeometry pathGeo = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
			var figure = pathGeo.Open();

			float offset1 = 5f;
			float arrow_height = 17f;
			float arrow_width = 1f;

			if (up) {
				figure.BeginFigure(new SharpDX.Vector2(x, y), SharpDX.Direct2D1.FigureBegin.Filled);
				figure.AddLine(new SharpDX.Vector2(x + offset1, y + arrow_height));
				figure.AddLine(new SharpDX.Vector2(x - arrow_width, y + arrow_height));
				figure.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);

			}
			else {
				figure.BeginFigure(new SharpDX.Vector2(x, y), SharpDX.Direct2D1.FigureBegin.Filled);
				figure.AddLine(new SharpDX.Vector2(x + offset1, y - arrow_height));
				figure.AddLine(new SharpDX.Vector2(x - arrow_width, y - arrow_height));
				figure.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);

			}

			figure.Close();
			return (pathGeo);
		}

		private SharpDX.Direct2D1.PathGeometry Arrow(bool up, float w, float h, float x, float y) {
			SharpDX.Direct2D1.PathGeometry pathGeo = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
			var arrow = pathGeo.Open();

			if (up) {
				arrow.BeginFigure(new SharpDX.Vector2(x, y), SharpDX.Direct2D1.FigureBegin.Filled);
				arrow.AddLine(new SharpDX.Vector2(x - w / 2f, y + h / 2f));
				arrow.AddLine(new SharpDX.Vector2(x - w / 4f, y + h / 2f));
				arrow.AddLine(new SharpDX.Vector2(x - w / 4f, y + h));
				arrow.AddLine(new SharpDX.Vector2(x + w / 4f, y + h));
				arrow.AddLine(new SharpDX.Vector2(x + w / 4f, y + h / 2f));
				arrow.AddLine(new SharpDX.Vector2(x + w / 2f, y + h / 2f));
				arrow.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);

			}
			else {
				arrow.BeginFigure(new SharpDX.Vector2(x, y), SharpDX.Direct2D1.FigureBegin.Filled);
				arrow.AddLine(new SharpDX.Vector2(x - w / 2f, y - h / 2f));
				arrow.AddLine(new SharpDX.Vector2(x - w / 4f, y - h / 2f));
				arrow.AddLine(new SharpDX.Vector2(x - w / 4f, y - h));
				arrow.AddLine(new SharpDX.Vector2(x + w / 4f, y - h));
				arrow.AddLine(new SharpDX.Vector2(x + w / 4f, y - h / 2f));
				arrow.AddLine(new SharpDX.Vector2(x + w / 2f, y - h / 2f));
				arrow.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);

			}
			arrow.Close();
			return (pathGeo);
		}

		private void DrawArrow(bool up, float x, float y, SharpDX.Direct2D1.Brush brush) {
			SharpDX.Direct2D1.PathGeometry arrow = Arrow(up, 15, 25, x, y);

			RenderTarget.FillGeometry(arrow, brush);
		}




		private int linewidth = 1;
		private int trend;      // confirmed trend of current zigzag, 1=up, -1=down
		private int lhb;        // last high bar count of last swing high (bars ago = CurrentBar-lhb)
		private int prev_lhb;
		private int uplineid;   // last used up line (name) id
		private int llb;        // last low bar count of last swing low (bars ago = CurrentBar-llb)
		private int prev_llb;
		private int downlineid; // last used down line name
		private double hh;          // New Higher high
		private double prev_hh;
		private double ll;          // New lower low
		private double prev_ll;

		private double HLPivot; // The high-low pivot level switch
								//private Indicator ind;
		private Series<double> output;


		public int upBar;// { get; set; }
		public int dnBar;// { get; set; }

		private Series<double> output2;

		public int direction_index;// { get; set; }
		public int upBar2;// { get; set; }
		public int dnBar2;// { get; set; }

		private Dictionary<int, double> Points;
		private Dictionary<int, int> Indices;// { get; set; }
		public Dictionary<int, int> getIndices() {
			return Indices;
        }

		private Series<double> maxPriceH;
		private Series<double> minPriceL;
		private Series<double> state;

		public bool confirmed = false;
		public bool confirmed_prv = false;


		//public Zigzag(Indicator ind) {

		//}

		public int GetCurrentTrend() {
			return trend;
		}

		public double GetHLPivot() {
			return HLPivot;
		}

		//public double GetLastDif() {
		//	return direction_index > 1 ? ind.Instrument.MasterInstrument.RoundToTickSize(Points[direction_index] - Points[direction_index - 1]) : 0;
		//}

		public void ZigZagUpdate(int CurrentBar,
			ISeries<double> PriceH, ISeries<double> PriceL, double ZZPercent, double absoluteReversal, int ATRPeriod, double ATRFactor, int tickReversal, double atr, double close0) {

			try {
				if (CurrentBar < 1) // minimum 2 bars required
				{
					ll = PriceL[0];
					hh = PriceH[0];
					llb = lhb = 0;
					return;
				}
				if (CurrentBar < 2) // trend start based on bar 2
				{
					if (PriceH[0] >= hh) {
						hh = PriceH[0];
						lhb = 1;
						trend = 1;
					}
					else {
						ll = PriceL[0];
						llb = 1;
						trend = -1;
					}
					uplineid = downlineid = CurrentBar;
				}

				// ATR factor = 0, only use percent setting
				if (ATRFactor == 0)
					HLPivot = (ZZPercent / 100.0);
				// Zigzag percent = 0, only use ATR
				else if (ZZPercent == 0)
					HLPivot = atr / close0 * ATRFactor;
				// Use both influences
				else HLPivot = ZZPercent / 100.0 + atr / close0 * ATRFactor;

				double absReversal;
				if (absoluteReversal != 0) {
					absReversal = absoluteReversal;
				}
				else {
					absReversal = tickReversal * TickSize;// ind.TickSize;
				}

				// --------------------------------------------------------------------------------
				// look for swing points and draw lines
				// trend is up, look for new swing low
				if (trend > 0 ||
					(llb == CurrentBar && !(PriceL[0] < hh - hh * HLPivot - absReversal)) ||
					!confirmed) {

					if (PriceH[0] >= hh) {


						// new higher high detected
						hh = PriceH[0];
						lhb = CurrentBar;


						//prev high trend was continued
						if (((llb == CurrentBar && !(PriceL[0] < hh - hh * HLPivot - absReversal)) && confirmed && trend < 0) ||
							(!confirmed && trend < 0)) {
							ll = prev_ll;
							llb = prev_llb;
							trend = 1;

							Points.Remove(direction_index);
							Indices.Remove(direction_index);
							direction_index--;

						}

						if (trend > 0) {
							//approach2
							upBar2 = CurrentBar;

							//approach3
							Points[direction_index] = PriceH[0];
							Indices[direction_index] = CurrentBar;

							if (PriceH[0] > ll + ll * HLPivot + absReversal && !confirmed) {
								confirmed = true;
							}
						}


						//						ind.Print(ind.Time[0] + "new higher high detected " + "Confirmed = "+confirmed + "trend = "+trend);
					}

					else if (PriceL[0] < hh - hh * HLPivot - absReversal && confirmed) {


						// found a swing low
						prev_ll = ll;
						prev_llb = llb;
						ll = PriceL[0];
						llb = CurrentBar;
						downlineid = CurrentBar;
						trend = -1;

						//approach1
						output[0] = 1;
						upBar = lhb;


						//approach2
						direction_index++;
						dnBar2 = llb;

						//approach3
						Points.Add(direction_index, PriceL[0]);
						Indices.Add(direction_index, CurrentBar);

						confirmed = true;

						//						ind.Print(ind.Time[0] + "Low was broken. New Down Trend. Confirmed = true ");
					}

					else if (PriceH[0] < hh && confirmed) {
						trend = -1;
						confirmed = false;

						prev_ll = ll;
						prev_llb = llb;
						ll = PriceL[0];
						llb = CurrentBar;

						direction_index++;

						Points.Add(direction_index, PriceL[0]);
						Indices.Add(direction_index, CurrentBar);

						//						ind.Print(ind.Time[0] + "Unconfirmed Down Trend. Confirmed = false ");
					}

					else if (trend > 0 && !confirmed) {
						Points[direction_index] = PriceH[0];
						Indices[direction_index] = CurrentBar;
					}
				}

				// else trend is down, look for new swing high
				if (trend < 0 ||
					(lhb == CurrentBar && !(PriceH[0] > ll + ll * HLPivot + absReversal)) ||
					!confirmed) {



					if (PriceL[0] <= ll) {

						// new lower low detected
						ll = PriceL[0];
						llb = CurrentBar;



						//prev high trend was continued
						if ((lhb == CurrentBar && !(PriceH[0] > ll - ll * HLPivot + absReversal) && confirmed) ||
							(!confirmed && trend > 0)) {
							hh = prev_hh;
							lhb = prev_lhb;
							trend = -1;

							Points.Remove(direction_index);
							Indices.Remove(direction_index);
							direction_index--;
						}


						if (trend < 0) {
							//approach2
							dnBar2 = CurrentBar;


							//approach3

							Points[direction_index] = PriceL[0];
							Indices[direction_index] = CurrentBar;


							if (PriceL[0] < hh - hh * HLPivot - absReversal && !confirmed) {
								confirmed = true;
							}
						}

						//						ind.Print(ind.Time[0] + "new lower low detected " + "Confirmed = "+confirmed + "trend = "+trend);

					}
					else if (PriceH[0] > ll + ll * HLPivot + absReversal && confirmed) {

						// found a swing high
						prev_hh = hh;
						prev_lhb = lhb;
						hh = PriceH[0];
						lhb = CurrentBar;
						uplineid = CurrentBar;
						trend = 1;

						//approach1
						output[0] = -1;
						dnBar = llb;


						//approach2
						direction_index++;
						upBar2 = lhb;

						//approach3
						Points.Add(direction_index, PriceH[0]);
						Indices.Add(direction_index, CurrentBar);

						confirmed = true;

						//						ind.Print(ind.Time[0] + "High was broken. New Up Trend. Confirmed = true ");
					}

					else if (PriceL[0] > ll && confirmed) {
						trend = 1;
						confirmed = false;

						prev_hh = hh;
						prev_lhb = lhb;
						hh = PriceH[0];
						lhb = CurrentBar;

						direction_index++;

						Points.Add(direction_index, PriceH[0]);
						Indices.Add(direction_index, CurrentBar);

						//						ind.Print(ind.Time[0] + "Unconfirmed Up Trend. Confirmed = false ");
					}
					else if (trend < 0 && !confirmed) {
						Points[direction_index] = PriceL[0];
						Indices[direction_index] = CurrentBar;
					}

				}
				//All logic above is from the original zig zag class and is not touched by me!!!
				//All code below is coded by me in order not to interact with the original logic!!!
				//Part of the logic might be better to be in the code above (in order the code to be more understandable)
				//But is left to be below in order there not to be any interaction between me and the original reverse engineered original class logic which was converted to indicator


				//All below is my code - added by me - VTS(KStds)
				//confirmed_prv = confirmed;








				#region commented region in the original sup dem wrong indicator where the zig zag is a class (very wrong approach) that is fixed in this indicator to be stand alone like it has to be!
				//				state[0]	=	0;

				//				bool newMax;
				//				bool newMin;

				//				double prevMaxH	=	maxPriceH[1];
				//				double prevMinL	=	minPriceL[1];

				//				if(state[1] == 0)
				//				{
				//					maxPriceH 	=	PriceH[0];
				//					minPriceL	=	PriceL[0];	
				//					newMax		=	true;
				//					newMin		=	true;
				//					state[0]	=	1;
				//				}
				//				else if(state[1] == 1)
				//				{
				//					if(PriceH[0] >= prevMaxH)
				//					{
				//						state[0] = 2;
				//						maxPriceH[0] 	=	PriceH[0];
				//						minPriceL[0]	=	prevMinL;
				//						newMax			=	true;
				//						newMin			=	false;
				//					}
				//					else if(PriceL[0] <= prevMinL)
				//					{
				//						state[0]		=	3;
				//						maxPriceH[0] 	= 	prevMaxH;
				//						minPriceL[0] 	= 	PriceL[0];
				//						newMax			=	false;
				//						newMin			=	true;
				//					}
				//					else
				//					{
				//						state[0]		=	1;
				//						maxPriceH[0]	=	prevMaxH;
				//						minPriceL[0]	=	prevMinL;
				//						newMax			=	false;
				//						newMin			=	false;
				//					}

				//				}
				//				else if(state[1] == 2)
				//				{
				//					if(PriceL[0] <= prevMaxH - prevMaxH * hlPivot - absReversal)
				//					{
				//						state			=	3;
				//						maxPriceH[0]	=	prevMaxH;
				//						minPriceL[0]	=	PriceL;
				//						newMax			=	false;
				//						newMin			=	true;

				//					}
				//					else
				//					{
				//						state			=	2;
				//						if(PriceH[0] 	>= prevMaxH)
				//						{
				//							maxPriceH[0] 	= PriceH[0];
				//							newMax			=	true;
				//						}
				//						else
				//						{
				//							maxPriceH[0]	=	prevMaxH;
				//							newMax			=	false;
				//						}
				//						minPriceL[0]	=	prevMinL;
				//						newMin			=	false;
				//					}
				//				}
				//				else
				//				{
				//					if(PriceH[0] >= prevMinL + prevMinL * hlPivot + absReversal)
				//					{
				//						state[0]		=	2;
				//						maxPriceH[0]	=	PriceH[0];
				//						minPriceL[0]	=	prevMinL;
				//						newMax			=	true;
				//						newMin			=	false;
				//					}
				//					else
				//					{
				//						state 			=	3;
				//						maxPriceH[0]	=	prevMaxH;
				//						newMax			=	false;
				//						if(PriceL[0] < prevMinL)
				//						{
				//							minPriceL[0] 	= PriceL[0];
				//							newMin			=	true;
				//						}
				//						else
				//						{
				//							minPriceL[0]	=	prevMinL;
				//							newMin			=	false;
				//						}
				//					}
				//				}
				#endregion
			}
            catch (Exception e) {
				Print(e.Message);
				Print(e.StackTrace);
			}
		}








	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private KomepcStudios.KomepcStudios_ZigZagCleanMod[] cacheKomepcStudios_ZigZagCleanMod;
		public KomepcStudios.KomepcStudios_ZigZagCleanMod KomepcStudios_ZigZagCleanMod(double bubbleoffset, double percentamount, double revAmount, double atrreversal, int atrlength, bool showBubbleschange, bool showBubblesprice, bool showBubblesBarsCount, bool showArrows, bool showBubblesVolume)
		{
			return KomepcStudios_ZigZagCleanMod(Input, bubbleoffset, percentamount, revAmount, atrreversal, atrlength, showBubbleschange, showBubblesprice, showBubblesBarsCount, showArrows, showBubblesVolume);
		}

		public KomepcStudios.KomepcStudios_ZigZagCleanMod KomepcStudios_ZigZagCleanMod(ISeries<double> input, double bubbleoffset, double percentamount, double revAmount, double atrreversal, int atrlength, bool showBubbleschange, bool showBubblesprice, bool showBubblesBarsCount, bool showArrows, bool showBubblesVolume)
		{
			if (cacheKomepcStudios_ZigZagCleanMod != null)
				for (int idx = 0; idx < cacheKomepcStudios_ZigZagCleanMod.Length; idx++)
					if (cacheKomepcStudios_ZigZagCleanMod[idx] != null && cacheKomepcStudios_ZigZagCleanMod[idx].Bubbleoffset == bubbleoffset && cacheKomepcStudios_ZigZagCleanMod[idx].Percentamount == percentamount && cacheKomepcStudios_ZigZagCleanMod[idx].RevAmount == revAmount && cacheKomepcStudios_ZigZagCleanMod[idx].Atrreversal == atrreversal && cacheKomepcStudios_ZigZagCleanMod[idx].Atrlength == atrlength && cacheKomepcStudios_ZigZagCleanMod[idx].ShowBubbleschange == showBubbleschange && cacheKomepcStudios_ZigZagCleanMod[idx].ShowBubblesprice == showBubblesprice && cacheKomepcStudios_ZigZagCleanMod[idx].ShowBubblesBarsCount == showBubblesBarsCount && cacheKomepcStudios_ZigZagCleanMod[idx].ShowArrows == showArrows && cacheKomepcStudios_ZigZagCleanMod[idx].ShowBubblesVolume == showBubblesVolume && cacheKomepcStudios_ZigZagCleanMod[idx].EqualsInput(input))
						return cacheKomepcStudios_ZigZagCleanMod[idx];
			return CacheIndicator<KomepcStudios.KomepcStudios_ZigZagCleanMod>(new KomepcStudios.KomepcStudios_ZigZagCleanMod(){ Bubbleoffset = bubbleoffset, Percentamount = percentamount, RevAmount = revAmount, Atrreversal = atrreversal, Atrlength = atrlength, ShowBubbleschange = showBubbleschange, ShowBubblesprice = showBubblesprice, ShowBubblesBarsCount = showBubblesBarsCount, ShowArrows = showArrows, ShowBubblesVolume = showBubblesVolume }, input, ref cacheKomepcStudios_ZigZagCleanMod);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.KomepcStudios.KomepcStudios_ZigZagCleanMod KomepcStudios_ZigZagCleanMod(double bubbleoffset, double percentamount, double revAmount, double atrreversal, int atrlength, bool showBubbleschange, bool showBubblesprice, bool showBubblesBarsCount, bool showArrows, bool showBubblesVolume)
		{
			return indicator.KomepcStudios_ZigZagCleanMod(Input, bubbleoffset, percentamount, revAmount, atrreversal, atrlength, showBubbleschange, showBubblesprice, showBubblesBarsCount, showArrows, showBubblesVolume);
		}

		public Indicators.KomepcStudios.KomepcStudios_ZigZagCleanMod KomepcStudios_ZigZagCleanMod(ISeries<double> input , double bubbleoffset, double percentamount, double revAmount, double atrreversal, int atrlength, bool showBubbleschange, bool showBubblesprice, bool showBubblesBarsCount, bool showArrows, bool showBubblesVolume)
		{
			return indicator.KomepcStudios_ZigZagCleanMod(input, bubbleoffset, percentamount, revAmount, atrreversal, atrlength, showBubbleschange, showBubblesprice, showBubblesBarsCount, showArrows, showBubblesVolume);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.KomepcStudios.KomepcStudios_ZigZagCleanMod KomepcStudios_ZigZagCleanMod(double bubbleoffset, double percentamount, double revAmount, double atrreversal, int atrlength, bool showBubbleschange, bool showBubblesprice, bool showBubblesBarsCount, bool showArrows, bool showBubblesVolume)
		{
			return indicator.KomepcStudios_ZigZagCleanMod(Input, bubbleoffset, percentamount, revAmount, atrreversal, atrlength, showBubbleschange, showBubblesprice, showBubblesBarsCount, showArrows, showBubblesVolume);
		}

		public Indicators.KomepcStudios.KomepcStudios_ZigZagCleanMod KomepcStudios_ZigZagCleanMod(ISeries<double> input , double bubbleoffset, double percentamount, double revAmount, double atrreversal, int atrlength, bool showBubbleschange, bool showBubblesprice, bool showBubblesBarsCount, bool showArrows, bool showBubblesVolume)
		{
			return indicator.KomepcStudios_ZigZagCleanMod(input, bubbleoffset, percentamount, revAmount, atrreversal, atrlength, showBubbleschange, showBubblesprice, showBubblesBarsCount, showArrows, showBubblesVolume);
		}
	}
}

#endregion
