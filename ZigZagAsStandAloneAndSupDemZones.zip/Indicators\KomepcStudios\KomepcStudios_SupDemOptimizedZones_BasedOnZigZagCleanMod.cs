#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Custom.Indicators.KomepcStudios;
#endregion

/*
 * 
 * 1.	ASK ALEX (the question was discussed but was before maybe almost 2 months)
 *			When the curernt active naked validated zone becomes invalidated, the system looks back and 
 *		searches for the older youngest still valid and still naked zone back in the time
 *			A zone that was created far away back in the time might become the current active zone 
 *		as long as it is with the same color as the zone that was fully invalidated just now
 *    
 * 2.	ASK ALEX:
 *		Once the validation bar is reached it classifies the zone as valid.
 *		It does not waits the validation bar to become prior bar?
 *
 * 3.	The zone starts from bar Number 0 - this has to be pointed to Alex
 *		If the zone is with 3 bars at the moment its right side bar is in fact bar Number 2!!!
 *		
 *	
 *    
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */


//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.KomepcStudios
{
	public class KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod : Indicator
	{
		protected override void OnStateChange()
		{
			try {
				if (State == State.SetDefaults) {
					Description = @"Enter the description for your new custom Indicator here.";
					Name = "Sup Dem Zones (Zig Zag Clean Mod Based) by KomepcStudios";
					Calculate = Calculate.OnBarClose;
					IsOverlay = true;
					DisplayInDataBox = true;
					DrawOnPricePanel = true;
					DrawHorizontalGridLines = true;
					DrawVerticalGridLines = true;
					PaintPriceMarkers = true;
					ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
					IsSuspendedWhileInactive = false;
					#region Zig Zag Params
					bubbleoffset = .0005;
					percentamount = .01;
					revAmount = .15;
					atrreversal = 1.0;
					atrlength = 5;
					showBubbleschange = false;
					showBubblesprice = false;
					showBubblesBarsCount = false;
					showArrows = false;
					//The commented variables are/were from the SupDem main indicator which infact was/is extension of the zig zag
					//The sup dem zones indicator was containing the zig zag indicator inside itself as a class which is awful approach
					//With this indicator )Komepc Studios version) the Zig Zag indicator is turned to be a real stand alone indicator
					//Stand alone indicator like any other normal indicator - this is the way it should be! :-)
					//usealerts = false;
					//numbersuppdemandtoshow = 2;
					//numberextfibstoshow = 2;
					//showFibExtLines = true;
					//showtodayonly = false;
					//showSupplyDemand = CustomEnumNamespace.showSupplyDemandEnum.Pivot;
					//showSupplyDemandCloud = true;
					//fibextbubblespacesinexpansion = 8;
					showbubblesvolume = false;
					#endregion

					invalidationType = INVALIDATION_TYPE.ON_TOUCH;
					minusBarsBack = 1;
					drawNakedsOnly = false;
					multiplyTheZoneLinesBy = 1;
				}
				else if (State == State.Configure) {

				}
				else if (State == State.DataLoaded) {
					zigZagCleanMod = KomepcStudios_ZigZagCleanMod(Input, bubbleoffset, percentamount, revAmount, atrreversal, atrlength, showBubbleschange, showBubblesprice, showBubblesBarsCount, showArrows, showbubblesvolume);

					if (true) {
						chartTab = ChartControl.ChartTab;
						chart = ChartControl.OwnerChart;

						//if (CurrentBar == 0)
						for (int index = 0; index < ChartControl.Indicators.Count; index++) {
							Gui.NinjaScript.IndicatorRenderBase indi = ChartControl.Indicators[index];
							NinjaTrader.NinjaScript.Indicators.Indicator indiB = (Indicator)indi;
							if (this.Equals(indiB)) {
								Print("ChartControl.Indicators " + "[" + index.ToString() + "] is " + ChartControl.Indicators[index].Name + " (which is the instance that is printing this line :-)");
							}
							else
								Print("ChartControl.Indicators " + "[" + index.ToString() + "] is " + ChartControl.Indicators[index].Name);

							indiB = null;
						}

						//chartWindow = System.Windows.Window.GetWindow(ChartControl.Parent) as Chart;

						//foreach (System.Windows.DependencyObject item in chartWindow.MainMenu) {
						//    //if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == "ChartToolbarExampleMenu")
						//    //	return;
						//    int t = 0;
						//    t = 1;
						//}
					}


				}
				else if (State == State.Historical) {
					ChartControl.Dispatcher.InvokeAsync(() => {
						timer = new System.Windows.Threading.DispatcherTimer { Interval = new TimeSpan(0, 0, 0, 0, 200), IsEnabled = true };
						timer.Tick += OnTimerTick;
					});
				}
			}
			catch (Exception e) {
				Print(e.Message);
				Print(e.StackTrace);
			}
		}
		#region Visuals Forced Refresh even if the replay is on pause or the connection is out of trading hours and there is no data tick coming to the platform
		private void OnTimerTick(object sender, EventArgs e) {
			ForceRefresh();

			if (RefreshAnimationsCanCallThemSemiAnimationsJustBlinks()) {
				

			}


		}

		private bool RefreshAnimationsCanCallThemSemiAnimationsJustBlinks() {
			return ChartControl != null
					&& Bars != null
					&& Bars.Instrument.MarketData != null
					&& IsVisible;
		}
		#endregion

		private System.Windows.Threading.DispatcherTimer timer;

		KomepcStudios_ZigZagCleanMod zigZagCleanMod;
		int zigzag_direction_index_prv = 0;
		SupplyDemandKomepcUltraZone current_lastZoneOfAnyTypeIncludingAboutToBeRemovedZones;
		SupplyDemandKomepcUltraZone previous_lastZoneOfAnyTypeIncludingAboutToBeRemovedZones;
		Boolean atLeastOneZoneAlreadCyreated = false;

		private NinjaTrader.Gui.Chart.ChartTab chartTab;
		private NinjaTrader.Gui.Chart.Chart chart;
		protected override void OnBarUpdate()
		{
			try {

				

				zigZagCleanMod.Update();
				SupplyDemandKomepcUltraZone theNewZone = null;
				//if (zigZagCleanMod.confirmed && !zigZagCleanMod.confirmed_prv) {
				if (this.IsFirstTickOfBar /*&& State == State.Realtime*/ && zigzag_direction_index_prv != 0) {

					if (zigZagCleanMod.direction_index > zigzag_direction_index_prv && zigZagCleanMod.confirmed) {
						theNewZone = CreateNewZoneAndInitializeItByCallingTheZoneOnBarUpdateMethod();
						
						//Commented, the newes zone is the youngest but is not the current active validated zone
						//The current zones are the ones which passed the validation bar and are still naked!!!
						//theNewZone.ultra_isCurrent = true;

						//Add the new zone to the map wi
						//Bar is created one bar back, check will it work for ticks, possibly it will not
						//                                                     vvv CurrentBar - 1 vvv
						if (!supplyDemandKomepcAllUltraZones.ContainsKey(/*CurrentBar - 1 is same as*/theNewZone.ultra_creation_start_bar_index_used_also_as_dictionary_key_externally_to_the_class)) {
							supplyDemandKomepcAllUltraZones.Add(/*CurrentBar - 1 is same as*/theNewZone.ultra_creation_start_bar_index_used_also_as_dictionary_key_externally_to_the_class, theNewZone);
							Print("Adding");
						}
						else { 
							supplyDemandKomepcAllUltraZones[/*CurrentBar - 1 is same as*/theNewZone.ultra_creation_start_bar_index_used_also_as_dictionary_key_externally_to_the_class] = theNewZone;
							Print("Updating");
						}
						previous_lastZoneOfAnyTypeIncludingAboutToBeRemovedZones = current_lastZoneOfAnyTypeIncludingAboutToBeRemovedZones;
						current_lastZoneOfAnyTypeIncludingAboutToBeRemovedZones = theNewZone;
						atLeastOneZoneAlreadCyreated = true;
					}
					else if(atLeastOneZoneAlreadCyreated && zigZagCleanMod.direction_index < zigzag_direction_index_prv) {
						Print("Deleting/Removing  ");
						current_lastZoneOfAnyTypeIncludingAboutToBeRemovedZones = previous_lastZoneOfAnyTypeIncludingAboutToBeRemovedZones;
						supplyDemandKomepcAllUltraZones.Remove(current_lastZoneOfAnyTypeIncludingAboutToBeRemovedZones.ultra_creation_start_bar_index_used_also_as_dictionary_key_externally_to_the_class);

						
						//Be very careful:
						//CurrentBar - 1 is used here, but is also used inside the class of the kmpc zone
						//Here and there the same displacement has to be use
					}
				}
				zigzag_direction_index_prv = zigZagCleanMod.direction_index;
				zigZagCleanMod.confirmed_prv = zigZagCleanMod.confirmed;

				//A lot of optimization for faster processing can be made - create maps for valid, for non valid, for invalidated for non invalidated zones...
				if (IsFirstTickOfBar) {
					List<int> keysWhichAreBarIndexes = supplyDemandKomepcAllUltraZones.Keys.ToList();
					keysWhichAreBarIndexes.Sort();
					keysWhichAreBarIndexes.Reverse();
					bool cRedValidZoneDetected = false;
					bool cGreenValidZoneDetected = false;
					foreach (int keyWhichIsStartBarIndex in keysWhichAreBarIndexes) {
						SupplyDemandKomepcUltraZone ultraZone = supplyDemandKomepcAllUltraZones[keyWhichIsStartBarIndex];
						ultraZone.OnBarUpdate();
					}
					foreach (int keyWhichIsStartBarIndex in keysWhichAreBarIndexes) {
						SupplyDemandKomepcUltraZone ultraZone = supplyDemandKomepcAllUltraZones[keyWhichIsStartBarIndex];

						//Just an experiment, absolutely not needed, it was for a test, but is left here commented in order to remember the concept of the approach
						//if(ultraZone.ultra_isCurrent 
						//	&& ultraZone.ultra_zone_direction_color_type == theNewZone.ultra_zone_direction_color_type
						//	&& ultraZone != theNewZone) {
						//	ultraZone.ultra_isCurrent = false;
						//}
						
						if (ultraZone.ultra_calc_ZONE_IS_VALID) {
							if (ultraZone.ultra_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.RED) {
								if (!cRedValidZoneDetected) {
									cRedValidZoneDetected = true;
									ultraZone.ultra_isCurrentYoungestValidNakedZoneForThisZoneColorDirection = true;
								}
								else if (cRedValidZoneDetected) {
									ultraZone.ultra_isCurrentYoungestValidNakedZoneForThisZoneColorDirection = false;
								}
							}
							else if (ultraZone.ultra_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.GREEN) {
								if (!cGreenValidZoneDetected) {
									cGreenValidZoneDetected = true;
									ultraZone.ultra_isCurrentYoungestValidNakedZoneForThisZoneColorDirection = true;
								}
								else if (cGreenValidZoneDetected) {
									ultraZone.ultra_isCurrentYoungestValidNakedZoneForThisZoneColorDirection = false;
								}
							}

						}
					}
				}
			}
			catch (Exception e) {
				Print(e.Message);
				Print(e.StackTrace);
			}
		}
		private Dictionary<int, SupplyDemandKomepcUltraZone> supplyDemandKomepcAllUltraZones = new Dictionary<int, SupplyDemandKomepcUltraZone>();
		public SupplyDemandKomepcUltraZone CreateNewZoneAndInitializeItByCallingTheZoneOnBarUpdateMethod() {
			ZONE_DIRECTION_COLOR_TYPE zoneType = ZONE_DIRECTION_COLOR_TYPE.RED;
			if (zigZagCleanMod.GetCurrentTrend() == 1)
				zoneType = ZONE_DIRECTION_COLOR_TYPE.GREEN;
			//Valid at 5th bar is hardcoded for now!!!
			//Zone high and zone low is here as parameter in the constructor because the parent indicator (in this case this sup dem indicator)
			//The parent indicator can have a zone extension parameter (in ticks) this is why the zone high and low is not created inside the constructor of the ultra zone class/object
			int StartBarForwardedCorrectFinally = zigZagCleanMod.getIndices()[zigZagCleanMod.direction_index - 1];
			double zoneHigh = High[CurrentBar - StartBarForwardedCorrectFinally];
			double zoneLow = Low[CurrentBar - StartBarForwardedCorrectFinally];
			if (Calculate != Calculate.OnBarClose) {
				if (IsFirstTickOfBar) {
					zoneHigh = High[CurrentBar - StartBarForwardedCorrectFinally + 1];
					zoneLow = Low[CurrentBar - StartBarForwardedCorrectFinally + 1];
				}
			}
			SupplyDemandKomepcUltraZone cSupplyDemandKomepcUltraZone = new SupplyDemandKomepcUltraZone(this, StartBarForwardedCorrectFinally, minusBarsBack, zoneHigh, zoneLow, zoneType, invalidationType, 5);
			
			cSupplyDemandKomepcUltraZone.OnBarUpdate();
			return cSupplyDemandKomepcUltraZone;
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale) {
			try { 
				base.OnRender(chartControl, chartScale);
				zigZagCleanMod.OnRenderHack(chartControl, chartScale, RenderTarget, ChartBars, ChartPanel);
				//komepcStudios_ZigZagCleanMod.OnRenderTargetChanged();

				foreach (int key in supplyDemandKomepcAllUltraZones.Keys) {
					SupplyDemandKomepcUltraZone ultraZone = supplyDemandKomepcAllUltraZones[key];
					ultraZone.OnRender(chartControl, chartScale, ChartBars, drawNakedsOnly);
				}
			}
			catch (Exception e) {
				Print(e.Message);
				Print(e.StackTrace);
			}
		}

		


		[NinjaScriptProperty]
		[Display(Name = "Invalidation Type", Order = 0, GroupName = "Zone Parameters")]
		public INVALIDATION_TYPE invalidationType { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "(Not used at the moment, I test with OnBarClose only) Zone Starting X Bars Back ", Order = 1, GroupName = "Zone Parameters")]
		public int minusBarsBack { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Draw Only Naked Zones", Order = 2, GroupName = "Zone Parameters")]
		public bool drawNakedsOnly { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Zone Lines Ticknes Multiplier", Order = 3, GroupName = "Zone Parameters")]
		public int multiplyTheZoneLinesBy { get; set; }

		#region Zig Zag Parameters

		[NinjaScriptProperty]
		[Display(Name = "bubbleoffset", Order = 1, GroupName = "ZigZag Parameters")]
		public double bubbleoffset { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "percentamount", Order = 2, GroupName = "ZigZag Parameters")]
		public double percentamount { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "revAmount", Order = 3, GroupName = "ZigZag Parameters")]
		public double revAmount { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "atrreversal", Order = 4, GroupName = "ZigZag Parameters")]
		public double atrreversal { get; set; }


		[NinjaScriptProperty]
		[Display(Name = "atrlength", Order = 5, GroupName = "ZigZag Parameters")]
		public int atrlength { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "showBubbleschange", Order = 6, GroupName = "ZigZag Parameters")]
		public bool showBubbleschange { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "showBubblesprice", Order = 7, GroupName = "ZigZag Parameters")]
		public bool showBubblesprice { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "showBubblesBarsCount", Order = 8, GroupName = "ZigZag Parameters")]
		public bool showBubblesBarsCount { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "showArrows", Order = 9, GroupName = "ZigZag Parameters")]
		public bool showArrows { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "showbubblesvolume", Order = 18, GroupName = "ZigZag Parameters")]
		public bool showbubblesvolume { get; set; }


		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private KomepcStudios.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[] cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod;
		public KomepcStudios.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod(INVALIDATION_TYPE invalidationType, int minusBarsBack, bool drawNakedsOnly, int multiplyTheZoneLinesBy, double bubbleoffset, double percentamount, double revAmount, double atrreversal, int atrlength, bool showBubbleschange, bool showBubblesprice, bool showBubblesBarsCount, bool showArrows, bool showbubblesvolume)
		{
			return KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod(Input, invalidationType, minusBarsBack, drawNakedsOnly, multiplyTheZoneLinesBy, bubbleoffset, percentamount, revAmount, atrreversal, atrlength, showBubbleschange, showBubblesprice, showBubblesBarsCount, showArrows, showbubblesvolume);
		}

		public KomepcStudios.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod(ISeries<double> input, INVALIDATION_TYPE invalidationType, int minusBarsBack, bool drawNakedsOnly, int multiplyTheZoneLinesBy, double bubbleoffset, double percentamount, double revAmount, double atrreversal, int atrlength, bool showBubbleschange, bool showBubblesprice, bool showBubblesBarsCount, bool showArrows, bool showbubblesvolume)
		{
			if (cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod != null)
				for (int idx = 0; idx < cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod.Length; idx++)
					if (cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx] != null && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].invalidationType == invalidationType && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].minusBarsBack == minusBarsBack && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].drawNakedsOnly == drawNakedsOnly && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].multiplyTheZoneLinesBy == multiplyTheZoneLinesBy && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].bubbleoffset == bubbleoffset && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].percentamount == percentamount && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].revAmount == revAmount && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].atrreversal == atrreversal && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].atrlength == atrlength && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].showBubbleschange == showBubbleschange && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].showBubblesprice == showBubblesprice && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].showBubblesBarsCount == showBubblesBarsCount && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].showArrows == showArrows && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].showbubblesvolume == showbubblesvolume && cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx].EqualsInput(input))
						return cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod[idx];
			return CacheIndicator<KomepcStudios.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod>(new KomepcStudios.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod(){ invalidationType = invalidationType, minusBarsBack = minusBarsBack, drawNakedsOnly = drawNakedsOnly, multiplyTheZoneLinesBy = multiplyTheZoneLinesBy, bubbleoffset = bubbleoffset, percentamount = percentamount, revAmount = revAmount, atrreversal = atrreversal, atrlength = atrlength, showBubbleschange = showBubbleschange, showBubblesprice = showBubblesprice, showBubblesBarsCount = showBubblesBarsCount, showArrows = showArrows, showbubblesvolume = showbubblesvolume }, input, ref cacheKomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.KomepcStudios.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod(INVALIDATION_TYPE invalidationType, int minusBarsBack, bool drawNakedsOnly, int multiplyTheZoneLinesBy, double bubbleoffset, double percentamount, double revAmount, double atrreversal, int atrlength, bool showBubbleschange, bool showBubblesprice, bool showBubblesBarsCount, bool showArrows, bool showbubblesvolume)
		{
			return indicator.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod(Input, invalidationType, minusBarsBack, drawNakedsOnly, multiplyTheZoneLinesBy, bubbleoffset, percentamount, revAmount, atrreversal, atrlength, showBubbleschange, showBubblesprice, showBubblesBarsCount, showArrows, showbubblesvolume);
		}

		public Indicators.KomepcStudios.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod(ISeries<double> input , INVALIDATION_TYPE invalidationType, int minusBarsBack, bool drawNakedsOnly, int multiplyTheZoneLinesBy, double bubbleoffset, double percentamount, double revAmount, double atrreversal, int atrlength, bool showBubbleschange, bool showBubblesprice, bool showBubblesBarsCount, bool showArrows, bool showbubblesvolume)
		{
			return indicator.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod(input, invalidationType, minusBarsBack, drawNakedsOnly, multiplyTheZoneLinesBy, bubbleoffset, percentamount, revAmount, atrreversal, atrlength, showBubbleschange, showBubblesprice, showBubblesBarsCount, showArrows, showbubblesvolume);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.KomepcStudios.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod(INVALIDATION_TYPE invalidationType, int minusBarsBack, bool drawNakedsOnly, int multiplyTheZoneLinesBy, double bubbleoffset, double percentamount, double revAmount, double atrreversal, int atrlength, bool showBubbleschange, bool showBubblesprice, bool showBubblesBarsCount, bool showArrows, bool showbubblesvolume)
		{
			return indicator.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod(Input, invalidationType, minusBarsBack, drawNakedsOnly, multiplyTheZoneLinesBy, bubbleoffset, percentamount, revAmount, atrreversal, atrlength, showBubbleschange, showBubblesprice, showBubblesBarsCount, showArrows, showbubblesvolume);
		}

		public Indicators.KomepcStudios.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod(ISeries<double> input , INVALIDATION_TYPE invalidationType, int minusBarsBack, bool drawNakedsOnly, int multiplyTheZoneLinesBy, double bubbleoffset, double percentamount, double revAmount, double atrreversal, int atrlength, bool showBubbleschange, bool showBubblesprice, bool showBubblesBarsCount, bool showArrows, bool showbubblesvolume)
		{
			return indicator.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod(input, invalidationType, minusBarsBack, drawNakedsOnly, multiplyTheZoneLinesBy, bubbleoffset, percentamount, revAmount, atrreversal, atrlength, showBubbleschange, showBubblesprice, showBubblesBarsCount, showArrows, showbubblesvolume);
		}
	}
}

#endregion
