using NinjaTrader.NinjaScript.Strategies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NinjaTrader.NinjaScript.Strategies;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.Gui.Chart;
using System.Windows.Media;
using NinjaTrader.Gui;

namespace NinjaTrader.Custom.Indicators.KomepcStudios {
	public class SupplyDemandKomepcUltraZone {

		public class ChartPoint {
			public int bar = 0;
			public double price = 0;
			//public bool invalidated = false;
			public int invalidatedAtBar = -1;
			public int lastTouchedOrCrossedAtBar = -1;
			public ChartPoint(int bar, double price) {
				this.bar = bar;
				this.price = price;
            }
        }

		
		
		public Indicator parent;

		public bool ultra_isCurrentYoungestValidNakedZoneForThisZoneColorDirection = false;
		public bool ultra_isPrior = false;

		public bool ultra_createdAtCurrentChartBar = false;
		public bool ultra_createdNow_OnThisTick_OnThisOnBarUpdateIndicatorCall = false;
		public int ultra_creation_start_bar_index_used_also_as_dictionary_key_externally_to_the_class = 0;
		public ChartPoint ultra_HighPoint_OnCreation_thisispointwith_index_0;
		public ChartPoint ultra_LowPoint_OnCreation_thisispointwith_index_0;
		public List<ChartPoint> ultra_low_historical_points = new List<ChartPoint>();
		public List<ChartPoint> ultra_high_historical_points = new List<ChartPoint>();
		private INVALIDATION_TYPE ultra_CONFIG_PARAM_INVALIDATABLE = INVALIDATION_TYPE.NOT_INVALIDATABLE;
		public ZONE_DIRECTION_COLOR_TYPE ultra_zone_direction_color_type = ZONE_DIRECTION_COLOR_TYPE.NOT_CREATED_YET;
		private Calculate ultra_CONFIG_parent_indi_CALCULATE = Calculate.OnBarClose;
		private int ultra_CONFIG_validation_bar_index = 0;
		//CONSTRUCTOR
		public SupplyDemandKomepcUltraZone(Indicator cratedByIndicator, int StartBar, int minusBarsBack, double high, double low, ZONE_DIRECTION_COLOR_TYPE zoneDirectionColorType, INVALIDATION_TYPE invalidationType, int CONFIG_VALID_FROM_Xth_BAR) {
			this.parent = cratedByIndicator;
			//Zone high and zone low is here as parameter in the constructor because the parent indicator (in this case this sup dem indicator)
			//The parent indicator can have a zone extension parameter (in ticks) this is why the zone high and low is not created inside the constructor of the ultra zone class/object
			
			//CurrentBar - 1 is used everywhere, we are using the prior bar for all calculation types which is possibly wrong for OnBarClose. Will check this in few minutes but will not re-comment it
			this.ultra_HighPoint_OnCreation_thisispointwith_index_0 = new ChartPoint(StartBar/*this.parent.CurrentBar - minusBarsBack*/, high);
			this.ultra_LowPoint_OnCreation_thisispointwith_index_0 = new ChartPoint(StartBar/*this.parent.CurrentBar - minusBarsBack*/, low);
			//Lists(arrays) of points defining the form of the zone if it was partially touched(eaten) by the price
			this.ultra_high_historical_points.Add(this.ultra_HighPoint_OnCreation_thisispointwith_index_0);
			this.ultra_low_historical_points.Add(this.ultra_LowPoint_OnCreation_thisispointwith_index_0);

			this.ultra_creation_start_bar_index_used_also_as_dictionary_key_externally_to_the_class = StartBar;
			this.ultra_createdAtCurrentChartBar = true;
			this.ultra_createdNow_OnThisTick_OnThisOnBarUpdateIndicatorCall = true;
			this.ultra_zone_direction_color_type = zoneDirectionColorType;
			this.ultra_CONFIG_PARAM_INVALIDATABLE = invalidationType;
			this.ultra_CONFIG_parent_indi_CALCULATE = parent.Calculate;
			this.ultra_CONFIG_validation_bar_index = this.ultra_creation_start_bar_index_used_also_as_dictionary_key_externally_to_the_class + CONFIG_VALID_FROM_Xth_BAR;
			this.ultra_calc_existsFromXBars = 0;
			//this.numberOfInvalidationEvents = 0;


			//And now some visual tricks...
			//Multiply the horizontal zones tickness in order if there are two instances on the same chart they to differe somehow visually
			if (parent is NinjaScript.Indicators.KomepcStudios.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod) {
				lineTicknessMultiplier = ((NinjaScript.Indicators.KomepcStudios.KomepcStudios_SupDemOptimizedZones_BasedOnZigZagCleanMod)parent).multiplyTheZoneLinesBy;
			}

		}
		int lineTicknessMultiplier = 1;

		int ultra_calc_existsFromXBars = 0;
		bool ultra_calc_validationBarReached = false;
		bool ultra_calc_ZONE_WAS_VALID_possibly_not_needed = false;
		public bool ultra_calc_ZONE_IS_VALID = false;
		bool ultra_THE_ZONE_IS_FULLY_INVALIDATED = false;
		int ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR = -1;
		public bool ultra_InvalidatedNow_OnThisTick = false;

		public bool ultra_calc_InvalidatedAfterValidationBar = false;
		public bool ultra_calc_InvalidatedBeforeValidationBar = false;
		
		public void calcExistFromBars() {
			ultra_calc_existsFromXBars = parent.CurrentBar - this.ultra_creation_start_bar_index_used_also_as_dictionary_key_externally_to_the_class;
        }
		public void setIsValidationBarReached() {
			if (Calculate.OnBarClose == ultra_CONFIG_parent_indi_CALCULATE) {
				ultra_calc_validationBarReached = parent.CurrentBar >= ultra_CONFIG_validation_bar_index - 1;
			}
			else {
				ultra_calc_validationBarReached = parent.CurrentBar >= ultra_CONFIG_validation_bar_index;
			}
		}
		//IMPORTANT NOTE!!! Invalidate on bar close or in real time depending on the calculation mode/type
		public void CheckForFullInvalidationByThePriorBar() {
			double priorBarHigh = 0;
			double priorBarLow = 0;
			if (Calculate.OnBarClose == ultra_CONFIG_parent_indi_CALCULATE) {
				priorBarHigh = parent.High[0];
				priorBarLow = parent.Low[0];
			}
			else {
				priorBarHigh = parent.High[1];
				priorBarLow = parent.Low[1];
			}

			if (ultra_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.GREEN) {
				if ((priorBarLow <= this.ultra_low_historical_points[0].price && ultra_CONFIG_PARAM_INVALIDATABLE == INVALIDATION_TYPE.ON_TOUCH)
					||
					(priorBarLow < this.ultra_low_historical_points[0].price && ultra_CONFIG_PARAM_INVALIDATABLE == INVALIDATION_TYPE.ON_CROSS)
				) {
					this.ultra_THE_ZONE_IS_FULLY_INVALIDATED = true;
					//The index of the invalidation bar depends on the calculation type
					if (ultra_CONFIG_parent_indi_CALCULATE == Calculate.OnBarClose)
						this.ultra_low_historical_points[0].invalidatedAtBar = parent.CurrentBar;
					else
						this.ultra_low_historical_points[0].invalidatedAtBar = parent.CurrentBar - 1;
					this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR = this.ultra_low_historical_points[0].invalidatedAtBar;
				}
			}
			else if (ultra_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.RED) {
				if ((priorBarHigh >= this.ultra_high_historical_points[0].price && ultra_CONFIG_PARAM_INVALIDATABLE == INVALIDATION_TYPE.ON_TOUCH)
					||
					(priorBarHigh > this.ultra_high_historical_points[0].price && ultra_CONFIG_PARAM_INVALIDATABLE == INVALIDATION_TYPE.ON_CROSS)
				) {
					this.ultra_THE_ZONE_IS_FULLY_INVALIDATED = true;
					//The index of the invalidation bar depends on the calculation type
					if (ultra_CONFIG_parent_indi_CALCULATE == Calculate.OnBarClose)
						this.ultra_high_historical_points[0].invalidatedAtBar = parent.CurrentBar;
					else
						this.ultra_high_historical_points[0].invalidatedAtBar = parent.CurrentBar - 1;
					this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR = this.ultra_high_historical_points[0].invalidatedAtBar;
				}
			}
			//Note that the validation bar reached parameter is calculated/set inside setIsValidationBarReached
			//Which setIsValidationBarReached() method is called before entering here in this method CheckForFullInvalidationByThePriorBar()
			//So we can rely on the ultra_THE_ZONE_IS_FULLY_INVALIDATED variable
			if (this.ultra_THE_ZONE_IS_FULLY_INVALIDATED) {
				if (ultra_calc_validationBarReached)
					ultra_calc_InvalidatedAfterValidationBar = true;
				else
					ultra_calc_InvalidatedBeforeValidationBar = true;
				this.ultra_InvalidatedNow_OnThisTick = true;
			}
		}

		public void CheckForPartialInvalidationByThePriorBar_DetectingTheYoungestBarThatIsCrossingOrTouchingTheInnerZoneLine() {
			double priorBarHigh = 0;
			double priorBarLow = 0;
			if (Calculate.OnBarClose == ultra_CONFIG_parent_indi_CALCULATE) {
				priorBarHigh = parent.High[0];
				priorBarLow = parent.Low[0];
			}
			else {
				priorBarHigh = parent.High[1];
				priorBarLow = parent.Low[1];
			}

			if (ultra_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.GREEN) {
				if (	(priorBarLow <= this.ultra_high_historical_points[0].price
						&& this.ultra_high_historical_points[0].price <= priorBarHigh
						&& ultra_CONFIG_PARAM_INVALIDATABLE == INVALIDATION_TYPE.ON_TOUCH)
						||
						(priorBarLow < this.ultra_high_historical_points[0].price
						&& this.ultra_high_historical_points[0].price  < priorBarHigh
						&& ultra_CONFIG_PARAM_INVALIDATABLE == INVALIDATION_TYPE.ON_CROSS)
				) {
					//this.ultra_THE_ZONE_IS_FULLY_INVALIDATED = true;
					//The index of the invalidation bar depends on the calculation type
					if (ultra_CONFIG_parent_indi_CALCULATE == Calculate.OnBarClose) {
						if (ultra_calc_validationBarReached)
							this.ultra_high_historical_points[0].lastTouchedOrCrossedAtBar = parent.CurrentBar;
					}
					else {
						if (ultra_calc_validationBarReached)
							this.ultra_high_historical_points[0].lastTouchedOrCrossedAtBar = parent.CurrentBar - 1;
					}
				}
			}
			else if (ultra_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.RED) {
				if (	(priorBarHigh >= this.ultra_low_historical_points[0].price
						&& this.ultra_low_historical_points[0].price >= priorBarLow
						&& ultra_CONFIG_PARAM_INVALIDATABLE == INVALIDATION_TYPE.ON_TOUCH)
						||
						(priorBarHigh > this.ultra_low_historical_points[0].price
						&& this.ultra_low_historical_points[0].price > priorBarLow
						&& ultra_CONFIG_PARAM_INVALIDATABLE == INVALIDATION_TYPE.ON_CROSS)
				) {
					//this.ultra_THE_ZONE_IS_FULLY_INVALIDATED = true;
					//The index of the invalidation bar depends on the calculation type
					if (ultra_CONFIG_parent_indi_CALCULATE == Calculate.OnBarClose) {
						if (ultra_calc_validationBarReached)
							this.ultra_low_historical_points[0].lastTouchedOrCrossedAtBar = parent.CurrentBar;
					}
					else {
						if (ultra_calc_validationBarReached)
							this.ultra_low_historical_points[0].lastTouchedOrCrossedAtBar = parent.CurrentBar - 1;
					}
				}
			}
		}

		public bool blinking = false;
		//private bool firstOnBarUpdateCall = false;
		public int drawXPixelsAhead = 100;
		public void OnBarUpdate() {
			if(this.parent.CurrentBar < 3) {
				return;
            }
			//Calculate for how many bars the zone exists
			calcExistFromBars();
			//After this line we know is the zone valide (i.e. is the validation bar reached)
			setIsValidationBarReached();
			//If the zone was invalidated on the prior tick
			//NOTE!!! Be careful with this, we have to always call the OnBarUpdate() method for the zone
			//If we stop to call the OnBarUpdate() for the zone after the invalidation tick =>
			//=> then we will enter here and set ultra_InvalidatedNow_OnThisTick on the next tick
			if (this.ultra_InvalidatedNow_OnThisTick)
				this.ultra_InvalidatedNow_OnThisTick = false;
			//First check for semi cross or touch of zone
			if (!ultra_THE_ZONE_IS_FULLY_INVALIDATED)
				CheckForPartialInvalidationByThePriorBar_DetectingTheYoungestBarThatIsCrossingOrTouchingTheInnerZoneLine();
			//Now check for full invalidation (on touch or on cross)
			//The invalidation is done on the opening of the new/current bar and works for all three calcualtion modes/types
			if (ultra_CONFIG_PARAM_INVALIDATABLE != INVALIDATION_TYPE.NOT_INVALIDATABLE && !ultra_THE_ZONE_IS_FULLY_INVALIDATED) 
				CheckForFullInvalidationByThePriorBar();
			if (this.ultra_calc_validationBarReached && !this.ultra_THE_ZONE_IS_FULLY_INVALIDATED) {
				this.ultra_calc_ZONE_IS_VALID = true;
				this.ultra_calc_ZONE_WAS_VALID_possibly_not_needed = true;
			}
			if (this.ultra_THE_ZONE_IS_FULLY_INVALIDATED)
				this.ultra_calc_ZONE_IS_VALID = false;

			if (parent.CurrentBar != ultra_creation_start_bar_index_used_also_as_dictionary_key_externally_to_the_class)
				ultra_createdAtCurrentChartBar = false;
			else
				ultra_createdAtCurrentChartBar = true;

			if (ultra_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.NOT_CREATED_YET) {
				Print("ZONE_TYPE.NOT_CREATED_YET");
				return;
			}
			//At the end of the first OnBarUpdate call
            if (!parent.IsFirstTickOfBar)
				this.ultra_createdNow_OnThisTick_OnThisOnBarUpdateIndicatorCall = false;

			if (!this.ultra_calc_validationBarReached && !this.ultra_THE_ZONE_IS_FULLY_INVALIDATED)
				blinking = true;
			else
				blinking = false;
		}
		#region ValidatorAndInvalidator old code
		//      public void ValidatorAndInvalidator() {

		//	if (this != null) {
		//		if (indi.CurrentBar == this.StartBar + CONFIG_validation_bar) {
		//			this.ValidationBarReached = true;
		//			this.ValidationBar = indi.CurrentBar;
		//		}
		//		//Invalidation
		//		int index = 0;
		//		if (CONFIG_calculate == Calculate.OnBarClose)
		//			index = 0;
		//		else 
		//			index = 1;
		//		this.InvalidatedNow = false;
		//		int i = indi.CurrentBar;
		//		while (indi.CurrentBar - index > this.StartBar && !this.Invalidated) {
		//			if (CONFIG_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.GREEN) {
		//				if ((this.Low >= indi.Low[index] && CONFIG_PARAM_INVALIDATABLE == INVALIDATION_TYPE.ON_TOUCH)
		//					|| (this.Low > indi.Low[index] && CONFIG_PARAM_INVALIDATABLE == INVALIDATION_TYPE.ON_TOUCH)) {
		//					if (!this.ValidationBarReached) {
		//						this.InvalidatedBeforeValidationBar = true;
		//						this.InvalidatedNow = true;
		//					}
		//					if (this.ValidationBarReached && !this.InvalidatedBeforeValidationBar) { 
		//						this.InvalidatedAfterValidationBar = true;
		//						this.InvalidatedNow = true;
		//					}
		//				}
		//			}
		//			if (CONFIG_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.RED) {
		//				if ((this.High <= indi.High[index] && CONFIG_PARAM_INVALIDATABLE == INVALIDATION_TYPE.ON_TOUCH)
		//					|| (this.High < indi.High[index] && CONFIG_PARAM_INVALIDATABLE == INVALIDATION_TYPE.ON_CROSS)) {
		//					if (!this.ValidationBarReached) { 
		//						this.InvalidatedBeforeValidationBar = true;
		//						this.InvalidatedNow = true;
		//					}
		//					if (this.ValidationBarReached && !this.InvalidatedBeforeValidationBar) {
		//						this.InvalidatedAfterValidationBar = true;
		//						this.InvalidatedNow = true;
		//					}
		//				}
		//			}
		//			index++;
		//		}

		//		if (!this.Invalidated && this.InvalidatedNow) {
		//			this.Invalidated = true;
		//			this.invalidatedAtBar = indi.CurrentBar;
		//		}

		//		if (this.ValidationBarReached) {
		//			if (!this.Invalidated) {
		//				this.IsValid = true;
		//				this.WasValid = true;
		//			}
		//		}

		//		if (this.Invalidated)
		//			this.IsValid = false;
		//	}
		//}
		#endregion
		public void Print(String s) {
			this.parent.Print("    " + "SDUltraZone print: " + s);
        }
		//public int validTillBarNumber = -1;
		//public enum InvalidationTypeEnum_OnlyForOnPriceChangeAndOnEachTick {
		//	NONE_USED_IF_ONBARCLOSE_IS_USED, INVALIDATE_ON_REAL_TIME_CURRENT_BAR, INVALIDATE_ON_CLOSE_OF_PRIOR_BAR
		//}

		long previousMillis = 0;
		bool blinkingDevelopingStillNotValidZone_drawYellowBackgroundLineForIt = true;
		public void OnRender(ChartControl chartControl, ChartScale chartScale, ChartBars chartBars, bool nakedsOnly) {

			if (blinking) {
				long nowMillis = DateTimeOffset.Now.ToUnixTimeMilliseconds();
				long diff = nowMillis - previousMillis;
				if (diff > 100) {
					blinkingDevelopingStillNotValidZone_drawYellowBackgroundLineForIt = !blinkingDevelopingStillNotValidZone_drawYellowBackgroundLineForIt;
					previousMillis = nowMillis;
				}
			}
			else
				blinkingDevelopingStillNotValidZone_drawYellowBackgroundLineForIt = false;
			
			//drawing tools mine
			//if(customDXSStrokeStyle == null)
			initDrawingToolsDuringTheCreationOfTheZone();

			
			
			
			int endBarOfTopLine = -1;
			int endBarOfBottomLine = -1;
			if (ultra_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.GREEN) {
				endBarOfTopLine = this.ultra_HighPoint_OnCreation_thisispointwith_index_0     .lastTouchedOrCrossedAtBar;
				// ^^^^ Same as = this.ultra_high_historical_points[0].lastTouchedOrCrossedAtBar
				//pointXEndOfTopLine = chartControl.GetXByBarIndex(parent.ChartBars, endBarOfTopLine);
				if (ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR != -1)
					endBarOfBottomLine = this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR;
			}
			else if (ultra_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.RED) {
				endBarOfBottomLine = this.ultra_LowPoint_OnCreation_thisispointwith_index_0     .lastTouchedOrCrossedAtBar;
				// ^^^^ Same as    = this.ultra_low_historical_points[0].lastTouchedOrCrossedAtBar
				//pointXEndOfBottomLine = chartControl.GetXByBarIndex(parent.ChartBars, endBarOfBottomLine);
				if (ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR != -1)
					endBarOfTopLine = this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR;
			}


			//Commented, might think about it later. But it is not needed exotic visual
			//if (this.ultra_HighPoint_OnCreation.invalidatedAtBar != -1)
			//    pointXEndOfTopLine = chartControl.GetXByBarIndex(parent.ChartBars, this.ultra_HighPoint_OnCreation.invalidatedAtBar);
			//if (this.ultra_LowPoint_OnCreation.invalidatedAtBar != -1)
			//    pointXEndOfBottomLine = chartControl.GetXByBarIndex(parent.ChartBars, this.ultra_LowPoint_OnCreation.invalidatedAtBar);

			//Also commented - I think that is not needed because the inner line of the zone is invalidated always earlier in the time (sometimes oth might be invalidated within the same bar, but still the logic above (before the commented lines, i.e. the logic that starts around 10-15 lines above) covers this inner line touch or cross
			//Second reson to comment the code bleow is:
			//Second reason is -> It is not supposed to enter here, because I check for cross or touch of the inner line only if the zone is still valid!!!
			//if (ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR != -1) {
			//	pointXEndOfTopLine = chartControl.GetXByBarIndex(parent.ChartBars, this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR);
			//	pointXEndOfBottomLine = chartControl.GetXByBarIndex(parent.ChartBars, this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR);
			//	endBarOfTopLine = this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR;
			//	endBarOfBottomLine = this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR;
			//}

			
			SharpDX.Direct2D1.Brush brush = Brushes.Blue.ToDxBrush(parent.RenderTarget);
			if (ultra_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.GREEN)
				brush = brushGreen;
			else if (ultra_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.RED)
				brush = brushRed;

			////Dashed Yellow line for validation point/bar (nice idea)
			////TRY TO ANIMATE ALL LINE APPEARANCES
			//... old code removed ...

			if (!nakedsOnly || (nakedsOnly && this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR == -1)) {

				//A bit messy (not so messy but duplicated) logic for the dashes, tickness and coloring and opacity...
				//The main thing is the logic above that is detecting the start and the ends of the horizontal and vertical lines
				SolidColorBrush solCBr = Brushes.Blue;
				
				int thickenssHigh = 1;
				int thicknessLow = 1;
				
				float[] patternHighNormal_ = new float[] { 3f, 12f };
				float[] patternLowNormal_ = new float[] { 3f, 12f };
				float[] patternHighCurrentValid_ = new float[] { 12f, 3f };
				float[] patternLowCurrentValid_ = new float[] { 12f, 3f };

				float[] patternHigh = patternHighNormal_;
				float[] patternLow = patternLowNormal_;
				if (this.ultra_isCurrentYoungestValidNakedZoneForThisZoneColorDirection) {
					patternHigh = patternHighCurrentValid_;
					patternLow = patternLowCurrentValid_;
				}
				if (ultra_zone_direction_color_type == ZONE_DIRECTION_COLOR_TYPE.GREEN) {
					solCBr = Brushes.Green;
					thickenssHigh = 1;
					thicknessLow = 3;
					//patternLow = new float[] { 6f, 1f };
				}
				else {
					solCBr = Brushes.Red;
					thickenssHigh = 3;
					thicknessLow = 1;
					//patternHigh = new float[] { 6f, 1f };
				}

				
				float dashOffsetHigh = 0f;
				float dashOffsetLow = 0f;
				float opacityForTheLines = 1.0f;
				float opacityForTheZoneFill = 1.0f;
				if (this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR == -1 ||/*same as the left one*/ this.ultra_calc_ZONE_IS_VALID) {
					if (this.blinking || this.ultra_isCurrentYoungestValidNakedZoneForThisZoneColorDirection) {
						thickenssHigh = 2;
						thicknessLow = 2;
						patternHigh = new float[] { 20f, 14f };
						patternLow = new float[] { 20f, 14f };
						dashOffsetHigh = 0f;
						dashOffsetLow = 6f;//6f is 
						opacityForTheLines = 0.25f;
						opacityForTheZoneFill = 0.1f;
					}
					else {
						thickenssHigh = 1;
						thicknessLow = 1;
						patternHigh = new float[] { 3f, 6f };
						patternLow = new float[] { 3f, 6f };
						opacityForTheLines = 0.25f;
						opacityForTheZoneFill = 0.035f;
					}
				}
				//This is for invalidated (non naked zones)
				else {
					thickenssHigh = 1;
					thicknessLow = 1;
					patternHigh = new float[] { 3f, 6f };
					patternLow = new float[] { 3f, 6f };
					opacityForTheLines = 0.25f;
				}
				drawUniversalHorizontalLineWith100PixelsAheadOnTheChart(
					chartControl, chartScale,
					this.ultra_HighPoint_OnCreation_thisispointwith_index_0.bar, endBarOfTopLine,//this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR,
					ultra_HighPoint_OnCreation_thisispointwith_index_0.price,
					//Line Color
					solCBr, opacityForTheLines,
					//Line dash pattern and thickness
					patternHigh, dashOffsetHigh, thickenssHigh,
					blinkingDevelopingStillNotValidZone_drawYellowBackgroundLineForIt);

				drawUniversalHorizontalLineWith100PixelsAheadOnTheChart(
					chartControl, chartScale,
					this.ultra_LowPoint_OnCreation_thisispointwith_index_0.bar, endBarOfBottomLine,//this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR,
					ultra_LowPoint_OnCreation_thisispointwith_index_0.price,
					//Line Color
					solCBr, opacityForTheLines,
					//Line dash pattern and thickness
					patternLow, dashOffsetLow, thicknessLow,
					blinkingDevelopingStillNotValidZone_drawYellowBackgroundLineForIt);





				//Again note that ultra_HighPoint_OnCreation is same as this.ultra_high_historical_points[0]
				float yPixelsForTheTopOfTheZone = chartScale.GetYByValue(ultra_HighPoint_OnCreation_thisispointwith_index_0.price);
				float yPixelsForTheBottomOfTheZone = chartScale.GetYByValue(ultra_LowPoint_OnCreation_thisispointwith_index_0.price);
				
				//Dashed Yellow line for validation point/bar (nice idea)
				//TRY TO ANIMATE ALL LINE APPEARANCES
				if (true) { //Draw Yellow Dashed Vertical Line on the validation bar position
					
					float location_pix__horizontal_ValidationBar = chartControl.GetXByBarIndex(parent.ChartBars, this.ultra_CONFIG_validation_bar_index);
					
					SharpDX.Direct2D1.Brush brush2D1ForVerticalValidationLine = toDxBrush(solCBr);
					brush2D1ForVerticalValidationLine.Opacity = opacityForTheLines; 
					SharpDX.Vector2 topOfDashedValidationLine = new SharpDX.Vector2(location_pix__horizontal_ValidationBar, yPixelsForTheTopOfTheZone);
					SharpDX.Vector2 bottomOfDashedValidationLine = new SharpDX.Vector2(location_pix__horizontal_ValidationBar, yPixelsForTheBottomOfTheZone);

					int lineThickness = 1 * lineTicknessMultiplier;
					float[] patternVerticalYellow = new float[] { 6f, 6f };
					int i = 0;
					while (i < patternVerticalYellow.Length) {
						patternVerticalYellow[i] = patternVerticalYellow[i] / lineThickness;
						i++;
					}
					SharpDX.Direct2D1.StrokeStyle normalSStyle = CreateCustomStrokeVUseful(patternVerticalYellow, 6);
					SharpDX.Direct2D1.StrokeStyle reversedSStyle = CreateCustomStrokeVUseful(new float[] { patternVerticalYellow[1], patternVerticalYellow[0] }, 6);
					
					//Draw background blinking yellow dashed line indicating that the zone is still developing and has not reached its validation bar
					if (blinkingDevelopingStillNotValidZone_drawYellowBackgroundLineForIt) {
						SharpDX.Direct2D1.Brush brush2D1YellowReversedDashes = toDxBrush(Brushes.Yellow);
						brush2D1YellowReversedDashes.Opacity = opacityForTheLines;
						DrawLineOverriden(topOfDashedValidationLine, bottomOfDashedValidationLine,
							//																		 this is the reversed pattern for the background yellow blinking dashes/dots
							brush2D1YellowReversedDashes, lineThickness, reversedSStyle);
					}
					DrawLineOverriden(topOfDashedValidationLine, bottomOfDashedValidationLine, 
						brush2D1ForVerticalValidationLine, lineThickness, normalSStyle);
				}

				if (true) {
					float pointXStartOfZone = chartControl.GetXByBarIndex(parent.ChartBars, this.ultra_HighPoint_OnCreation_thisispointwith_index_0.bar);
					float pointXEndOfZone = chartControl.GetXByBarIndex(parent.ChartBars, parent.CurrentBar);
					if (this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR != -1)
						pointXEndOfZone = chartControl.GetXByBarIndex(parent.ChartBars, this.ultra_THE_ZONE_WAS_FULLY_INVALIDATED_AT_BAR);
					if (this.ultra_isCurrentYoungestValidNakedZoneForThisZoneColorDirection || blinking /*blinking means still developing*/) {
						pointXEndOfZone += drawXPixelsAhead;
					}
					SharpDX.RectangleF supDemZoneRect = new SharpDX.RectangleF(pointXStartOfZone,
																				yPixelsForTheTopOfTheZone,
                                                                                pointXEndOfZone - pointXStartOfZone,
																				yPixelsForTheBottomOfTheZone - yPixelsForTheTopOfTheZone);
					brush.Opacity = opacityForTheZoneFill;
					//Fill the zone only if it s valid
					if(ultra_calc_ZONE_IS_VALID)
						parent.RenderTarget.FillRectangle(supDemZoneRect, brush);
                }
            }

            brushGreen.Dispose();
            brushRed.Dispose();
        }

		public SharpDX.Direct2D1.Brush toDxBrush(SolidColorBrush solidColorBrush) {
			return solidColorBrush.ToDxBrush(parent.RenderTarget);
		}

		#region drawing tools ragion
			public void initDrawingToolsDuringTheCreationOfTheZone() {
				customDXSStrokeStyle = CreateCustomStrokeVUseful((new float[] { 10f, 3f }), 100);
				customDXSStrokeStyle2 = CreateCustomStrokeVUseful((new float[] { 5.0f, 3f }), 0);
				customDXSStrokeStyleForTheVerticalYellowLine = CreateCustomStrokeVUseful((new float[] { 6.0f, 10.0f }), 10);
				brushGreen = Brushes.Green.ToDxBrush(parent.RenderTarget); // Brushes.Lime.ToDxBrush(RenderTarget);
				brushRed = Brushes.Red.ToDxBrush(parent.RenderTarget);
				brushYellow = Brushes.Yellow.ToDxBrush(parent.RenderTarget);
				brushDarkGray = Brushes.DarkGray.ToDxBrush(parent.RenderTarget);
				brushLightGray = Brushes.LightGray.ToDxBrush(parent.RenderTarget);
				brushBlack = Brushes.Black.ToDxBrush(parent.RenderTarget);
				brushWhite = Brushes.White.ToDxBrush(parent.RenderTarget);
			}
			SharpDX.Direct2D1.StrokeStyle customDXSStrokeStyle = null;// = CreateCustomStrokeVUseful((new float[] { 10f, 3f }), 100);
			SharpDX.Direct2D1.StrokeStyle customDXSStrokeStyle2;// = CreateCustomStrokeVUseful((new float[] { 5.0f, 3f }), 0);
			SharpDX.Direct2D1.StrokeStyle customDXSStrokeStyleForTheVerticalYellowLine;// = CreateCustomStrokeVUseful((new float[] { 6.0f, 10.0f }), 10);
			SharpDX.Direct2D1.Brush brushGreen;// = Brushes.Green.ToDxBrush(parent.RenderTarget); // Brushes.Lime.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush brushRed;// = Brushes.Red.ToDxBrush(parent.RenderTarget);
			SharpDX.Direct2D1.Brush brushYellow;// = Brushes.Yellow.ToDxBrush(parent.RenderTarget);
			SharpDX.Direct2D1.Brush brushDarkGray;// = Brushes.DarkGray.ToDxBrush(parent.RenderTarget);
			SharpDX.Direct2D1.Brush brushLightGray;// = Brushes.DarkGray.ToDxBrush(parent.RenderTarget);
			SharpDX.Direct2D1.Brush brushBlack;// = Brushes.Black.ToDxBrush(parent.RenderTarget);
			SharpDX.Direct2D1.Brush brushWhite;// = Brushes.White.ToDxBrush(parent.RenderTarget);
        #endregion
        
		//QuadraticBezierSegment

        public void drawUniversalHorizontalLineWith100PixelsAheadOnTheChart(ChartControl chartControl, ChartScale chartScale, 
			int index_of_bar_1, int index_of_bar_2_touchOrCrossPointIndex, double price, 
			SolidColorBrush winMediaSolidColorBrush, float opacity,
			float[] customDXSStrokeStylePattern, float dashOffset,  int lineThickness, 
			bool drawYellowBackgroundSolidLineBehindTheRedOrGreenDashes) {
			try {
				lineThickness = lineThickness * lineTicknessMultiplier;

				int i = 0;
				while (i < customDXSStrokeStylePattern.Length) {
					customDXSStrokeStylePattern[i] = customDXSStrokeStylePattern[i] / lineThickness;
					i++;
				}

				SharpDX.Direct2D1.StrokeStyle customDXSStrokeStyleInternal = CreateCustomStrokeVUseful(customDXSStrokeStylePattern, dashOffset);
				SharpDX.Direct2D1.StrokeStyle customDXSStrokeStyleInternal_ReversedOppositeForTheYellowLineToCoverTheBlackPixelsOnly = CreateCustomStrokeVUseful(new float[] { customDXSStrokeStylePattern[1], customDXSStrokeStylePattern[0] }, dashOffset + customDXSStrokeStylePattern[1]);// + customDXSStrokeStylePattern[0]);
				float x1Pixel = chartControl.GetXByBarIndex(parent.ChartBars, index_of_bar_1);
				float x2Pixel = chartControl.GetXByBarIndex(parent.ChartBars, parent.CurrentBar);
				if(this.ultra_isCurrentYoungestValidNakedZoneForThisZoneColorDirection || blinking /*blinking means still developing*/) {
					x2Pixel += drawXPixelsAhead;
				}
				if (index_of_bar_2_touchOrCrossPointIndex != -1)
					x2Pixel = chartControl.GetXByBarIndex(parent.ChartBars, index_of_bar_2_touchOrCrossPointIndex);
				float yPixel = chartScale.GetYByValue(price);
				SharpDX.Direct2D1.Brush brush2D1 = toDxBrush(winMediaSolidColorBrush);
				brush2D1.Opacity = opacity;
				SharpDX.Direct2D1.Brush brush2D1YellowReversedDashes = toDxBrush(Brushes.Yellow);
				brush2D1YellowReversedDashes.Opacity = opacity;
				//TRY TO ANIMATE ALL LINE APPEARANCES
				SharpDX.Vector2 p1 = new SharpDX.Vector2(x1Pixel, yPixel);
				SharpDX.Vector2 p2 = new SharpDX.Vector2(x2Pixel, yPixel);
				//Draw solid yellow line indicating that it is a developing/fres zone that has not reached its validation bar
				if(drawYellowBackgroundSolidLineBehindTheRedOrGreenDashes)
					DrawLineOverriden(p1, p2, brush2D1YellowReversedDashes, lineThickness, customDXSStrokeStyleInternal_ReversedOppositeForTheYellowLineToCoverTheBlackPixelsOnly);
				DrawLineOverriden(p1, p2, brush2D1, lineThickness, customDXSStrokeStyleInternal);
			}
			catch (Exception e) {
				Print(e.Message);
				Print(e.StackTrace);
			}
		}

		
		public void DrawLineOverriden(SharpDX.Vector2 point0, SharpDX.Vector2 point1, SharpDX.Direct2D1.Brush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle) {
			parent.RenderTarget.DrawLine(point0, point1, brush, strokeWidth, strokeStyle);
		}

		//New variables after starting to add the naked zones detector
		//public SupplyDemandFibExtensionsUltra createdByIndicator;
		//public int CORE_Fully_Invalidated_At_Bar = -1;
		//public int CORE_Partially_Invalidated_At_Bar = -1;
		//public int highWasInvalidatedAtBar = -1;
		//public double newHighAfterPartialInvalidation = -1;
		//public int lowWasInvalidatedAtBar = -1;
		//public double newLowAfterPartialInvalidation = -1;
		public double getYOfLowForDrawing() {

			return 0;
		}
		
		//public ENTRY_DIRECTION EntryDirection = ENTRY_DIRECTION.NO_TRADE_FOR_THIS_ZONE_YET_works_only_for_komepc_zone_object;
		//public bool isTheActiveZone = false;
		//public bool ValidationBarReached = false;
		//public bool Invalidated = false;
		//public bool InvalidatedNow = false;
		//public bool InvalidatedAfterValidationBar = false;
		//public bool InvalidatedBeforeValidationBar = false;
		//public int invalidatedAtBar = -1;

		//public double NakedHigh = 0;
		//public double NakedLow = 0;
		////lastKeyUsed is not used, it looks confusing to use it together with startBarOfTheCurrentZone
		//public int lastKeyUsed = 0;
		//public bool IsValid = false;
		//public bool WasValid = false;
		////Valid means that the zone was naked at and after the 3rd bar!!!
		//public int ValidationBar = -1;
		//public int StartBar = 0;
		public Boolean drawBoldSolidTopLineZone = false;
		public Boolean drawBoldSolidBottomLineZone = false;
		public Boolean fillZone = false;
		
		


		public SharpDX.Direct2D1.StrokeStyle CreateCustomStrokeVUseful(float[] dashesCallItSpaces, float dashOffset) {
			// define the an array of floating-point values
			//float[] dashesCallItSpaces = { 15.0f, 15.0f };

			SharpDX.Direct2D1.StrokeStyleProperties dxStrokeStyleProperties = new SharpDX.Direct2D1.StrokeStyleProperties {
				// set the dash style to "Custom" define the dash pattern 
				DashStyle = SharpDX.Direct2D1.DashStyle.Custom,

				// set further custom/optional StrokeStyle appearances
				DashCap = SharpDX.Direct2D1.CapStyle.Round,
				EndCap = SharpDX.Direct2D1.CapStyle.Flat,
				StartCap = SharpDX.Direct2D1.CapStyle.Square,
				LineJoin = SharpDX.Direct2D1.LineJoin.Miter,

				// offset in the dash sequence
				DashOffset = dashOffset,
			};

			// create the stroke style using the custom properties and dash array
			SharpDX.Direct2D1.StrokeStyle customDXSStrokeStyle_ = new SharpDX.Direct2D1.StrokeStyle(NinjaTrader.Core.Globals.D2DFactory,
					dxStrokeStyleProperties, dashesCallItSpaces);
			return customDXSStrokeStyle_;
		}
	}
}
