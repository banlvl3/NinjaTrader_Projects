using NinjaTrader.NinjaScript.Strategies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NinjaTrader.NinjaScript.Strategies;
using System.ComponentModel;

namespace NinjaTrader.Custom.Indicators.KomepcStudios {
	public enum INVALIDATION_TYPE {
		[Description("Do not Invalidate")] NOT_INVALIDATABLE,
		[Description("Invalidate on Touch")] ON_TOUCH,
		[Description("Invalidate on Cross")] ON_CROSS
	}
	public enum ZONE_DIRECTION_COLOR_TYPE {
		NOT_CREATED_YET, RED, GREEN
	}

	public class EnumsUltraVersion {

    }
}
