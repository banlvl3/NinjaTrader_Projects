#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui.Tools;
using System.Windows.Controls;
#endregion

//This namespace holds Add ons in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.AddOns.My_AddOns
{

	public class CustomButtonAddOn : NinjaTrader.NinjaScript.AddOnBase
	{
        #region Constants and Instance Variables
        //
        private const string CHART_TRADER_AUTOMATION_ID = "ChartWindowChartTraderControl";
        private const string CHART_TRADER_MAIN_GRID_NAME = "grdMain";
        private const string CHART_TRADER_EXTENSION_ROW_NAME = "ChartTraderExtensionsRow";
        private const string CHART_TRADER_EXTENSION_GRID_UID = "ChartTraderExtensionsGrid";
        private const string SAMPLE_BUTTON_UID = "SampleButton";
        private const int CHART_TRADER_ROWS = 7;
        private int chartWindowCount = 0;
        //
        #endregion
        protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"ChartTrader CutomButton to place Stop Orders";
				Name										= "CustomButtonAddOn";
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnWindowCreated(Window window)
		{
            // return if the calling window is not a Chart
            if (window as Chart == null) return;

            Print("Creating Chart Window " + ++chartWindowCount);

            // find Chart Trader from the calling chart window by its Automation ID
            ChartTrader chartTrader = window.FindFirst(CHART_TRADER_AUTOMATION_ID) as ChartTrader;
            if (chartTrader == null) return; // something is seriously wrong if chartTrader is null

            // find the main Chart Trader grid where the default buttons and controls reside
            Grid mainGrid = chartTrader.FindName(CHART_TRADER_MAIN_GRID_NAME) as Grid;
            if (mainGrid != null) // something is seriously wrong if mainGrid is null
            {
                // define a Chart Trader Extension grid
                Grid chartTraderExtensionGrid = new Grid
                {
                    VerticalAlignment = VerticalAlignment.Top,
                    Margin = new Thickness(10),
                    Uid = CHART_TRADER_EXTENSION_GRID_UID
                };

                // define the Sample button
                Button sampleButton = new Button
                {
                    Content = "ON",
                    Style = Application.Current.TryFindResource("Button") as Style,
                    Uid = SAMPLE_BUTTON_UID
                };
                Print("Adding the " + sampleButton.Uid + " to the Chart Trader Extension grid on Window " + chartWindowCount);
                chartTraderExtensionGrid.Children.Add(sampleButton);

                // by default, there will be 7 rows in Chart Trader, we need to add a new row for the Chart Trader Extension Grid
                if (mainGrid.RowDefinitions.Count <= CHART_TRADER_ROWS)
                {
                    RowDefinition newRow = new RowDefinition
                    {
                        Name = CHART_TRADER_EXTENSION_ROW_NAME
                    };
                    Print("Adding a new row to the Chart Trader grid on Window " + chartWindowCount);
                    mainGrid.RowDefinitions.Add(newRow);
                }
                // add the Chart Trader Extension grid to the new row we just created
                Grid.SetRow(chartTraderExtensionGrid, mainGrid.RowDefinitions.Count);

                Print("Adding the Chart Trader Extension grid to the Chart Trader grid on Window " + chartWindowCount);
                mainGrid.Children.Add(chartTraderExtensionGrid);

                Print("Attaching the event handler from the Click event for " + sampleButton.Uid + " on Window " + chartWindowCount);
                sampleButton.Click += SampleButton_Click;
            }
        }

		protected override void OnWindowDestroyed(Window window)
		{
            // Return if the calling window is not a chart
            if (window as Chart == null) return;

            Print("Destroying Chart Window " + chartWindowCount);

            // find Chart Trader from the calling chart window by its Automation ID
            ChartTrader chartTrader = window.FindFirst(CHART_TRADER_AUTOMATION_ID) as ChartTrader;
            if (chartTrader == null) return; // something is seriously wrong if chartTrader is null

            // find the main Chart Trader grid
            Grid currentMainGrid = chartTrader.FindName(CHART_TRADER_MAIN_GRID_NAME) as Grid;
            if (currentMainGrid != null) // something is seriously wrong if mainGrid is null
            {
                // find the Chart Trader Extensions grid we added
                Grid chartTraderExtensionGrid = currentMainGrid.Children
                                                               .Cast<UIElement>()
                                                               .FirstOrDefault(g => g.Uid == CHART_TRADER_EXTENSION_GRID_UID) as Grid;
                if (chartTraderExtensionGrid != null)
                {
                    // find the Sample Button we created and added to the Chart Trader Extensions grid
                    Button sampleButton = chartTraderExtensionGrid.Children
                                                    .Cast<UIElement>()
                                                    .FirstOrDefault(b => b.Uid == SAMPLE_BUTTON_UID) as Button;
                    if (sampleButton != null)
                    {
                        Print("Detaching the event handler from the Click event for " + sampleButton.Uid + " on Window " + chartWindowCount);
                        sampleButton.Click -= SampleButton_Click;
                    }

                    Print("Removing the Chart Trader Extension grid on Window " + chartWindowCount);
                    currentMainGrid.Children.Remove(chartTraderExtensionGrid);
                }

                if (currentMainGrid.RowDefinitions.Count > CHART_TRADER_ROWS)
                {
                    // find the row we added to the Chart Trader grid
                    RowDefinition rowToRemove = currentMainGrid.RowDefinitions
                                                               .FirstOrDefault(r => r.Name == CHART_TRADER_EXTENSION_ROW_NAME);
                    if (rowToRemove != null)
                    {
                        Print("Removing a row from the Chart Trader grid on Window " + chartWindowCount);
                        currentMainGrid.RowDefinitions.Remove(rowToRemove);
                    }
                }
            }
            chartWindowCount--;
        }
        #region Event Handlers
        //
        private void SampleButton_Click(object sender, RoutedEventArgs e)
        {
            Button sampleButton = sender as Button;
            if (sampleButton == null) return;

            Chart chartWindow = Window.GetWindow(sampleButton) as Chart;
            if (chartWindow == null) return;

            ChartControl chartControl = chartWindow.ActiveChartControl;
            if (chartControl == null) return;

            Print(sampleButton.Content + " Button Clicked");
            if (sampleButton.Content.ToString() == "ON")
            {
                sampleButton.Content = "ON";
                chartControl.MouseDown += OnMouseDown;
                chartControl.KeyDown += OnKeyDown;
            }
            else if (sampleButton.Content.ToString() == "OFF")
            {
                sampleButton.Content = "OFF";
                chartControl.MouseDown -= OnMouseDown;
                chartControl.KeyDown -= OnKeyDown;
            }
        }

        private void OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            ChartControl chartControl = sender as ChartControl;
            if (chartControl != null)
            {
                Print("Point " + chartControl.MouseDownPoint.ToString());
            }
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            Print("Key " + e.Key.ToString());
        }
        //
        #endregion
    }

}
