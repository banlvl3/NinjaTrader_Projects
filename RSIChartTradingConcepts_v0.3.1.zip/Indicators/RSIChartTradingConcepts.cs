#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;

using NinjaTrader.Cbi;
using NinjaTrader.Core;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.AddOns;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	#region RSICTC_Vars
	public class RSICTC_Vars
	{
		public const string LenLRCat 		= "Length Left / Right";
		public const string TrendLinesCat 	= "Trend Lines";
		public const string FillCat		 	= "Fill";
		public const string LabelsCat 		= "Labels";
		public const string RSICat 			= "RSI";
		public const string SourceCat 		= "Source";
		public const string MACat 			= "MA Settings";
		public const string DivergenceCat	= "Divergence";
		public const string BreakCat		= "Breakout / Breakdown";
		public const string GhostCat		= "Ghost";
		public const string CandlesCat		= "Candles Color";
		public const string RossHookCat		= "Ross Hook";
		
		public enum RSI_Type 
		{
			RSI,
			Two_Sources_RSI,
			Connors_RSI
		}
		
		public enum Price_Source 
		{
			Open,
			High,
			Low,
			Close,
			HL2,
			HLC3,
			OHLC4,
			HLCC4
		}
		
		public enum Source_Type 
		{
			On_RSI,
			On_Price
		}
		
		public enum MA_Type 
		{
			SMA,
			EMA,
			SMMA,
			WMA,
			VWMA
		}
	}
	#endregion
	
	#region Categories Order
	[CategoryOrder(RSICTC_Vars.LenLRCat, 1)]
	[CategoryOrder(RSICTC_Vars.TrendLinesCat, 2)]
	[CategoryOrder(RSICTC_Vars.FillCat, 3)]
	[CategoryOrder(RSICTC_Vars.LabelsCat, 4)]
	[CategoryOrder(RSICTC_Vars.RSICat, 5)]
	[CategoryOrder(RSICTC_Vars.SourceCat, 6)]
	[CategoryOrder(RSICTC_Vars.MACat, 7)]
	[CategoryOrder(RSICTC_Vars.DivergenceCat, 8)]
	[CategoryOrder(RSICTC_Vars.BreakCat, 9)]
	[CategoryOrder(RSICTC_Vars.GhostCat, 10)]
	[CategoryOrder(RSICTC_Vars.CandlesCat, 11)]
	[CategoryOrder(RSICTC_Vars.RossHookCat, 12)]
	#endregion
	public class RSIChartTradingConcepts : Indicator
	{
		private Series<double> rsi, rsiHl2, rsiHighs, rsiLows, ma1, ma2, divLows, divHighs;
		private Series<double> open, close, high, low, hl2, hlc3, hlcc4, ohlc4, highSource, lowSource;
		
		private MIN minLows, minRSILows;
		private MAX maxHighs, maxRSIHighs;
		
		private List<double> pivotLows, pivotHighs, pivotRSIHighs, pivotRSILows;
		private List<int> pivotLowBarIndex, pivotHighBarIndex;
		
		private int 	minBars, latestOverboughtBar = 0, latestOversoldBar = 0;
		private bool 	isOnPrice;
		private double 	labelsDist;
		
		private string 	hhTag = "", lhTag = "", hh2Tag = "", lh2Tag = "", hhFillTag = "", lhFillTag = "",
						llTag = "", hlTag = "", ll2Tag = "", hl2Tag = "", llFillTag = "", hlFillTag = "",
						breakHHTag = "BreakHHLabel", breakLHTag = "BreakLHLabel", breakHLTag = "BreakHLLabel", breakLLTag = "BreakLLLabel";
		
		private string breakAlertSound = NinjaTrader.Core.Globals.UserDataDir + @"\templates\RSICTC\BreakAlert.wav";
		private PopUpWindow popUp;
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description = @"RSI Chart Trading Concepts v0.3.1";
				Name = "RSI Chart Trading Concepts";
				
				Calculate					= Calculate.OnBarClose;
				IsOverlay					= true;
				DisplayInDataBox			= true;
				DrawOnPricePanel			= true;
				DrawHorizontalGridLines		= true;
				DrawVerticalGridLines		= true;
				PaintPriceMarkers			= true;
				ScaleJustification			= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive	= true;
				
				#region Params
				
				PivotHighLeft 	= 5;
				PivotHighRight 	= 3;
				PivotLowLeft 	= 5;
				PivotLowRight 	= 3;
				
				HigherHighBrush 	= Brushes.OrangeRed;
				HigherHighTextBrush = Brushes.Red;
				HigherLowBrush		= Brushes.DodgerBlue;
				HigherLowTextBrush 	= Brushes.Blue;
				LowerLowBrush		= Brushes.Green;
				LowerLowTextBrush	= Brushes.LimeGreen;
				LowerHighBrush 		= Brushes.Goldenrod;
				LowerHighTextBrush	= Brushes.Yellow;
				
				FillOpacity 	= 10;
				LabelsDistance	= 10;
				
				RSI_Type 			= RSICTC_Vars.RSI_Type.RSI;
				HighRSISource 		= RSICTC_Vars.Price_Source.Close;
				LowRSISource 		= RSICTC_Vars.Price_Source.Close;
				RSILength			= 14;
				UpDownLength		= 2;
				ROCLength			= 100;
				OverboughtThreshold = 70;
				OversoldThreshold	= 30;
				ShowRSITrend		= true;
				
				SourceType	= RSICTC_Vars.Source_Type.On_Price;
				HighsSource	= RSICTC_Vars.Price_Source.Close;
				LowsSource	= RSICTC_Vars.Price_Source.Close;
				
				MA1Source	= RSICTC_Vars.Price_Source.Close;
				MA1Type		= RSICTC_Vars.MA_Type.SMA;
				MA1Length	= 3;
				MA2Source	= RSICTC_Vars.Price_Source.Close;
				MA2Type		= RSICTC_Vars.MA_Type.SMA;
				MA2Length	= 3;
				
				PlotBullish 			= true;
				PlotHiddenBullish 		= false;
				PlotBearish				= true;
				PlotHiddenBearish		= false;
				DivTransparency			= 0;
				BearBrush				= Brushes.Red;
				BullBrush				= Brushes.Green;
				DivHiddenTransparency 	= 80;
				HiddenBullBrush			= Brushes.Blue;
				HiddenBearBrush			= Brushes.Orange;
				
				ShowBreak 			= false;
				ShowBreakAlert 		= false;
				PlayBreakAlertSound = false;
				BreakHHBrush		= Brushes.Red;
				BreakLHBrush		= Brushes.Orange;
				BreakLLBrush		= Brushes.Green;
				BreakHLBrush		= Brushes.Blue;
				BreakTransparency	= 0;
				
				Ghost 		= true;
				GhostLength = 21;
				
				ColoredCandles 			= false;
				FullColoredCandles 		= false;
				OversoldCanleBrush 		= Brushes.Blue;
				OverboughtCanleBrush	= Brushes.Purple;
				MA1OverMA2CandleBrush	= Brushes.Red;
				MA1UnderMA2CandleBrush	= Brushes.Green;
				
				RossHookBullishBrush = Brushes.Cyan;
				RossHookBearishBrush = Brushes.Magenta;
				
				#endregion
				
				AddPlot(new Stroke(Brushes.Transparent, 2), PlotStyle.Line, "MA1");
				AddPlot(new Stroke(Brushes.Transparent, 2), PlotStyle.Line, "MA2");
				AddPlot(new Stroke(Brushes.Purple, 2), PlotStyle.Line, "Overbought Top");
				AddPlot(new Stroke(Brushes.Purple, 1), PlotStyle.Cross, "Overbought Bottom");
				AddPlot(new Stroke(Brushes.LightBlue, 1), PlotStyle.Cross, "Oversold Top");
				AddPlot(new Stroke(Brushes.LightBlue, 2), PlotStyle.Line, "Oversold Bottom");
			}
			else if (State == State.DataLoaded)
			{
				minBars 	= Math.Max(PivotHighLeft + PivotHighRight, PivotLowLeft + PivotLowRight);
				isOnPrice 	= SourceType == RSICTC_Vars.Source_Type.On_Price;
				labelsDist 	= LabelsDistance * TickSize;
				
				SetBrushTransparencies();
				Init();
			}
		}
		
		public override string DisplayName
		{
			get { return Name; }
		}

		protected override void OnBarUpdate()
		{
			UpdateSources();
			if (RSI_Type == RSICTC_Vars.RSI_Type.Two_Sources_RSI)
				rsi[0] = rsiHl2[0] >= 50 ? rsiHighs[0] : rsiLows[0];
			
			ColorCandles();
				
			if(CurrentBar < minBars)
				return;
			
			HigherLower();
			
			bool sufficientLows = pivotLowBarIndex.Count >= 2;
			bool sufficientHighs = pivotHighBarIndex.Count >= 2;
			
			if (sufficientLows && pivotRSILows.Count >= 2)
			{
				DrawLowBreakouts();
				DrawBullishDiv();
			}
			
			if (sufficientHighs && pivotRSIHighs.Count >= 2)
			{
				DrawHighBreakouts();
				DrawBearishDiv();
			}
			
			if (sufficientHighs && sufficientLows)
				DrawRossHook();
			
			if (rsi[0] >= OverboughtThreshold)
				Overbought();
			else
				latestOverboughtBar = 0;
			
			if (rsi[0] <= OversoldThreshold)
				Oversold();
			else
				latestOversoldBar = 0;
		}
		
		private void ColorCandles()
		{
			Brush candlesColor = rsi[0] < OversoldThreshold ? OversoldCanleBrush : 
								(rsi[0] > OverboughtThreshold ? OverboughtCanleBrush : 
								(MA1[0] > MA2[0] ? MA1OverMA2CandleBrush : MA1UnderMA2CandleBrush));
			
			if (ColoredCandles || FullColoredCandles)
				BarBrush = candlesColor;
			
			if (FullColoredCandles)
				CandleOutlineBrush = candlesColor;
		}
		
		private void HigherLower()
		{
			if (highSource[PivotHighRight] == maxHighs[0])
			{
				pivotHighs.Insert(0, maxHighs[0]);
				pivotHighBarIndex.Insert(0, CurrentBar - PivotHighRight);
				DrawHighs();
			}
			
			if (rsi[PivotHighRight] == maxRSIHighs[0])
			{
				pivotRSIHighs.Insert(0, maxRSIHighs[0]);
				
				if (ShowRSITrend && pivotRSIHighs.Count >= 2)
					DrawRSITrendlinesHigh();
			}
			
			if (lowSource[PivotLowRight] == minLows[0])
			{
				pivotLows.Insert(0, minLows[0]);
				pivotLowBarIndex.Insert(0, CurrentBar - PivotLowRight);
				DrawLows();
			}
			
			if (rsi[PivotLowRight] == minRSILows[0])
			{
				pivotRSILows.Insert(0, minRSILows[0]);
				
				if (ShowRSITrend && pivotRSILows.Count >= 2)
					DrawRSITrendlinesLow();
			}
		}
		
		private void Overbought()
		{
			if (latestOverboughtBar == 0)
			{
				latestOverboughtBar = CurrentBar;
				
				OverboughtTop[0] = High[0];
				OverboughtBottom[0] = Low[0];
			}
			else
			{
				OverboughtTop[0] = Math.Max(OverboughtTop[1], High[0]);
				OverboughtBottom[0] = Math.Min(OverboughtBottom[1], Low[0]);
				
				for (int i = CurrentBar - latestOverboughtBar; i > 0; i--)
				{
					OverboughtTop[i] = OverboughtTop[0];
					OverboughtBottom[i] = OverboughtBottom[0];
				}
			}
		}
		
		private void Oversold()
		{
			if (latestOversoldBar == 0)
			{
				latestOversoldBar = CurrentBar;
				
				OversoldTop[0] = High[0];
				OversoldBottom[0] = Low[0];
			}
			else
			{
				OversoldTop[0] = Math.Max(OversoldTop[1], High[0]);
				OversoldBottom[0] = Math.Min(OversoldBottom[1], Low[0]);
				
				for (int i = CurrentBar - latestOversoldBar; i > 0; i--)
				{
					OversoldTop[i] = OversoldTop[0];
					OversoldBottom[i] = OversoldBottom[0];
				}
			}
		}
		
		#region Init & Update
		
		private void SetBrushTransparencies()
		{
			BearBrush = BearBrush.Clone();
			BearBrush.Opacity = (100 - DivTransparency) / 100.0;
			BearBrush.Freeze();
			
			BullBrush = BullBrush.Clone();
			BullBrush.Opacity = (100 - DivTransparency) / 100.0;
			BullBrush.Freeze();
			
			HiddenBearBrush = HiddenBearBrush.Clone();
			HiddenBearBrush.Opacity = (100 - DivHiddenTransparency) / 100.0;
			HiddenBearBrush.Freeze();
			
			HiddenBullBrush = HiddenBullBrush.Clone();
			HiddenBullBrush.Opacity = (100 - DivHiddenTransparency) / 100.0;
			HiddenBullBrush.Freeze();
			
			BreakHHBrush = BreakHHBrush.Clone();
			BreakHHBrush.Opacity = (100 - BreakTransparency) / 100.0;
			BreakHHBrush.Freeze();
			
			BreakLHBrush = BreakLHBrush.Clone();
			BreakLHBrush.Opacity = (100 - BreakTransparency) / 100.0;
			BreakLHBrush.Freeze();
			
			BreakHLBrush = BreakHLBrush.Clone();
			BreakHLBrush.Opacity = (100 - BreakTransparency) / 100.0;
			BreakHLBrush.Freeze();
			
			BreakLLBrush = BreakLLBrush.Clone();
			BreakLLBrush.Opacity = (100 - BreakTransparency) / 100.0;
			BreakLLBrush.Freeze();
		}
		
		private void Init()
		{
			pivotHighs 			= new List<double>();
			pivotLows 			= new List<double>();
			pivotRSIHighs		= new List<double>();
			pivotRSILows		= new List<double>();
			pivotHighBarIndex 	= new List<int>();
			pivotLowBarIndex 	= new List<int>();
			
			open			= new Series<double>(this);
			close 			= new Series<double>(this);
			high			= new Series<double>(this);
			low				= new Series<double>(this);
			hl2 			= new Series<double>(this);
			hlc3 			= new Series<double>(this);
			hlcc4 			= new Series<double>(this);
			ohlc4 			= new Series<double>(this);
			highSource 		= new Series<double>(this);
			lowSource 		= new Series<double>(this);
			
			rsiHighs 	= RSI(GetSource(HighRSISource), RSILength, 3).Value;
			rsiLows 	= RSI(GetSource(LowRSISource), RSILength, 3).Value;
			
			switch(RSI_Type)
			{
				case RSICTC_Vars.RSI_Type.RSI:
					rsi = rsiHighs;
					break;
				case RSICTC_Vars.RSI_Type.Two_Sources_RSI:
					rsi = new Series<double>(this);
					break;
				case RSICTC_Vars.RSI_Type.Connors_RSI:
					rsi = ConnorsRSI(GetSource(HighRSISource), ROCLength, RSILength, UpDownLength).Connors_RSI;
					break;
				default:
					break;
			}
			
			rsiHl2 		= RSI(GetSource(RSICTC_Vars.Price_Source.HL2), RSILength, 3).Value;
			Values[0]	= GetMovingAverage(GetSource(MA1Source), MA1Length, MA1Type);
			Values[1]	= GetMovingAverage(GetSource(MA2Source), MA2Length, MA2Type);
			highSource 	= isOnPrice ? GetSource(HighsSource) : rsi;
			lowSource 	= isOnPrice ? GetSource(LowsSource) : rsi;
			divHighs	= isOnPrice ? GetSource(HighsSource) : high;
			divLows		= isOnPrice ? GetSource(LowsSource) : low;
			maxHighs 	= MAX(highSource, PivotHighLeft + PivotHighRight);
			minLows 	= MIN(lowSource, PivotLowLeft + PivotLowRight);
			maxRSIHighs = MAX(rsi, PivotHighLeft + PivotHighRight);
			minRSILows 	= MIN(rsi, PivotLowLeft + PivotLowRight);
		}
		
		private void UpdateSources()
		{
			open[0]			= Open[0];
			close[0]		= Close[0];
			high[0]			= High[0];
			low[0]			= Low[0];
			hl2[0] 			= (High[0] + Low[0]) / 2;
			hlc3[0] 		= (High[0] + Low[0] + Close[0]) / 3;
			hlcc4[0] 		= (High[0] + Low[0] + Close[0] + Close[0]) / 4;
			ohlc4[0] 		= (Open[0] + High[0] + Low[0] + Close[0]) / 4;
		}
		
		#endregion
		
		#region Helper
		
		private Series<double> GetSource(RSICTC_Vars.Price_Source sourceType)
		{
			switch(sourceType)
			{
				case RSICTC_Vars.Price_Source.Close:
					return close;
				case RSICTC_Vars.Price_Source.Open:
					return open;
				case RSICTC_Vars.Price_Source.High:
					return high;
				case RSICTC_Vars.Price_Source.Low:
					return low;
				case RSICTC_Vars.Price_Source.HL2:
					return hl2;
				case RSICTC_Vars.Price_Source.HLC3:
					return hlc3;
				case RSICTC_Vars.Price_Source.HLCC4:
					return hlcc4;
				case RSICTC_Vars.Price_Source.OHLC4:
					return ohlc4;
				default:
					return close;
			}
		}
		
		private Series<double> GetMovingAverage(Series<double> source, int length, RSICTC_Vars.MA_Type type)
		{
			switch(type)
			{
				case RSICTC_Vars.MA_Type.SMA:
					return SMA(source, length).Value;
				case RSICTC_Vars.MA_Type.EMA:
					return EMA(source, length).Value;
				case RSICTC_Vars.MA_Type.SMMA:
					return SMMA(source, length).Value;
				case RSICTC_Vars.MA_Type.WMA:
					return WMA(source, length).Value;
				case RSICTC_Vars.MA_Type.VWMA:
					return VWMA(source, length).Value;
				default:
					return SMA(source, length).Value;
			}
		}
		
		private void ShowAlertPopUp(string message, Brush textBrush)
		{
			if (popUp != null)
				popUp.Dispatcher.InvokeAsync(new Action(() => { popUp.Close(); }));
			
			Globals.RandomDispatcher.InvokeAsync(new Action(() =>
			{
				popUp = new PopUpWindow()
				{
					Caption = "RSIChartTradingConcepts Alert",
					message = message,
					TextColor = textBrush
				};
				
				popUp.Show(); // open the window
				popUp.Activate(); // bring to the top
			}));
		}
		
		#endregion
		
		#region Draw
		
		private void DrawHighs()
		{
			int startX 	= PivotHighRight;
			int endX 	= Ghost ? 0 - (GhostLength - PivotHighRight) : 0;
			double y1 	= isOnPrice ? pivotHighs[0] : High[PivotHighRight];
			double y2 	= Math.Max(High[PivotHighRight], Open[PivotHighRight]);
			
		    if (pivotHighs.Count == 1)
			{
				Draw.Text(this, "HHLabel", "Higher High", PivotHighRight, High[PivotHighRight] + labelsDist, HigherHighTextBrush);
				
				hhTag 		= Draw.Line(this, "HHLine" + CurrentBar, startX, y1, endX, y1, HigherHighBrush).Tag;
				lhTag		= Draw.Line(this, "LHLine" + CurrentBar, startX, y1, endX, y1, HigherHighBrush).Tag;
				hh2Tag 		= Draw.Line(this, "HH2Line" + CurrentBar, startX, y2, endX, y2, HigherHighBrush).Tag;
				lh2Tag 		= Draw.Line(this, "LH2Line" + CurrentBar, startX, y2, endX, y2, HigherHighBrush).Tag;
				hhFillTag 	= Draw.Rectangle(this, "HHFill" + CurrentBar, true, startX, y1, endX, y2, Brushes.Transparent, HigherHighBrush, FillOpacity).Tag;
				lhFillTag 	= Draw.Rectangle(this, "LHFill" + CurrentBar, true, startX, y1, endX, y2, Brushes.Transparent, HigherHighBrush, FillOpacity).Tag;
			}
		    else
			{
		        if (pivotHighs[0] >= pivotHighs[1])
				{
					if (!Ghost)
					{
						RemoveDrawObject(hhTag);
						RemoveDrawObject(hh2Tag);
						RemoveDrawObject(hhFillTag);
					}
					
					Draw.Text(this, "HHLabel", "Higher High", PivotHighRight, High[PivotHighRight] + labelsDist, HigherHighTextBrush);
					
					hhTag 		= Draw.Line(this, "HHLine" + CurrentBar, startX, y1, endX, y1, HigherHighBrush).Tag;
					hh2Tag 		= Draw.Line(this, "HH2Line" + CurrentBar, startX, y2, endX, y2, HigherHighBrush).Tag;
					hhFillTag 	= Draw.Rectangle(this, "HHFill" + CurrentBar, true, startX, y1, endX, y2, Brushes.Transparent, HigherHighBrush, FillOpacity).Tag;
				}
		        else
				{
					if (!Ghost)
					{
						RemoveDrawObject(lhTag);
						RemoveDrawObject(lh2Tag);
						RemoveDrawObject(lhFillTag);
					}
					
					Draw.Text(this, "LHLabel", "Lower High", PivotHighRight, High[PivotHighRight] + labelsDist, LowerHighTextBrush);
					
					lhTag 		= Draw.Line(this, "LHLine" + CurrentBar, startX, y1, endX, y1, LowerHighBrush).Tag;
					lh2Tag 		= Draw.Line(this, "LH2Line" + CurrentBar, startX, y2, endX, y2, LowerHighBrush).Tag;
					lhFillTag 	= Draw.Rectangle(this, "LHFill" + CurrentBar, true, startX, y1, endX, y2, Brushes.Transparent, LowerHighBrush, FillOpacity).Tag;
				}
			}
		}
		
		private void DrawLows()
		{
			int startX 	= PivotLowRight;
			int endX 	= Ghost ? 0 - (GhostLength - PivotLowRight) : 0;
			double y1 	= isOnPrice ? pivotLows[0] : Low[PivotLowRight];
			double y2 	= Math.Min(Low[PivotLowRight], Open[PivotLowRight]);
			
		    if (pivotLows.Count == 1)
			{
				Draw.Text(this, "LLLabel", "Lower Low", PivotHighRight, High[PivotHighRight] - labelsDist, LowerLowTextBrush);
				
				llTag 		= Draw.Line(this, "LLLine" + CurrentBar, startX, y1, endX, y1, LowerLowBrush).Tag;
				hlTag		= Draw.Line(this, "HLLine" + CurrentBar, startX, y1, endX, y1, LowerLowBrush).Tag;
				ll2Tag 		= Draw.Line(this, "LL2Line" + CurrentBar, startX, y2, endX, y2, LowerLowBrush).Tag;
				hl2Tag 		= Draw.Line(this, "HL2Line" + CurrentBar, startX, y2, endX, y2, LowerLowBrush).Tag;
				llFillTag 	= Draw.Rectangle(this, "LLFill" + CurrentBar, true, startX, y1, endX, y2, Brushes.Transparent, LowerLowBrush, FillOpacity).Tag;
				hlFillTag 	= Draw.Rectangle(this, "HLFill" + CurrentBar, true, startX, y1, endX, y2, Brushes.Transparent, LowerLowBrush, FillOpacity).Tag;
			}
		    else
			{
		        if (pivotLows[0] <= pivotLows[1])
				{
					if (!Ghost)
					{
						RemoveDrawObject(llTag);
						RemoveDrawObject(ll2Tag);
						RemoveDrawObject(llFillTag);
					}
					
					Draw.Text(this, "LLLabel", "Lower Low", PivotHighRight, High[PivotHighRight] - labelsDist, LowerLowTextBrush);
					
					llTag 		= Draw.Line(this, "LLLine" + CurrentBar, startX, y1, endX, y1, LowerLowBrush).Tag;
					ll2Tag 		= Draw.Line(this, "LL2Line" + CurrentBar, startX, y2, endX, y2, LowerLowBrush).Tag;
					llFillTag 	= Draw.Rectangle(this, "LLFill" + CurrentBar, true, startX, y1, endX, y2, Brushes.Transparent, LowerLowBrush, FillOpacity).Tag;
				}
		        else
				{
					if (!Ghost)
					{
						RemoveDrawObject(hlTag);
						RemoveDrawObject(hl2Tag);
						RemoveDrawObject(hlFillTag);
					}
					
					Draw.Text(this, "HLLabel", "Higher Low", PivotHighRight, High[PivotHighRight] - labelsDist, HigherLowTextBrush);
					
					hlTag 		= Draw.Line(this, "HLLine" + CurrentBar, startX, y1, endX, y1, HigherLowBrush).Tag;
					hl2Tag 		= Draw.Line(this, "HL2Line" + CurrentBar, startX, y2, endX, y2, HigherLowBrush).Tag;
					hlFillTag 	= Draw.Rectangle(this, "HLFill" + CurrentBar, true, startX, y1, endX, y2, Brushes.Transparent, HigherLowBrush, FillOpacity).Tag;
				}
			}
		}
		
		private void DrawBullishDiv()
		{
			int barsAgo0 = CurrentBar - pivotLowBarIndex[0];
			int barsAgo1 = CurrentBar - pivotLowBarIndex[1];
			
			if (PlotBullish && pivotRSILows[0] > pivotRSILows[1] && pivotLows[0] < pivotLows[1])
				Draw.Line(this, "RegularBullish" + CurrentBar, barsAgo1, divLows[barsAgo1], barsAgo0, divLows[barsAgo0], BullBrush);
			
			if (PlotHiddenBullish && pivotRSILows[0] < pivotRSILows[1] && pivotLows[0] > pivotLows[1])
				Draw.Line(this, "HiddenBullish" + CurrentBar, barsAgo1, divLows[barsAgo1], barsAgo0, divLows[barsAgo0], HiddenBullBrush);
		}
		
		private void DrawBearishDiv()
		{
			int barsAgo0 = CurrentBar - pivotHighBarIndex[0];
			int barsAgo1 = CurrentBar - pivotHighBarIndex[1];
			
			if (PlotBearish && pivotRSIHighs[0] < pivotRSIHighs[1] && pivotHighs[0] > pivotHighs[1])
				Draw.Line(this, "RegularBearish" + CurrentBar, barsAgo1, divHighs[barsAgo1], barsAgo0, divHighs[barsAgo0], BearBrush);
			
			if (PlotHiddenBearish && pivotRSIHighs[0] > pivotRSIHighs[1] && pivotHighs[0] < pivotHighs[1])
				Draw.Line(this, "HiddenBearish" + CurrentBar, barsAgo1, divHighs[barsAgo1], barsAgo0, divHighs[barsAgo0], HiddenBearBrush);
		}
		
		private void DrawLowBreakouts()
		{
			int barsAgo = CurrentBar - pivotLowBarIndex[0];
			bool isBreakLL = Close[0] < divLows[barsAgo] && pivotLows[0] < pivotLows[1] && pivotRSILows[0] < pivotRSILows[1];
			bool isBreakHL = Close[0] < divLows[barsAgo] && pivotLows[0] > pivotLows[1] && pivotRSILows[0] > pivotRSILows[1];
			
			if (isBreakLL)
			{
				string message = "Breakdown of the LowerLow";
				
				if (ShowBreak)
				{
					RemoveDrawObject(breakLLTag);
					Draw.Line(this, "BreakLLLine" + CurrentBar, 0, Low[barsAgo] - TickSize, 0, Low[barsAgo] - labelsDist, BreakLLBrush);
					Draw.Text(this, breakLLTag, message, 0, Low[barsAgo] - labelsDist, BreakLLBrush);
				}
				
				if (PlayBreakAlertSound && State != State.Historical)
					PlaySound(breakAlertSound);
				
				if (ShowBreakAlert && State != State.Historical)
					ShowAlertPopUp(message, BreakLLBrush);
			}
			
			if (isBreakHL)
			{
				string message = "Breakdown of the HigherLow";
				
				if (ShowBreak)
				{
					RemoveDrawObject(breakHLTag);
					Draw.Line(this, "BreakHLLine" + CurrentBar, 0, Low[barsAgo] - TickSize, 0, Low[barsAgo] - labelsDist, BreakHLBrush);
					Draw.Text(this, breakHLTag, message, 0, Low[barsAgo] - labelsDist, BreakHLBrush);
				}
				
				if (PlayBreakAlertSound && State != State.Historical)
					PlaySound(breakAlertSound);
				
				if (ShowBreakAlert && State != State.Historical)
					ShowAlertPopUp(message, BreakHLBrush);
			}
		}
		
		private void DrawHighBreakouts()
		{
			int barsAgo = CurrentBar - pivotHighBarIndex[0];
			bool isBreakHH = Close[0] > divHighs[barsAgo] && pivotHighs[0] > pivotHighs[1] && pivotRSIHighs[0] > pivotRSIHighs[1];
			bool isBreakLH = Close[0] > divHighs[barsAgo] && pivotHighs[0] < pivotHighs[1] && pivotRSIHighs[0] < pivotRSIHighs[1];
			
			if (isBreakHH)
			{
				string message = "Breakout of the HigherHigh";
				
				if (ShowBreak)
				{
					RemoveDrawObject(breakHHTag);
					Draw.Line(this, "BreakHHLine" + CurrentBar, 0, High[barsAgo] + TickSize, 0, High[barsAgo] + labelsDist, BreakHHBrush);
					Draw.Text(this, breakHHTag, message, 0, High[barsAgo] + labelsDist, BreakHHBrush);
				}
				
				if (PlayBreakAlertSound && State != State.Historical)
					PlaySound(breakAlertSound);
				
				if (ShowBreakAlert && State != State.Historical)
					ShowAlertPopUp(message, BreakHHBrush);
			}
			
			if (isBreakLH)
			{
				string message = "Breakout of the LowerHigh";
				
				if (ShowBreak)
				{
					RemoveDrawObject(breakLHTag);
					Draw.Line(this, "BreakLHLine" + CurrentBar, 0, High[barsAgo] + TickSize, 0, High[barsAgo] + labelsDist, BreakLHBrush);
					Draw.Text(this, breakLHTag, message, 0, High[barsAgo] + labelsDist, BreakLHBrush);
				}
				
				if (PlayBreakAlertSound && State != State.Historical)
					PlaySound(breakAlertSound);
				
				if (ShowBreakAlert && State != State.Historical)
					ShowAlertPopUp(message, BreakLHBrush);
			}
		}
		
		private void DrawRSITrendlinesHigh()
		{
			if (pivotRSIHighs[0] > pivotRSIHighs[1])
			{
				string message = string.Format("RSI Higher High -{0}-", Math.Round(pivotRSIHighs[0], 0));
				
				Draw.Text(this, "RSIHHLabel", message, PivotHighRight, High[PivotHighRight] + labelsDist, HigherHighBrush);
				Draw.Line(this, "RSIHHLine", PivotHighRight, Close[PivotHighRight], 0, Close[PivotHighRight], HigherHighBrush);
			}
			else if (pivotRSIHighs[0] < pivotRSIHighs[1])
			{
				string message = string.Format("RSI Lower High -{0}-", Math.Round(pivotRSIHighs[0], 0));
				
				Draw.Text(this, "RSILHLabel", message, PivotHighRight, High[PivotHighRight] + labelsDist, LowerHighBrush);
				Draw.Line(this, "RSILHLine", PivotHighRight, Close[PivotHighRight], 0, Close[PivotHighRight], LowerHighBrush);
			}
		}
		
		private void DrawRSITrendlinesLow()
		{
			if (pivotRSILows[0] < pivotRSILows[1])
			{
				string message = string.Format("RSI Lower Low -{0}-", Math.Round(pivotRSILows[0], 0));
				
				Draw.Text(this, "RSILLLabel", message, PivotHighRight, Low[PivotLowRight] - labelsDist, LowerLowBrush);
				Draw.Line(this, "RSILLLine", PivotLowRight, Close[PivotLowRight], 0, Close[PivotLowRight], LowerLowBrush);
			}
			else if (pivotRSILows[0] > pivotRSILows[1])
			{
				string message = string.Format("RSI Higher Low -{0}-", Math.Round(pivotRSILows[0], 0));
				
				Draw.Text(this, "RSIHLLabel", message, PivotHighRight, Low[PivotLowRight] - labelsDist, HigherLowBrush);
				Draw.Line(this, "RSIHLLine", PivotLowRight, Close[PivotLowRight], 0, Close[PivotLowRight], HigherLowBrush);
			}
		}
		
		private void DrawRossHook()
		{
			if (pivotHighBarIndex[1] < pivotLowBarIndex[1] && pivotLowBarIndex[1] < pivotHighBarIndex[0] && 
				pivotHighBarIndex[0] < pivotLowBarIndex[0] && pivotLows[0] > pivotLows[1])
			{ // Bullish
				// Bull -> Breakout at last high -> Line until no hook or until breakout
				// Line from low1 to high0 and line from high0 to low0
				
				string hookTag = "BullRossHook" + (Ghost ? pivotHighBarIndex[1].ToString() : "");
				string lineTag = "BullRossHookLine" + (Ghost ? pivotHighBarIndex[1].ToString() : "");
				
				int x1 = CurrentBar - pivotLowBarIndex[1];
				int x2 = CurrentBar - pivotHighBarIndex[0];
				int x3 = CurrentBar - pivotLowBarIndex[0];
				
				Draw.Line(this, hookTag + 1, false, x1, divLows[x1], x2, divHighs[x2], RossHookBullishBrush, DashStyleHelper.Solid, 2);
				Draw.Line(this, hookTag + 2, false, x2, divHighs[x2], x3, divLows[x3], RossHookBullishBrush, DashStyleHelper.Solid, 2);
				Draw.Line(this, lineTag, false, x2, divHighs[x2], 0, divHighs[x2], RossHookBullishBrush, DashStyleHelper.DashDot, 1);
			}
			else if (pivotLowBarIndex[1] < pivotHighBarIndex[1] &&  pivotHighBarIndex[1] < pivotLowBarIndex[0] && 
				pivotLowBarIndex[0] < pivotHighBarIndex[0] && pivotHighs[0] < pivotHighs[1])
			{ // Bearish
				// Bull -> Breakout at last low -> Line until no hook or until breakout
				// Line from high1 to low0 and line from low0 to high0
				
				string hookTag = "BearRossHook" + (Ghost ? pivotLowBarIndex[1].ToString() : "");
				string lineTag = "BearRossHookLine" + (Ghost ? pivotLowBarIndex[1].ToString() : "");
				
				int x1 = CurrentBar - pivotHighBarIndex[1];
				int x2 = CurrentBar - pivotLowBarIndex[0];
				int x3 = CurrentBar - pivotHighBarIndex[0];
				
				Draw.Line(this, hookTag + 1, false, x1, divHighs[x1], x2, divLows[x2], RossHookBearishBrush, DashStyleHelper.Solid, 2);
				Draw.Line(this, hookTag + 2, false, x2, divLows[x2], x3, divHighs[x3], RossHookBearishBrush, DashStyleHelper.Solid, 2);
				Draw.Line(this, lineTag, false, x2, divLows[x2], 0, divLows[x2], RossHookBearishBrush, DashStyleHelper.DashDot, 1);
			}
		}
		
		#endregion
		
		#region Properties
		
		#region Length Left / Right
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Pivot High Left", GroupName = RSICTC_Vars.LenLRCat, Order = 1)]
		public int PivotHighLeft { get; set; }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Pivot High Right", GroupName = RSICTC_Vars.LenLRCat, Order = 2)]
		public int PivotHighRight { get; set; }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Pivot Low Left", GroupName = RSICTC_Vars.LenLRCat, Order = 3)]
		public int PivotLowLeft { get; set; }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Pivot Low Right", GroupName = RSICTC_Vars.LenLRCat, Order = 4)]
		public int PivotLowRight { get; set; }
		
		#endregion
		
		#region Trend Lines
		
		[NinjaScriptProperty]
		[Display(Name = "Higher High Color", GroupName = RSICTC_Vars.TrendLinesCat, Order = 1)]
		public Brush HigherHighBrush { get; set; }
		
		[Browsable(false)]
		public string HigherHighBrushSerialize
		{
			get { return Serialize.BrushToString(HigherHighBrush); }
   			set { HigherHighBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Higher High Text Color", GroupName = RSICTC_Vars.TrendLinesCat, Order = 2)]
		public Brush HigherHighTextBrush { get; set; }
		
		[Browsable(false)]
		public string HigherHighTextBrushSerialize
		{
			get { return Serialize.BrushToString(HigherHighTextBrush); }
   			set { HigherHighTextBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Higher Low Color", GroupName = RSICTC_Vars.TrendLinesCat, Order = 3)]
		public Brush HigherLowBrush { get; set; }
		
		[Browsable(false)]
		public string HigherLowBrushSerialize
		{
			get { return Serialize.BrushToString(HigherLowBrush); }
   			set { HigherLowBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Higher Low Text Color", GroupName = RSICTC_Vars.TrendLinesCat, Order = 4)]
		public Brush HigherLowTextBrush { get; set; }
		
		[Browsable(false)]
		public string HigherLowTextBrushSerialize
		{
			get { return Serialize.BrushToString(HigherLowTextBrush); }
   			set { HigherLowTextBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Lower Low Color", GroupName = RSICTC_Vars.TrendLinesCat, Order = 5)]
		public Brush LowerLowBrush { get; set; }
		
		[Browsable(false)]
		public string LowerLowBrushSerialize
		{
			get { return Serialize.BrushToString(LowerLowBrush); }
   			set { LowerLowBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Lower Low Text Color", GroupName = RSICTC_Vars.TrendLinesCat, Order = 6)]
		public Brush LowerLowTextBrush { get; set; }
		
		[Browsable(false)]
		public string LowerLowTextBrushSerialize
		{
			get { return Serialize.BrushToString(LowerLowTextBrush); }
   			set { LowerLowTextBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Lower High Color", GroupName = RSICTC_Vars.TrendLinesCat, Order = 7)]
		public Brush LowerHighBrush { get; set; }
		
		[Browsable(false)]
		public string LowerHighBrushSerialize
		{
			get { return Serialize.BrushToString(LowerHighBrush); }
   			set { LowerHighBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Lower High Text Color", GroupName = RSICTC_Vars.TrendLinesCat, Order = 8)]
		public Brush LowerHighTextBrush { get; set; }
		
		[Browsable(false)]
		public string LowerHighTextBrushSerialize
		{
			get { return Serialize.BrushToString(LowerHighTextBrush); }
   			set { LowerHighTextBrush = Serialize.StringToBrush(value); }
		}
		
		#endregion
		
		[Range(0, 100), NinjaScriptProperty]
		[Display(Name = "Fill Opacity", GroupName = RSICTC_Vars.FillCat, Order = 1)]
		public int FillOpacity { get; set; }
		
		[Range(0, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Labels Distance", GroupName = RSICTC_Vars.LabelsCat, Order = 1)]
		public int LabelsDistance { get; set; }
		
		#region RSI
		
		[NinjaScriptProperty]
		[Display(Name = "RSI Type", Description = "If the RSI TYPE is not 2 SOURCES RSI, select close, close. 2 source is meant for Highest and Lowest", GroupName = RSICTC_Vars.RSICat, Order = 1)]
		public RSICTC_Vars.RSI_Type RSI_Type { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "High RSI Source", GroupName = RSICTC_Vars.RSICat, Order = 2)]
		public RSICTC_Vars.Price_Source HighRSISource { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Low RSI Source", GroupName = RSICTC_Vars.RSICat, Order = 3)]
		public RSICTC_Vars.Price_Source LowRSISource { get; set; }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "RSI Length", GroupName = RSICTC_Vars.RSICat, Order = 4)]
		public int RSILength { get; set; }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "UpDown Length", Description = "If RSI TYPE is CONORS RSI.", GroupName = RSICTC_Vars.RSICat, Order = 5)]
		public int UpDownLength { get; set; }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "ROC Length", Description = "If RSI TYPE is CONORS RSI.", GroupName = RSICTC_Vars.RSICat, Order = 6)]
		public int ROCLength { get; set; }
		
		[Range(1, 100), NinjaScriptProperty]
		[Display(Name = "Overbought Threshold", GroupName = RSICTC_Vars.RSICat, Order = 7)]
		public int OverboughtThreshold { get; set; }
		
		[Range(1, 100), NinjaScriptProperty]
		[Display(Name = "Oversold Threshold", GroupName = RSICTC_Vars.RSICat, Order = 8)]
		public int OversoldThreshold { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Show RSI Trend Lines", GroupName = RSICTC_Vars.RSICat, Order = 9)]
		public bool ShowRSITrend { get; set; }
		
		#endregion
		
		#region Source
		
		[NinjaScriptProperty]
		[Display(Name = "Version", GroupName = RSICTC_Vars.SourceCat, Order = 1)]
		public RSICTC_Vars.Source_Type SourceType { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Highs Source", GroupName = RSICTC_Vars.SourceCat, Order = 2)]
		public RSICTC_Vars.Price_Source HighsSource { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Lows Source", GroupName = RSICTC_Vars.SourceCat, Order = 3)]
		public RSICTC_Vars.Price_Source LowsSource { get; set; }
		
		#endregion
		
		#region MA Settings
		
		[NinjaScriptProperty]
		[Display(Name = "MA1 Source", GroupName = RSICTC_Vars.MACat, Order = 1)]
		public RSICTC_Vars.Price_Source MA1Source { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "MA1 Type", GroupName = RSICTC_Vars.MACat, Order = 2)]
		public RSICTC_Vars.MA_Type MA1Type { get; set; }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "MA1 Length", GroupName = RSICTC_Vars.MACat, Order = 3)]
		public int MA1Length { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "MA2 Source", GroupName = RSICTC_Vars.MACat, Order = 5)]
		public RSICTC_Vars.Price_Source MA2Source { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "MA2 Type", GroupName = RSICTC_Vars.MACat, Order = 6)]
		public RSICTC_Vars.MA_Type MA2Type { get; set; }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "MA2 Length", GroupName = RSICTC_Vars.MACat, Order = 7)]
		public int MA2Length { get; set; }
		
		#endregion
		
		#region Divergence
		
		[NinjaScriptProperty]
		[Display(Name = "Plot Bullish", GroupName = RSICTC_Vars.DivergenceCat, Order = 3)]
		public bool PlotBullish { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Plot Hidden Bullish", GroupName = RSICTC_Vars.DivergenceCat, Order = 4)]
		public bool PlotHiddenBullish { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Plot Bearish", GroupName = RSICTC_Vars.DivergenceCat, Order = 5)]
		public bool PlotBearish { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Plot Hidden Bearish", GroupName = RSICTC_Vars.DivergenceCat, Order = 6)]
		public bool PlotHiddenBearish { get; set; }
		
		[Range(0, 100), NinjaScriptProperty]
		[Display(Name = "Transparency", GroupName = RSICTC_Vars.DivergenceCat, Order = 7)]
		public int DivTransparency { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Bear Color", GroupName = RSICTC_Vars.DivergenceCat, Order = 8)]
		public Brush BearBrush { get; set; }
		
		[Browsable(false)]
		public string BearBrushSerialize
		{
			get { return Serialize.BrushToString(BearBrush); }
   			set { BearBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Bull Color", GroupName = RSICTC_Vars.DivergenceCat, Order = 9)]
		public Brush BullBrush { get; set; }
		
		[Browsable(false)]
		public string BullBrushSerialize
		{
			get { return Serialize.BrushToString(BullBrush); }
   			set { BullBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(0, 100), NinjaScriptProperty]
		[Display(Name = "Hidden Transparency", GroupName = RSICTC_Vars.DivergenceCat, Order = 10)]
		public int DivHiddenTransparency { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Hidden Bull Color", GroupName = RSICTC_Vars.DivergenceCat, Order = 11)]
		public Brush HiddenBullBrush { get; set; }
		
		[Browsable(false)]
		public string HiddenBullBrushSerialize
		{
			get { return Serialize.BrushToString(HiddenBullBrush); }
   			set { HiddenBullBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Hidden Bear Color", GroupName = RSICTC_Vars.DivergenceCat, Order = 12)]
		public Brush HiddenBearBrush { get; set; }
		
		[Browsable(false)]
		public string HiddenBearBrushSerialize
		{
			get { return Serialize.BrushToString(HiddenBearBrush); }
   			set { HiddenBearBrush = Serialize.StringToBrush(value); }
		}
		
		#endregion
		
		#region Breakout/Breakdown
		
		[NinjaScriptProperty]
		[Display(Name = "Show Labels & Lines", GroupName = RSICTC_Vars.BreakCat, Order = 1)]
		public bool ShowBreak { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Show PopUp Alert", GroupName = RSICTC_Vars.BreakCat, Order = 2)]
		public bool ShowBreakAlert { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Play Alert Sound", GroupName = RSICTC_Vars.BreakCat, Order = 3)]
		public bool PlayBreakAlertSound { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Higher High Color", GroupName = RSICTC_Vars.BreakCat, Order = 8)]
		public Brush BreakHHBrush { get; set; }
		
		[Browsable(false)]
		public string BreakHHBrushSerialize
		{
			get { return Serialize.BrushToString(BreakHHBrush); }
   			set { BreakHHBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Lower High Color", GroupName = RSICTC_Vars.BreakCat, Order = 9)]
		public Brush BreakLHBrush { get; set; }
		
		[Browsable(false)]
		public string BreakLHBrushSerialize
		{
			get { return Serialize.BrushToString(BreakLHBrush); }
   			set { BreakLHBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Lower Low Color", GroupName = RSICTC_Vars.BreakCat, Order = 11)]
		public Brush BreakLLBrush { get; set; }
		
		[Browsable(false)]
		public string BreakLLBrushSerialize
		{
			get { return Serialize.BrushToString(BreakLLBrush); }
   			set { BreakLLBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Higher Low Color", GroupName = RSICTC_Vars.BreakCat, Order = 12)]
		public Brush BreakHLBrush { get; set; }
		
		[Browsable(false)]
		public string BreakHLBrushSerialize
		{
			get { return Serialize.BrushToString(BreakHLBrush); }
   			set { BreakHLBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(0, 100), NinjaScriptProperty]
		[Display(Name = "Transparency", GroupName = RSICTC_Vars.BreakCat, Order = 13)]
		public int BreakTransparency { get; set; }
		
		#endregion
		
		#region Ghost
		
		[NinjaScriptProperty]
		[Display(Name = "Ghost Lines", GroupName = RSICTC_Vars.GhostCat, Order = 1)]
		public bool Ghost { get; set; }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Ghost Length", GroupName = RSICTC_Vars.GhostCat, Order = 2)]
		public int GhostLength { get; set; }
		
		#endregion
		
		#region Candles Color
		
		[NinjaScriptProperty]
		[Display(Name = "Colored Candles", GroupName = RSICTC_Vars.CandlesCat, Order = 1)]
		public bool ColoredCandles { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Full Colored Candles", Description = "If this set to true, it will override the 'COLORED CANDLES'", GroupName = RSICTC_Vars.CandlesCat, Order = 2)]
		public bool FullColoredCandles { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Oversold Candle Color", GroupName = RSICTC_Vars.CandlesCat, Order = 3)]
		public Brush OversoldCanleBrush { get; set; }
		
		[Browsable(false)]
		public string OversoldCanleBrushSerialize
		{
			get { return Serialize.BrushToString(OversoldCanleBrush); }
   			set { OversoldCanleBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Overbought Candle Color", GroupName = RSICTC_Vars.CandlesCat, Order = 4)]
		public Brush OverboughtCanleBrush { get; set; }
		
		[Browsable(false)]
		public string OverboughtCanleBrushSerialize
		{
			get { return Serialize.BrushToString(OverboughtCanleBrush); }
   			set { OverboughtCanleBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "MA1 over MA2 Candle Color", GroupName = RSICTC_Vars.CandlesCat, Order = 5)]
		public Brush MA1OverMA2CandleBrush { get; set; }
		
		[Browsable(false)]
		public string MA1OverMA2CandleBrushSerialize
		{
			get { return Serialize.BrushToString(MA1OverMA2CandleBrush); }
   			set { MA1OverMA2CandleBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "MA1 under MA2 Candle Color", GroupName = RSICTC_Vars.CandlesCat, Order = 6)]
		public Brush MA1UnderMA2CandleBrush { get; set; }
		
		[Browsable(false)]
		public string MA1UnderMA2CandleBrushSerialize
		{
			get { return Serialize.BrushToString(MA1UnderMA2CandleBrush); }
   			set { MA1UnderMA2CandleBrush = Serialize.StringToBrush(value); }
		}
		
		#endregion
		
		#region Ross Hook
		
		[NinjaScriptProperty]
		[Display(Name = "Bullish Brush", GroupName = RSICTC_Vars.RossHookCat, Order = 2)]
		public Brush RossHookBullishBrush { get; set; }
		
		[Browsable(false)]
		public string RossHookBullishBrushSerialize
		{
			get { return Serialize.BrushToString(RossHookBullishBrush); }
   			set { RossHookBullishBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Bearish Brush", GroupName = RSICTC_Vars.RossHookCat, Order = 3)]
		public Brush RossHookBearishBrush { get; set; }
		
		[Browsable(false)]
		public string RossHookBearishBrushSerialize
		{
			get { return Serialize.BrushToString(RossHookBearishBrush); }
   			set { RossHookBearishBrush = Serialize.StringToBrush(value); }
		}
		
		#endregion
		
		#endregion

		#region Misc
		[XmlIgnore]
		[Browsable(false)]
		public Series<double> MA1 { get {return Values[0];} }
		
		[XmlIgnore]
		[Browsable(false)]
		public Series<double> MA2 { get {return Values[1];} }
		
		[XmlIgnore]
		[Browsable(false)]
		public Series<double> OverboughtTop { get {return Values[2];} }
		
		[XmlIgnore]
		[Browsable(false)]
		public Series<double> OverboughtBottom { get {return Values[3];} }
		
		[XmlIgnore]
		[Browsable(false)]
		public Series<double> OversoldTop { get {return Values[4];} }
		
		[XmlIgnore]
		[Browsable(false)]
		public Series<double> OversoldBottom { get {return Values[5];} }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private RSIChartTradingConcepts[] cacheRSIChartTradingConcepts;
		public RSIChartTradingConcepts RSIChartTradingConcepts(int pivotHighLeft, int pivotHighRight, int pivotLowLeft, int pivotLowRight, Brush higherHighBrush, Brush higherHighTextBrush, Brush higherLowBrush, Brush higherLowTextBrush, Brush lowerLowBrush, Brush lowerLowTextBrush, Brush lowerHighBrush, Brush lowerHighTextBrush, int fillOpacity, int labelsDistance, RSICTC_Vars.RSI_Type rSI_Type, RSICTC_Vars.Price_Source highRSISource, RSICTC_Vars.Price_Source lowRSISource, int rSILength, int upDownLength, int rOCLength, int overboughtThreshold, int oversoldThreshold, bool showRSITrend, RSICTC_Vars.Source_Type sourceType, RSICTC_Vars.Price_Source highsSource, RSICTC_Vars.Price_Source lowsSource, RSICTC_Vars.Price_Source mA1Source, RSICTC_Vars.MA_Type mA1Type, int mA1Length, RSICTC_Vars.Price_Source mA2Source, RSICTC_Vars.MA_Type mA2Type, int mA2Length, bool plotBullish, bool plotHiddenBullish, bool plotBearish, bool plotHiddenBearish, int divTransparency, Brush bearBrush, Brush bullBrush, int divHiddenTransparency, Brush hiddenBullBrush, Brush hiddenBearBrush, bool showBreak, bool showBreakAlert, bool playBreakAlertSound, Brush breakHHBrush, Brush breakLHBrush, Brush breakLLBrush, Brush breakHLBrush, int breakTransparency, bool ghost, int ghostLength, bool coloredCandles, bool fullColoredCandles, Brush oversoldCanleBrush, Brush overboughtCanleBrush, Brush mA1OverMA2CandleBrush, Brush mA1UnderMA2CandleBrush, Brush rossHookBullishBrush, Brush rossHookBearishBrush)
		{
			return RSIChartTradingConcepts(Input, pivotHighLeft, pivotHighRight, pivotLowLeft, pivotLowRight, higherHighBrush, higherHighTextBrush, higherLowBrush, higherLowTextBrush, lowerLowBrush, lowerLowTextBrush, lowerHighBrush, lowerHighTextBrush, fillOpacity, labelsDistance, rSI_Type, highRSISource, lowRSISource, rSILength, upDownLength, rOCLength, overboughtThreshold, oversoldThreshold, showRSITrend, sourceType, highsSource, lowsSource, mA1Source, mA1Type, mA1Length, mA2Source, mA2Type, mA2Length, plotBullish, plotHiddenBullish, plotBearish, plotHiddenBearish, divTransparency, bearBrush, bullBrush, divHiddenTransparency, hiddenBullBrush, hiddenBearBrush, showBreak, showBreakAlert, playBreakAlertSound, breakHHBrush, breakLHBrush, breakLLBrush, breakHLBrush, breakTransparency, ghost, ghostLength, coloredCandles, fullColoredCandles, oversoldCanleBrush, overboughtCanleBrush, mA1OverMA2CandleBrush, mA1UnderMA2CandleBrush, rossHookBullishBrush, rossHookBearishBrush);
		}

		public RSIChartTradingConcepts RSIChartTradingConcepts(ISeries<double> input, int pivotHighLeft, int pivotHighRight, int pivotLowLeft, int pivotLowRight, Brush higherHighBrush, Brush higherHighTextBrush, Brush higherLowBrush, Brush higherLowTextBrush, Brush lowerLowBrush, Brush lowerLowTextBrush, Brush lowerHighBrush, Brush lowerHighTextBrush, int fillOpacity, int labelsDistance, RSICTC_Vars.RSI_Type rSI_Type, RSICTC_Vars.Price_Source highRSISource, RSICTC_Vars.Price_Source lowRSISource, int rSILength, int upDownLength, int rOCLength, int overboughtThreshold, int oversoldThreshold, bool showRSITrend, RSICTC_Vars.Source_Type sourceType, RSICTC_Vars.Price_Source highsSource, RSICTC_Vars.Price_Source lowsSource, RSICTC_Vars.Price_Source mA1Source, RSICTC_Vars.MA_Type mA1Type, int mA1Length, RSICTC_Vars.Price_Source mA2Source, RSICTC_Vars.MA_Type mA2Type, int mA2Length, bool plotBullish, bool plotHiddenBullish, bool plotBearish, bool plotHiddenBearish, int divTransparency, Brush bearBrush, Brush bullBrush, int divHiddenTransparency, Brush hiddenBullBrush, Brush hiddenBearBrush, bool showBreak, bool showBreakAlert, bool playBreakAlertSound, Brush breakHHBrush, Brush breakLHBrush, Brush breakLLBrush, Brush breakHLBrush, int breakTransparency, bool ghost, int ghostLength, bool coloredCandles, bool fullColoredCandles, Brush oversoldCanleBrush, Brush overboughtCanleBrush, Brush mA1OverMA2CandleBrush, Brush mA1UnderMA2CandleBrush, Brush rossHookBullishBrush, Brush rossHookBearishBrush)
		{
			if (cacheRSIChartTradingConcepts != null)
				for (int idx = 0; idx < cacheRSIChartTradingConcepts.Length; idx++)
					if (cacheRSIChartTradingConcepts[idx] != null && cacheRSIChartTradingConcepts[idx].PivotHighLeft == pivotHighLeft && cacheRSIChartTradingConcepts[idx].PivotHighRight == pivotHighRight && cacheRSIChartTradingConcepts[idx].PivotLowLeft == pivotLowLeft && cacheRSIChartTradingConcepts[idx].PivotLowRight == pivotLowRight && cacheRSIChartTradingConcepts[idx].HigherHighBrush == higherHighBrush && cacheRSIChartTradingConcepts[idx].HigherHighTextBrush == higherHighTextBrush && cacheRSIChartTradingConcepts[idx].HigherLowBrush == higherLowBrush && cacheRSIChartTradingConcepts[idx].HigherLowTextBrush == higherLowTextBrush && cacheRSIChartTradingConcepts[idx].LowerLowBrush == lowerLowBrush && cacheRSIChartTradingConcepts[idx].LowerLowTextBrush == lowerLowTextBrush && cacheRSIChartTradingConcepts[idx].LowerHighBrush == lowerHighBrush && cacheRSIChartTradingConcepts[idx].LowerHighTextBrush == lowerHighTextBrush && cacheRSIChartTradingConcepts[idx].FillOpacity == fillOpacity && cacheRSIChartTradingConcepts[idx].LabelsDistance == labelsDistance && cacheRSIChartTradingConcepts[idx].RSI_Type == rSI_Type && cacheRSIChartTradingConcepts[idx].HighRSISource == highRSISource && cacheRSIChartTradingConcepts[idx].LowRSISource == lowRSISource && cacheRSIChartTradingConcepts[idx].RSILength == rSILength && cacheRSIChartTradingConcepts[idx].UpDownLength == upDownLength && cacheRSIChartTradingConcepts[idx].ROCLength == rOCLength && cacheRSIChartTradingConcepts[idx].OverboughtThreshold == overboughtThreshold && cacheRSIChartTradingConcepts[idx].OversoldThreshold == oversoldThreshold && cacheRSIChartTradingConcepts[idx].ShowRSITrend == showRSITrend && cacheRSIChartTradingConcepts[idx].SourceType == sourceType && cacheRSIChartTradingConcepts[idx].HighsSource == highsSource && cacheRSIChartTradingConcepts[idx].LowsSource == lowsSource && cacheRSIChartTradingConcepts[idx].MA1Source == mA1Source && cacheRSIChartTradingConcepts[idx].MA1Type == mA1Type && cacheRSIChartTradingConcepts[idx].MA1Length == mA1Length && cacheRSIChartTradingConcepts[idx].MA2Source == mA2Source && cacheRSIChartTradingConcepts[idx].MA2Type == mA2Type && cacheRSIChartTradingConcepts[idx].MA2Length == mA2Length && cacheRSIChartTradingConcepts[idx].PlotBullish == plotBullish && cacheRSIChartTradingConcepts[idx].PlotHiddenBullish == plotHiddenBullish && cacheRSIChartTradingConcepts[idx].PlotBearish == plotBearish && cacheRSIChartTradingConcepts[idx].PlotHiddenBearish == plotHiddenBearish && cacheRSIChartTradingConcepts[idx].DivTransparency == divTransparency && cacheRSIChartTradingConcepts[idx].BearBrush == bearBrush && cacheRSIChartTradingConcepts[idx].BullBrush == bullBrush && cacheRSIChartTradingConcepts[idx].DivHiddenTransparency == divHiddenTransparency && cacheRSIChartTradingConcepts[idx].HiddenBullBrush == hiddenBullBrush && cacheRSIChartTradingConcepts[idx].HiddenBearBrush == hiddenBearBrush && cacheRSIChartTradingConcepts[idx].ShowBreak == showBreak && cacheRSIChartTradingConcepts[idx].ShowBreakAlert == showBreakAlert && cacheRSIChartTradingConcepts[idx].PlayBreakAlertSound == playBreakAlertSound && cacheRSIChartTradingConcepts[idx].BreakHHBrush == breakHHBrush && cacheRSIChartTradingConcepts[idx].BreakLHBrush == breakLHBrush && cacheRSIChartTradingConcepts[idx].BreakLLBrush == breakLLBrush && cacheRSIChartTradingConcepts[idx].BreakHLBrush == breakHLBrush && cacheRSIChartTradingConcepts[idx].BreakTransparency == breakTransparency && cacheRSIChartTradingConcepts[idx].Ghost == ghost && cacheRSIChartTradingConcepts[idx].GhostLength == ghostLength && cacheRSIChartTradingConcepts[idx].ColoredCandles == coloredCandles && cacheRSIChartTradingConcepts[idx].FullColoredCandles == fullColoredCandles && cacheRSIChartTradingConcepts[idx].OversoldCanleBrush == oversoldCanleBrush && cacheRSIChartTradingConcepts[idx].OverboughtCanleBrush == overboughtCanleBrush && cacheRSIChartTradingConcepts[idx].MA1OverMA2CandleBrush == mA1OverMA2CandleBrush && cacheRSIChartTradingConcepts[idx].MA1UnderMA2CandleBrush == mA1UnderMA2CandleBrush && cacheRSIChartTradingConcepts[idx].RossHookBullishBrush == rossHookBullishBrush && cacheRSIChartTradingConcepts[idx].RossHookBearishBrush == rossHookBearishBrush && cacheRSIChartTradingConcepts[idx].EqualsInput(input))
						return cacheRSIChartTradingConcepts[idx];
			return CacheIndicator<RSIChartTradingConcepts>(new RSIChartTradingConcepts(){ PivotHighLeft = pivotHighLeft, PivotHighRight = pivotHighRight, PivotLowLeft = pivotLowLeft, PivotLowRight = pivotLowRight, HigherHighBrush = higherHighBrush, HigherHighTextBrush = higherHighTextBrush, HigherLowBrush = higherLowBrush, HigherLowTextBrush = higherLowTextBrush, LowerLowBrush = lowerLowBrush, LowerLowTextBrush = lowerLowTextBrush, LowerHighBrush = lowerHighBrush, LowerHighTextBrush = lowerHighTextBrush, FillOpacity = fillOpacity, LabelsDistance = labelsDistance, RSI_Type = rSI_Type, HighRSISource = highRSISource, LowRSISource = lowRSISource, RSILength = rSILength, UpDownLength = upDownLength, ROCLength = rOCLength, OverboughtThreshold = overboughtThreshold, OversoldThreshold = oversoldThreshold, ShowRSITrend = showRSITrend, SourceType = sourceType, HighsSource = highsSource, LowsSource = lowsSource, MA1Source = mA1Source, MA1Type = mA1Type, MA1Length = mA1Length, MA2Source = mA2Source, MA2Type = mA2Type, MA2Length = mA2Length, PlotBullish = plotBullish, PlotHiddenBullish = plotHiddenBullish, PlotBearish = plotBearish, PlotHiddenBearish = plotHiddenBearish, DivTransparency = divTransparency, BearBrush = bearBrush, BullBrush = bullBrush, DivHiddenTransparency = divHiddenTransparency, HiddenBullBrush = hiddenBullBrush, HiddenBearBrush = hiddenBearBrush, ShowBreak = showBreak, ShowBreakAlert = showBreakAlert, PlayBreakAlertSound = playBreakAlertSound, BreakHHBrush = breakHHBrush, BreakLHBrush = breakLHBrush, BreakLLBrush = breakLLBrush, BreakHLBrush = breakHLBrush, BreakTransparency = breakTransparency, Ghost = ghost, GhostLength = ghostLength, ColoredCandles = coloredCandles, FullColoredCandles = fullColoredCandles, OversoldCanleBrush = oversoldCanleBrush, OverboughtCanleBrush = overboughtCanleBrush, MA1OverMA2CandleBrush = mA1OverMA2CandleBrush, MA1UnderMA2CandleBrush = mA1UnderMA2CandleBrush, RossHookBullishBrush = rossHookBullishBrush, RossHookBearishBrush = rossHookBearishBrush }, input, ref cacheRSIChartTradingConcepts);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.RSIChartTradingConcepts RSIChartTradingConcepts(int pivotHighLeft, int pivotHighRight, int pivotLowLeft, int pivotLowRight, Brush higherHighBrush, Brush higherHighTextBrush, Brush higherLowBrush, Brush higherLowTextBrush, Brush lowerLowBrush, Brush lowerLowTextBrush, Brush lowerHighBrush, Brush lowerHighTextBrush, int fillOpacity, int labelsDistance, RSICTC_Vars.RSI_Type rSI_Type, RSICTC_Vars.Price_Source highRSISource, RSICTC_Vars.Price_Source lowRSISource, int rSILength, int upDownLength, int rOCLength, int overboughtThreshold, int oversoldThreshold, bool showRSITrend, RSICTC_Vars.Source_Type sourceType, RSICTC_Vars.Price_Source highsSource, RSICTC_Vars.Price_Source lowsSource, RSICTC_Vars.Price_Source mA1Source, RSICTC_Vars.MA_Type mA1Type, int mA1Length, RSICTC_Vars.Price_Source mA2Source, RSICTC_Vars.MA_Type mA2Type, int mA2Length, bool plotBullish, bool plotHiddenBullish, bool plotBearish, bool plotHiddenBearish, int divTransparency, Brush bearBrush, Brush bullBrush, int divHiddenTransparency, Brush hiddenBullBrush, Brush hiddenBearBrush, bool showBreak, bool showBreakAlert, bool playBreakAlertSound, Brush breakHHBrush, Brush breakLHBrush, Brush breakLLBrush, Brush breakHLBrush, int breakTransparency, bool ghost, int ghostLength, bool coloredCandles, bool fullColoredCandles, Brush oversoldCanleBrush, Brush overboughtCanleBrush, Brush mA1OverMA2CandleBrush, Brush mA1UnderMA2CandleBrush, Brush rossHookBullishBrush, Brush rossHookBearishBrush)
		{
			return indicator.RSIChartTradingConcepts(Input, pivotHighLeft, pivotHighRight, pivotLowLeft, pivotLowRight, higherHighBrush, higherHighTextBrush, higherLowBrush, higherLowTextBrush, lowerLowBrush, lowerLowTextBrush, lowerHighBrush, lowerHighTextBrush, fillOpacity, labelsDistance, rSI_Type, highRSISource, lowRSISource, rSILength, upDownLength, rOCLength, overboughtThreshold, oversoldThreshold, showRSITrend, sourceType, highsSource, lowsSource, mA1Source, mA1Type, mA1Length, mA2Source, mA2Type, mA2Length, plotBullish, plotHiddenBullish, plotBearish, plotHiddenBearish, divTransparency, bearBrush, bullBrush, divHiddenTransparency, hiddenBullBrush, hiddenBearBrush, showBreak, showBreakAlert, playBreakAlertSound, breakHHBrush, breakLHBrush, breakLLBrush, breakHLBrush, breakTransparency, ghost, ghostLength, coloredCandles, fullColoredCandles, oversoldCanleBrush, overboughtCanleBrush, mA1OverMA2CandleBrush, mA1UnderMA2CandleBrush, rossHookBullishBrush, rossHookBearishBrush);
		}

		public Indicators.RSIChartTradingConcepts RSIChartTradingConcepts(ISeries<double> input , int pivotHighLeft, int pivotHighRight, int pivotLowLeft, int pivotLowRight, Brush higherHighBrush, Brush higherHighTextBrush, Brush higherLowBrush, Brush higherLowTextBrush, Brush lowerLowBrush, Brush lowerLowTextBrush, Brush lowerHighBrush, Brush lowerHighTextBrush, int fillOpacity, int labelsDistance, RSICTC_Vars.RSI_Type rSI_Type, RSICTC_Vars.Price_Source highRSISource, RSICTC_Vars.Price_Source lowRSISource, int rSILength, int upDownLength, int rOCLength, int overboughtThreshold, int oversoldThreshold, bool showRSITrend, RSICTC_Vars.Source_Type sourceType, RSICTC_Vars.Price_Source highsSource, RSICTC_Vars.Price_Source lowsSource, RSICTC_Vars.Price_Source mA1Source, RSICTC_Vars.MA_Type mA1Type, int mA1Length, RSICTC_Vars.Price_Source mA2Source, RSICTC_Vars.MA_Type mA2Type, int mA2Length, bool plotBullish, bool plotHiddenBullish, bool plotBearish, bool plotHiddenBearish, int divTransparency, Brush bearBrush, Brush bullBrush, int divHiddenTransparency, Brush hiddenBullBrush, Brush hiddenBearBrush, bool showBreak, bool showBreakAlert, bool playBreakAlertSound, Brush breakHHBrush, Brush breakLHBrush, Brush breakLLBrush, Brush breakHLBrush, int breakTransparency, bool ghost, int ghostLength, bool coloredCandles, bool fullColoredCandles, Brush oversoldCanleBrush, Brush overboughtCanleBrush, Brush mA1OverMA2CandleBrush, Brush mA1UnderMA2CandleBrush, Brush rossHookBullishBrush, Brush rossHookBearishBrush)
		{
			return indicator.RSIChartTradingConcepts(input, pivotHighLeft, pivotHighRight, pivotLowLeft, pivotLowRight, higherHighBrush, higherHighTextBrush, higherLowBrush, higherLowTextBrush, lowerLowBrush, lowerLowTextBrush, lowerHighBrush, lowerHighTextBrush, fillOpacity, labelsDistance, rSI_Type, highRSISource, lowRSISource, rSILength, upDownLength, rOCLength, overboughtThreshold, oversoldThreshold, showRSITrend, sourceType, highsSource, lowsSource, mA1Source, mA1Type, mA1Length, mA2Source, mA2Type, mA2Length, plotBullish, plotHiddenBullish, plotBearish, plotHiddenBearish, divTransparency, bearBrush, bullBrush, divHiddenTransparency, hiddenBullBrush, hiddenBearBrush, showBreak, showBreakAlert, playBreakAlertSound, breakHHBrush, breakLHBrush, breakLLBrush, breakHLBrush, breakTransparency, ghost, ghostLength, coloredCandles, fullColoredCandles, oversoldCanleBrush, overboughtCanleBrush, mA1OverMA2CandleBrush, mA1UnderMA2CandleBrush, rossHookBullishBrush, rossHookBearishBrush);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.RSIChartTradingConcepts RSIChartTradingConcepts(int pivotHighLeft, int pivotHighRight, int pivotLowLeft, int pivotLowRight, Brush higherHighBrush, Brush higherHighTextBrush, Brush higherLowBrush, Brush higherLowTextBrush, Brush lowerLowBrush, Brush lowerLowTextBrush, Brush lowerHighBrush, Brush lowerHighTextBrush, int fillOpacity, int labelsDistance, RSICTC_Vars.RSI_Type rSI_Type, RSICTC_Vars.Price_Source highRSISource, RSICTC_Vars.Price_Source lowRSISource, int rSILength, int upDownLength, int rOCLength, int overboughtThreshold, int oversoldThreshold, bool showRSITrend, RSICTC_Vars.Source_Type sourceType, RSICTC_Vars.Price_Source highsSource, RSICTC_Vars.Price_Source lowsSource, RSICTC_Vars.Price_Source mA1Source, RSICTC_Vars.MA_Type mA1Type, int mA1Length, RSICTC_Vars.Price_Source mA2Source, RSICTC_Vars.MA_Type mA2Type, int mA2Length, bool plotBullish, bool plotHiddenBullish, bool plotBearish, bool plotHiddenBearish, int divTransparency, Brush bearBrush, Brush bullBrush, int divHiddenTransparency, Brush hiddenBullBrush, Brush hiddenBearBrush, bool showBreak, bool showBreakAlert, bool playBreakAlertSound, Brush breakHHBrush, Brush breakLHBrush, Brush breakLLBrush, Brush breakHLBrush, int breakTransparency, bool ghost, int ghostLength, bool coloredCandles, bool fullColoredCandles, Brush oversoldCanleBrush, Brush overboughtCanleBrush, Brush mA1OverMA2CandleBrush, Brush mA1UnderMA2CandleBrush, Brush rossHookBullishBrush, Brush rossHookBearishBrush)
		{
			return indicator.RSIChartTradingConcepts(Input, pivotHighLeft, pivotHighRight, pivotLowLeft, pivotLowRight, higherHighBrush, higherHighTextBrush, higherLowBrush, higherLowTextBrush, lowerLowBrush, lowerLowTextBrush, lowerHighBrush, lowerHighTextBrush, fillOpacity, labelsDistance, rSI_Type, highRSISource, lowRSISource, rSILength, upDownLength, rOCLength, overboughtThreshold, oversoldThreshold, showRSITrend, sourceType, highsSource, lowsSource, mA1Source, mA1Type, mA1Length, mA2Source, mA2Type, mA2Length, plotBullish, plotHiddenBullish, plotBearish, plotHiddenBearish, divTransparency, bearBrush, bullBrush, divHiddenTransparency, hiddenBullBrush, hiddenBearBrush, showBreak, showBreakAlert, playBreakAlertSound, breakHHBrush, breakLHBrush, breakLLBrush, breakHLBrush, breakTransparency, ghost, ghostLength, coloredCandles, fullColoredCandles, oversoldCanleBrush, overboughtCanleBrush, mA1OverMA2CandleBrush, mA1UnderMA2CandleBrush, rossHookBullishBrush, rossHookBearishBrush);
		}

		public Indicators.RSIChartTradingConcepts RSIChartTradingConcepts(ISeries<double> input , int pivotHighLeft, int pivotHighRight, int pivotLowLeft, int pivotLowRight, Brush higherHighBrush, Brush higherHighTextBrush, Brush higherLowBrush, Brush higherLowTextBrush, Brush lowerLowBrush, Brush lowerLowTextBrush, Brush lowerHighBrush, Brush lowerHighTextBrush, int fillOpacity, int labelsDistance, RSICTC_Vars.RSI_Type rSI_Type, RSICTC_Vars.Price_Source highRSISource, RSICTC_Vars.Price_Source lowRSISource, int rSILength, int upDownLength, int rOCLength, int overboughtThreshold, int oversoldThreshold, bool showRSITrend, RSICTC_Vars.Source_Type sourceType, RSICTC_Vars.Price_Source highsSource, RSICTC_Vars.Price_Source lowsSource, RSICTC_Vars.Price_Source mA1Source, RSICTC_Vars.MA_Type mA1Type, int mA1Length, RSICTC_Vars.Price_Source mA2Source, RSICTC_Vars.MA_Type mA2Type, int mA2Length, bool plotBullish, bool plotHiddenBullish, bool plotBearish, bool plotHiddenBearish, int divTransparency, Brush bearBrush, Brush bullBrush, int divHiddenTransparency, Brush hiddenBullBrush, Brush hiddenBearBrush, bool showBreak, bool showBreakAlert, bool playBreakAlertSound, Brush breakHHBrush, Brush breakLHBrush, Brush breakLLBrush, Brush breakHLBrush, int breakTransparency, bool ghost, int ghostLength, bool coloredCandles, bool fullColoredCandles, Brush oversoldCanleBrush, Brush overboughtCanleBrush, Brush mA1OverMA2CandleBrush, Brush mA1UnderMA2CandleBrush, Brush rossHookBullishBrush, Brush rossHookBearishBrush)
		{
			return indicator.RSIChartTradingConcepts(input, pivotHighLeft, pivotHighRight, pivotLowLeft, pivotLowRight, higherHighBrush, higherHighTextBrush, higherLowBrush, higherLowTextBrush, lowerLowBrush, lowerLowTextBrush, lowerHighBrush, lowerHighTextBrush, fillOpacity, labelsDistance, rSI_Type, highRSISource, lowRSISource, rSILength, upDownLength, rOCLength, overboughtThreshold, oversoldThreshold, showRSITrend, sourceType, highsSource, lowsSource, mA1Source, mA1Type, mA1Length, mA2Source, mA2Type, mA2Length, plotBullish, plotHiddenBullish, plotBearish, plotHiddenBearish, divTransparency, bearBrush, bullBrush, divHiddenTransparency, hiddenBullBrush, hiddenBearBrush, showBreak, showBreakAlert, playBreakAlertSound, breakHHBrush, breakLHBrush, breakLLBrush, breakHLBrush, breakTransparency, ghost, ghostLength, coloredCandles, fullColoredCandles, oversoldCanleBrush, overboughtCanleBrush, mA1OverMA2CandleBrush, mA1UnderMA2CandleBrush, rossHookBullishBrush, rossHookBearishBrush);
		}
	}
}

#endregion
