#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ConnorsRSI : Indicator
	{
		private Series<double> ids_Consecutive;
		
		private int			rankLookBack		= 100; 
		private int			clbPeriod			= 2;
		private int			rsiPeriod			= 3;
		private int			barsAgo				= 0;
		private double		rank				= 0.0;
		private double		percentRank			= 0.0;
	
		private ROC			rateOfChange;
		private RSI			clbRSI;
		private RSI			defaultRSI;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"ver 1.0.0 01/31/2015)  ConnorsRSI (Relative Strength Index) ... photog53";
				Name								= "ConnorsRSI";
				Calculate							= Calculate.OnBarClose;
				IsOverlay							= false;
				DisplayInDataBox					= true;
				DrawOnPricePanel					= true;
				DrawHorizontalGridLines				= true;
				DrawVerticalGridLines				= true;
				PaintPriceMarkers					= true;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive			= true;

				AddPlot(Brushes.Green, "Connors_RSI");
				AddLine(Brushes.MediumOrchid, 30, "Lower");
				AddLine(Brushes.YellowGreen, 70, "Upper");
			}
			else if (State == State.Configure)
			{
				ids_Consecutive = new Series<double>(this);
				
				rateOfChange 	= ROC(Input, 1);
				clbRSI 			= RSI(ids_Consecutive, clbPeriod, 3);
				defaultRSI 		= RSI(Input, rsiPeriod, 3);
			}
		}

		protected override void OnBarUpdate()
		{
			if(CurrentBar < 1)
			{
				ids_Consecutive[0]	= 0;
				Connors_RSI[0] 		= 50.0;
				return;
			}	
			
			barsAgo = Math.Min(rankLookBack, CurrentBar);
			rank = 0.0;
			
			for (int i = 1; i <= barsAgo; i++)
			{
				if(rateOfChange[0] > rateOfChange[i])
				{
					rank = rank + 1.0;
				}
			}
				
			percentRank = 100*rank/barsAgo;
				
			if(Input[0] > Input[1])
			{
				ids_Consecutive[0] = ids_Consecutive[1] < 0.5 ? 1.0 : ids_Consecutive[1] + 1.0;
			}
			else if (Input[0] < Input[1])
			{
				ids_Consecutive[0] = ids_Consecutive[1] > -0.5 ? -1.0 : ids_Consecutive[1] - 1.0;
			}
			else
			{
				ids_Consecutive[0] = 0.0;
			}
			
			Connors_RSI[0] = ((percentRank + clbRSI[0] + defaultRSI[0])/3.0);			
		}

		#region Properties
		[Range(1, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="Rank Look Back", Description="Rank LookBack Period", Order=1, GroupName="Parameters")]
		public int RankLookBack
		{
			get { return rankLookBack; }
			set { rankLookBack = value; }
		}

		[Range(1, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="RSI Period", Description="Numbers of bars used for calculations", Order=2, GroupName="Parameters")]
		public int RSIPeriod
		{
			get { return rsiPeriod; }
			set { rsiPeriod = value; }
		}

		[Range(1, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="Clb Period", Description="Consecutive period", Order=3, GroupName="Parameters")]
		public int ClbPeriod
		{
			get { return clbPeriod; }
			set { clbPeriod= value; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Connors_RSI
		{
			get { return Values[0]; }
		}


		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ConnorsRSI[] cacheConnorsRSI;
		public ConnorsRSI ConnorsRSI(int rankLookBack, int rSIPeriod, int clbPeriod)
		{
			return ConnorsRSI(Input, rankLookBack, rSIPeriod, clbPeriod);
		}

		public ConnorsRSI ConnorsRSI(ISeries<double> input, int rankLookBack, int rSIPeriod, int clbPeriod)
		{
			if (cacheConnorsRSI != null)
				for (int idx = 0; idx < cacheConnorsRSI.Length; idx++)
					if (cacheConnorsRSI[idx] != null && cacheConnorsRSI[idx].RankLookBack == rankLookBack && cacheConnorsRSI[idx].RSIPeriod == rSIPeriod && cacheConnorsRSI[idx].ClbPeriod == clbPeriod && cacheConnorsRSI[idx].EqualsInput(input))
						return cacheConnorsRSI[idx];
			return CacheIndicator<ConnorsRSI>(new ConnorsRSI(){ RankLookBack = rankLookBack, RSIPeriod = rSIPeriod, ClbPeriod = clbPeriod }, input, ref cacheConnorsRSI);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ConnorsRSI ConnorsRSI(int rankLookBack, int rSIPeriod, int clbPeriod)
		{
			return indicator.ConnorsRSI(Input, rankLookBack, rSIPeriod, clbPeriod);
		}

		public Indicators.ConnorsRSI ConnorsRSI(ISeries<double> input , int rankLookBack, int rSIPeriod, int clbPeriod)
		{
			return indicator.ConnorsRSI(input, rankLookBack, rSIPeriod, clbPeriod);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ConnorsRSI ConnorsRSI(int rankLookBack, int rSIPeriod, int clbPeriod)
		{
			return indicator.ConnorsRSI(Input, rankLookBack, rSIPeriod, clbPeriod);
		}

		public Indicators.ConnorsRSI ConnorsRSI(ISeries<double> input , int rankLookBack, int rSIPeriod, int clbPeriod)
		{
			return indicator.ConnorsRSI(input, rankLookBack, rSIPeriod, clbPeriod);
		}
	}
}

#endregion
