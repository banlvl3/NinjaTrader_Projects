#region Using declarations
using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.Indicators;
#endregion

//This namespace holds Add ons in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.AddOns
{
	public class PopUpWindow : NTWindow
	{
		private Button		okButton;
		private TextBlock	messageBlock;
		
		public string 	message;
		public Brush	TextColor;
		
		public PopUpWindow()
		{
			Caption		= "PopUp v1.0.2";
			Width		= 200;
			Height		= 120;
			TextColor	= Brushes.Black;

			Loaded		+= OnWindow_Loaded;
			Closing		+= OnWindow_Close;
		}

		private void OnWindow_Loaded(object sender, RoutedEventArgs e)
		{
			Grid grid = new Grid();
			
			ColumnDefinition col1 = new ColumnDefinition();
			col1.Width = new GridLength(15);
			
			ColumnDefinition col2 = new ColumnDefinition();
			 
			ColumnDefinition col3 = new ColumnDefinition();
			col3.Width = new GridLength(15);
			 
			grid.ColumnDefinitions.Add(col1);
			grid.ColumnDefinitions.Add(col2);
			grid.ColumnDefinitions.Add(col3);
			
			grid.RowDefinitions.Add(new RowDefinition());
			grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(30) });
			
			messageBlock = new TextBlock()
			{
				FontSize			= 12,
				Foreground			= TextColor,
				HorizontalAlignment	= HorizontalAlignment.Left,
				VerticalAlignment	= VerticalAlignment.Center,
				Margin				= new Thickness(0, 0, 0, 0),
				Text				= message
			};
			
			okButton = new Button()
			{
				Content				= "Ok",
				Width				= 50,
				Margin				= new Thickness(0,0,0,0),
				Padding				= new Thickness(0,0,0,0),
				Foreground			= TextColor,
				VerticalAlignment 	= VerticalAlignment.Bottom,
				HorizontalAlignment = HorizontalAlignment.Left
			};
			okButton.Click += OnOkButton_Click;
			
			Grid.SetColumn(messageBlock, 1);
			Grid.SetColumn(okButton, 1);
			
			Grid.SetRow(messageBlock, 0);
			Grid.SetRow(okButton, 1);
			
			grid.Children.Add(messageBlock);
			grid.Children.Add(okButton);
			
			Content = grid;
		}

		private void OnWindow_Close(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (okButton != null)
				okButton.Click -= OnOkButton_Click;
		}

		private void OnOkButton_Click(object sender, RoutedEventArgs e)
		{
			this.Close();
		}
	}
}
