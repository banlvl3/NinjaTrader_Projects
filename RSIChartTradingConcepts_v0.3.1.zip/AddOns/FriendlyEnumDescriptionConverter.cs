#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
	public class FriendlyEnumDescriptionConverter : EnumConverter
	{
		private Type enumType;
			
		public FriendlyEnumDescriptionConverter(Type type) : base(type)
		{
			enumType = type;
		}

		public override bool CanConvertFrom(ITypeDescriptorContext context, Type srcType)
		{
			return srcType == typeof(string);
		}

		public override bool CanConvertTo(ITypeDescriptorContext context, Type destType)
		{
			return destType == typeof(string);
		}

		public override object ConvertFrom(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value)
		{
			foreach (System.Reflection.FieldInfo fi in enumType.GetFields())
			{
				DescriptionAttribute dna = (DescriptionAttribute)Attribute.GetCustomAttribute(fi, typeof(DescriptionAttribute));
				if (dna != null && (string)value == dna.Description)
					return Enum.Parse(enumType, fi.Name);
			}
			return Enum.Parse(enumType, (string)value);
		}

		public override object ConvertTo(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value, Type destType)
		{
			System.Reflection.FieldInfo fi = enumType.GetField(value.ToString());
			DescriptionAttribute dna = (DescriptionAttribute) Attribute.GetCustomAttribute(fi, typeof(DescriptionAttribute));
			if(dna != null)
				return dna.Description;
			else
				return value.ToString();
		}

		public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			List<string> values = new List<string>();
			foreach (var v in Enum.GetValues(enumType))
			{
				System.Reflection.FieldInfo fi = enumType.GetField(v.ToString());
				DescriptionAttribute dna = (DescriptionAttribute)Attribute.GetCustomAttribute(fi, typeof(DescriptionAttribute));
				if (dna != null)
					values.Add(dna.Description);
				else
					values.Add(v.ToString());
			}
			return new StandardValuesCollection(values);
		}
	}
}
