#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.GB
{
	[Gui.CategoryOrder("Parameters", 1)]
	[Gui.CategoryOrder("Color", 2)]
	[Gui.CategoryOrder("Opacity", 3)]
	[Gui.CategoryOrder("Version", 4)]
	
	public class gbChandelierStop : Indicator
	{
		#region Variables
			private double									maxHi;
			private double									minLo;
			private double									atr;
			private double									hbound;
			private double									lbound;
			private double									hboundLast = 9999999;
			private double									lboundLast = 0;	
			private bool									trendUp = true;
			private string									versionString = "v 1.0 - March 24, 2021";
        #endregion
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Chuck LeBeau's Chandelier Stop.";
				Name										= "gbChandelierStop";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= false;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= false;
				DrawVerticalGridLines						= false;
				PaintPriceMarkers							= false;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive					= true;
				
				/// Parameters
				Lookback									= 22;
				MultipleATR									= 3;
				UseTicks									= false;
				NbrOfTicks									= 30;
				
				/// Color
				C1 											= Brushes.Lime;
				C2 											= Brushes.Red;
				ColorBG										= true;
				C3 											= Brushes.DarkGreen;
				C4 											= Brushes.DarkRed;
				
				/// Opacity
				O1 											= 90;
				O2 											= 90;
				O3 											= 10;
				O4 											= 10;
				
				AddPlot(new Stroke(Brushes.White, 3), PlotStyle.Line, "ChandelierHi");
				AddPlot(new Stroke(Brushes.White, 3), PlotStyle.Line, "ChandelierLo");	
			}
			else if (State == State.Configure)
			{
				if (C1 != null) { Brush C_1 = C1.Clone(); C_1.Opacity = (float) O1/100.0; C_1.Freeze(); C1 = C_1; }
				if (C2 != null) { Brush C_2 = C2.Clone(); C_2.Opacity = (float) O2/100.0; C_2.Freeze(); C2 = C_2; }
				if (C3 != null) { Brush C_3 = C1.Clone(); C_3.Opacity = (float) O3/100.0; C_3.Freeze(); C3 = C_3; }
				if (C4 != null) { Brush C_4 = C2.Clone(); C_4.Opacity = (float) O4/100.0; C_4.Freeze(); C4 = C_4; }
			}
			else if (State == State.Historical)
			{
			    SetZOrder(int.MinValue);
			}
		}

		protected override void OnBarUpdate()
		{		
			if (CurrentBar < Lookback) return;

			maxHi = MAX(High, Lookback)[0];
			minLo = MIN(Low, Lookback)[0];

			/// Use ATR or fixed number of ticks?
			if (!UseTicks)
				atr = ATR(Lookback)[0] * MultipleATR;
			else 
				atr = NbrOfTicks * TickSize;
			
			/// Calculate boundaries
			hbound = minLo + atr;
			lbound = maxHi - atr;
			
			/// Correct for drift
			if (trendUp && lbound < lboundLast) 								/// do not allow up trend to drift down
				lbound = lboundLast;
			else if (!trendUp && hbound > hboundLast) 							/// do not allow down trend to drift up
				hbound = hboundLast;
			
			/// Determine trend direction
			if (Close[0] > hbound && Close[1] > hbound && !trendUp)				/// must close above upper bound 2 consecutive bars
				trendUp = true;
			else if (Close[0] < lbound && Close[1] < lbound && trendUp)			/// must close below lower bound 2 consecutive bars
				trendUp = false;
			
			ChandelierHi[0] = hbound;
			ChandelierLo[0] = lbound;
			
			/// Color plots, background
			if (trendUp)
			{			
				PlotBrushes[0][0] = Brushes.Transparent;
				PlotBrushes[1][0] = C1;	
				
				if (ColorBG)
					BackBrushAll = C3;
			}
			else
			{
				PlotBrushes[0][0] = C2;
				PlotBrushes[1][0] = Brushes.Transparent;
				
				if (ColorBG) 
					BackBrushAll = C4;
			}
			
			/// Save current boundary for next pass
			hboundLast = hbound;
			lboundLast = lbound;
		}
		
		#region Properties
		
		/// Parameters

		[Browsable(false)] [XmlIgnore] public Series<double> ChandelierHi { get { return Values[0]; }}
		[Browsable(false)] [XmlIgnore] public Series<double> ChandelierLo { get { return Values[1]; }}
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Lookback", Description="Lookback for period to find highs or lows; also used for ATR.", Order=1, GroupName="Parameters")]
		public int Lookback
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="ATR Multiple", Description="Multiple for ATR.", Order=2, GroupName="Parameters")]
		public double MultipleATR
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Use Ticks instead of ATR", Description="Use fixed number of ticks instead of ATR.", Order=3, GroupName="Parameters")]
		public bool UseTicks
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Number of Ticks", Description="Number of ticks to use.", Order=4, GroupName="Parameters")]
		public int NbrOfTicks

		{ get; set; }
		///  Color
		
		[XmlIgnore]
		[Display(Name="Plot - Trend Up", Description="", Order=1, GroupName="Color")]
		public Brush C1
		{ get; set; }
		[Browsable(false)]
		public string C1Serializable
		{
			get { return Serialize.BrushToString(C1); }
			set { C1 = Serialize.StringToBrush(value); }
		}			

		[XmlIgnore]
		[Display(Name="Plot - Trend Down", Description="", Order=2, GroupName="Color")]
		public Brush C2
		{ get; set; }
		[Browsable(false)]
		public string C2Serializable
		{
			get { return Serialize.BrushToString(C2); }
			set { C2 = Serialize.StringToBrush(value); }
		}	
		
		[NinjaScriptProperty]
		[Display(Name="Color Background", Description="", Order=3, GroupName="Color")]
		public bool ColorBG
		{ get; set; }
		
		[XmlIgnore]
		[Display(Name="Background - Trend Up", Description="", Order=4, GroupName="Color")]
		public Brush C3
		{ get; set; }
		[Browsable(false)]
		public string C3Serializable
		{
			get { return Serialize.BrushToString(C3); }
			set { C3 = Serialize.StringToBrush(value); }
		}			

		[XmlIgnore]
		[Display(Name="Background - Trend Down", Description="", Order=5, GroupName="Color")]
		public Brush C4
		{ get; set; }
		[Browsable(false)]
		public string C4Serializable
		{
			get { return Serialize.BrushToString(C4); }
			set { C4 = Serialize.StringToBrush(value); }
		}	
		
		///  Opacity
		
		[XmlIgnore]
		[Range(0, 100)]
		[Display(Name="Plot - Trend Up", Description="", Order=1, GroupName="Opacity")]
		public int O1
		{ get; set; }

		[XmlIgnore]
		[Range(0, 100)]
		[Display(Name="Plot - Trend Down", Description="", Order=2, GroupName="Opacity")]
		public int O2
		{ get; set; }
		
		[XmlIgnore]
		[Range(0, 100)]
		[Display(Name="Background - Trend Up", Description="", Order=3, GroupName="Opacity")]
		public int O3
		{ get; set; }

		[XmlIgnore]
		[Range(0, 100)]
		[Display(Name="Background - Trend Down", Description="", Order=4, GroupName="Opacity")]
		public int O4
		{ get; set; }
		
		/// Version
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 1)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private GB.gbChandelierStop[] cachegbChandelierStop;
		public GB.gbChandelierStop gbChandelierStop(int lookback, double multipleATR, bool useTicks, int nbrOfTicks, bool colorBG)
		{
			return gbChandelierStop(Input, lookback, multipleATR, useTicks, nbrOfTicks, colorBG);
		}

		public GB.gbChandelierStop gbChandelierStop(ISeries<double> input, int lookback, double multipleATR, bool useTicks, int nbrOfTicks, bool colorBG)
		{
			if (cachegbChandelierStop != null)
				for (int idx = 0; idx < cachegbChandelierStop.Length; idx++)
					if (cachegbChandelierStop[idx] != null && cachegbChandelierStop[idx].Lookback == lookback && cachegbChandelierStop[idx].MultipleATR == multipleATR && cachegbChandelierStop[idx].UseTicks == useTicks && cachegbChandelierStop[idx].NbrOfTicks == nbrOfTicks && cachegbChandelierStop[idx].ColorBG == colorBG && cachegbChandelierStop[idx].EqualsInput(input))
						return cachegbChandelierStop[idx];
			return CacheIndicator<GB.gbChandelierStop>(new GB.gbChandelierStop(){ Lookback = lookback, MultipleATR = multipleATR, UseTicks = useTicks, NbrOfTicks = nbrOfTicks, ColorBG = colorBG }, input, ref cachegbChandelierStop);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.GB.gbChandelierStop gbChandelierStop(int lookback, double multipleATR, bool useTicks, int nbrOfTicks, bool colorBG)
		{
			return indicator.gbChandelierStop(Input, lookback, multipleATR, useTicks, nbrOfTicks, colorBG);
		}

		public Indicators.GB.gbChandelierStop gbChandelierStop(ISeries<double> input , int lookback, double multipleATR, bool useTicks, int nbrOfTicks, bool colorBG)
		{
			return indicator.gbChandelierStop(input, lookback, multipleATR, useTicks, nbrOfTicks, colorBG);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.GB.gbChandelierStop gbChandelierStop(int lookback, double multipleATR, bool useTicks, int nbrOfTicks, bool colorBG)
		{
			return indicator.gbChandelierStop(Input, lookback, multipleATR, useTicks, nbrOfTicks, colorBG);
		}

		public Indicators.GB.gbChandelierStop gbChandelierStop(ISeries<double> input , int lookback, double multipleATR, bool useTicks, int nbrOfTicks, bool colorBG)
		{
			return indicator.gbChandelierStop(input, lookback, multipleATR, useTicks, nbrOfTicks, colorBG);
		}
	}
}

#endregion
